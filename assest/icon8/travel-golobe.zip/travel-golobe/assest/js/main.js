$("#rangeDate").flatpickr({
    mode: 'range',
    dateFormat: "Y-m-d"
});