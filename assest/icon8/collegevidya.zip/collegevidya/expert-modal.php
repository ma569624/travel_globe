<!-- The Modal -->
<div class="modal fade" id="expert">
    <div class="modal-dialog ">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header border-0">

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body pb-5">

                <div class="row">
                    <div class="col-6 mx-auto">
                        <div id="wrapper">
                            <div class="card-wrapper">

                                <div class="card left-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\Ankit Singh.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card right-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\eexpert-team3.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card left-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\isha-sharma.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card right-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\Joshi-sir.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card left-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\Neeta.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card left-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\pallavi.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="card left-card">
                                    <div class="card-bg">
                                        <div class="card-img">
                                            <img src="assets\img\New\preeti.jpg" alt="">
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="row text-center">
                        <p class="mt-4 textprimary fs-14 mb-2">30,000+ Students were Happy After their calls!</p>
                        <p>Make College decisions like a pro 😎</p>
                    </div>

                    <div class="row-flex gap-2 px-3 d-flex justify-content-center">
                        <a href="payment.php" class="btn btn-primary btn-md">Instant Video Consultation</a>
                        <a href="counsellors.php" class="btn btn-outline-primary btn-md">Find Best Mentors</a>
                    </div>

                    <div class="row text-center">
                        <a href="#" class="mt-2 text-primary fs-14 "><i class="fa fa-phone"></i> Call Now </a>

                    </div>

                </div>




            </div>

        </div>
    </div>
</div>

<style>
 

  /* Wrapper and cards styling */

  .card-wrapper {
    width: 100%;
    min-width: 800px;
    height: auto;
    min-height: 280px;
   
  }

  .card-wrapper .card {
    width: 40%;
    max-width: 300px;
    position: absolute;
    
    display: block;
    transition: transform .5s ease;
    transform-origin: bottom center;
    cursor: pointer;
  }

  .card-wrapper .card.polaroid {
    border: 10px solid white;
    border-bottom: 60px solid white;
    box-shadow: 0 0 15px 0 rgba(0, 0, 0, .3);
  }

  .card-wrapper .card.polaroid .card-bg {
    padding-top: 90%;
  }

  .card-wrapper .card-bg {
    padding-top: 130%;
    position: relative;
  }

  .card-wrapper .card-img {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
  }

  .card-wrapper .card-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 16px;
  }

  .polaroid .card-img img {
    border-radius: 0
  }

  .left-card {
    transform: rotate(-15deg);
  }

  .right-card {
    transform: rotate(15deg);
  }

  .card.active {
    transform: rotate(0);
  }

  /* Cards aniamtion */
  .card.animate-leave {
    animation: leave .3s;
    animation-fill-mode: both;
    animation-timing-function: ease-in-out;
  }

  .card.right-card.animate-back {
    animation: backR .3s;
    animation-fill-mode: both;
    animation-timing-function: ease-in-out;
  }

  .card.left-card.animate-back {
    animation: backL .3s;
    animation-fill-mode: both;
    animation-timing-function: ease-in-out;
  }

  @keyframes leave {
    from {
      transform: translateY(0);
    }

    to {
      transform: translateY(-110%);
      transform: translateY(-110%) translateX(-20%);
    }
  }

  @keyframes backR {
    from {
      transform: translateY(-110%);
      transform: translateY(-110%) translateX(-20%);
    }

    to {
      transform: translateY(0) rotate(15deg);
    }
  }

  @keyframes backL {
    from {
      transform: translateY(-110%);
      transform: translateY(-110%) translateX(-20%);
    }

    to {
      transform: translateY(0) rotate(-15deg);
    }
  }



 



 
</style>


<script src="assets/js/jquery.min.js"></script>

<script>

  $(document).ready(function () {
    $('.card-wrapper .card').last().addClass('active');
    $('.card-wrapper .card').last().prev().addClass('next');
    // Autoplay interval 
    var interval = 5000;
    var myInt = setInterval(function () {
      $('.card.active').trigger('click');
    }, interval);
    // Clickable toggle
    $('.card').on('click', function () {
      clearInterval(myInt);
      // Prevent multiple fast clicks to break the functioning
      $('.card').css({ 'pointer-events': 'none' });
      $('.card.active').addClass('animate-leave').removeClass('active');
      $('.card.next').addClass('active').removeClass('next');
      $('.card-wrapper .card').last().prev().prev().addClass('next');
      setTimeout(function () {
        $('.card.animate-leave').addClass('animate-back').removeClass('animate-leave');
        $('.card-wrapper').prepend($('.animate-back'));
      }, 300); // Wait for the animation to end
      setTimeout(function () {
        $('.card.animate-back').removeClass('animate-back');
        $('.card').css({ 'pointer-events': 'auto' });
        clearInterval(myInt);
        myInt = setInterval(function () {
          $('.card.active').trigger('click');
        }, interval);
      }, 700);
    });

    // Just for fun
    $('.polaroid-style').on('click', function () {
      $('.card').toggleClass('polaroid')
    });

  });
</script>