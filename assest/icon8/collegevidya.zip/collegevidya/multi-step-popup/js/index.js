$(document).ready(function () {
  $("#submitModal").MultiStep({
    title: "Just Answer 6 Simple questions to get Best University for you!",
    data: [
      {
        content: `
            <h4 class=text-center>Are you Currently Working?</h4>
            <form >
                <div class="row">
                <div class="col-4 mx-auto">
                    <div class="form-check ">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" >
                    <label class="form-check-label" for="flexRadioDefault1">
                        Yes
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        No
                    </label>
                    </div>
                </div>
                </div>
                
            </form>
          `,
        label: "Custom label",
      },
      {
        content: `
            <h4 class=text-center>How many Study Hours can you Dedicate on the Weekly Basis?</h4>
            <form >
                <div class="row">
                <div class="col-4 mx-auto">
                    <div class="form-check ">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        2-4 Hours
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        4-8 Hours
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        8-16 Hours
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        16+ Hours
                    </label>
                    </div>
                </div>
                </div>
                
            </form>
          `,
      },
      {
        content: `
            <h4 class=text-center>Select Your Budget Options?</h4>
            <form >
                <div class="row">
                <div class="col-4 mx-auto">
                    <div class="form-check ">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Less than 60,000
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        60,000 to 1 lac
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        1 lac to 1.9 lac
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        2 lac to 3.5 lac
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        3.6 lac +
                    </label>
                    </div>
                </div>
                </div>
                
            </form>
          `,
       
      },
      {
        content: `
            <h4 class=text-center>Your Highest Qualification?</h4>
            <form >
                <div class="row">
                <div class="col-4 mx-auto">
                    <div class="form-check ">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        College Graudate
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Completed 12th
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        Completed 10th
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        Diploma Holder
                    </label>
                    </div>
                    
                </div>
                </div>
                
            </form>
          `,
        
      },
      {
        content: `
            <h4 class=text-center>What matters you the most?</h4>
            <form >
                <div class="row">
                <div class="col-4 mx-auto">
                    <div class="form-check ">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        The Right University + Right Course
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Less Fee Structure
                    </label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                    <label class="form-check-label" for="flexRadioDefault2">
                        I only care about the degree
                    </label>
                    </div>
                    
                    
                </div>
                </div>
                
            </form>
          `,
      },
      
    ],
    final: `
    <h4 class=text-center>Do you want to convert your Fees into Easy EMIs?</h4>
    <form >
        <div class="row">
        <div class="col-4 mx-auto">
            <div class="form-check ">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
            <label class="form-check-label" for="flexRadioDefault1">
                Yes
            </label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
            <label class="form-check-label" for="flexRadioDefault2">
                No
            </label>
            </div>
            
            
        </div>
        </div>
        
    </form>
  `,
   
    
  });
});
