
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Agent Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="description" />
    <meta name="csrf-token" content="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">
    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/ion.rangeSlider.min.css" />
    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/bootstrap.min.css"
        id="bootstrap-style" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/app.min.css" id="app-style" />
    <!--<link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/daterangepicker.css">-->
    
    <link href="https://cdn.rawgit.com/mdehoog/Semantic-UI/6e6d051d47b598ebab05857545f242caf2b4b48c/dist/semantic.min.css" rel="stylesheet" type="text/css" />
    
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/icons.min.css" />
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/animate.min.css" />
    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/chosen.min.css">

    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/select2.min.css" />
    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/jquery.fancybox.min.css">

    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://design.enrolhere.com/assetsAgent/css/responsive.css">

</head>

<body data-sidebar="dark" id="main">

    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
                <div class="object" id="object_one"></div>
                <div class="object" id="object_two" style="left:20px;"></div>
                <div class="object" id="object_three" style="left:40px;"></div>
                <div class="object" id="object_four" style="left:60px;"></div>
                <div class="object" id="object_five" style="left:80px;"></div>
            </div>
        </div>
    </div>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <div class="vertical-menu">
            <div data-simplebar class="h-100">
                <div class="close-nav">
                    <i class="bi bi-x"></i>
                </div>
                <div class="slide-logo">
                    <!-- <img src=""> -->
                    <h5 class="hide_logo">E</h5>
                    <h5 class="full_logo">Enrolhere</h5>
                </div>
                <div id="sidebar-menu">
                    <ul class="metismenu list-unstyled" id="side-menu">
                                                                    
                        <li><a href="/agentDashboard"><i class="me-2 fa-solid fa-house-chimney-window"></i><span>Dashboard</span></a></li>
                                            
                        <li><a href="/agentProgram"><i class="me-2 fa-solid fa-magnifying-glass"></i><span>Programs &amp; Schools</span></a></li>
                                            
                        <li><a href="/students"><i class="me-2 fa-solid fa-user-graduate"></i><span>Students</span></a></li>
                                            
                        <li><a href="/agentApplication"><i class="me-2 fa-solid fa-scroll"></i><span>Applications</span></a></li>
                                            
                        <li><a href="/sub_agent"><i class="me-2 fa-solid fa-user"></i><span>Sub Agents</span></a></li>
                                            
                        <li><a href="/growth_hub"><i class="me-2 fa-solid fa-users"></i><span>Growth Hub</span></a></li>
                                            
                        <li><a href="/agent_student_profile"><i class="me-2 fa-solid fa-users"></i><span>Student Profile</span></a></li>
                                            
                        <li><a href="/training_request"><i class="me-2 fa-solid fa-flag"></i><span>Training Request</span></a></li>
                                            
                        <li><a href="/invoices"><i class="me-2 fa-solid fa-receipt"></i><span>Invoices</span></a></li>
                                            
                        <li><a href="/students_applications"><i class="me-2 fa-solid fa-file-lines"></i><span>Students Applications</span></a></li>
                                            
                        <li><a href="/team"><i class="me-2 fa-solid fa-people-group"></i><span>Team</span></a></li>
                                            
                        <li><a href="/agent_my_reminders"><i class="me-2 fa-solid fa-clock"></i><span>My Reminders</span></a></li>
                                            
                        <li><a href="/template"><i class="me-2 fa-solid fa-file-lines"></i><span>Template</span></a></li>
                                            
                        <li><a href="/knowledge_base"><i class="me-2 fa-solid fa-box"></i><span>Knowledge Base</span></a></li>
                                                

                    </ul>
                </div>
                
                 <div class="side-profile">
                    <div class="profile-login d-inline-block">
                     
                        <div class="dropdown" style="display: flex;padding-left: 15px;">
                          
        
                            <img class="rounded-circle header-profile-user" src="/assetsAgent/img/profile-icon.png" alt="Header Avatar">
                            <a class="user-name custom" href="javascript::"> 
                                <span class="font-size-14">Hello</span>
                                <span class="font-size-14"><b> Sukhwinder Singh</b></span> 
                            </a>
         
                        </div>
                      
                    </div>
        
                </div>
                
            </div>
        </div>


        <div class="main-content">
            
                                                    

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                                        <div class="review-main pt-3 pb-2">
                        <h3>Show Application
                            <a class="btn btn-danger btn-sm px-2 mb-2"><i class="fa-solid fa-cart-shopping"></i> &nbsp; Pending</a>
                        </h3>  
                        <!--<span class="badge bg-danger text-white float-end">Pending</span>-->
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item">Dashboard</li>&nbsp; /
                                <li class="breadcrumb-item">Application</li>&nbsp; /
                                    <li class="breadcrumb-item" aria-current="page">Students</li>&nbsp; /
                                        <li class="breadcrumb-item" aria-current="page">Ram RAM</li>&nbsp; /
                                            <li class="breadcrumb-item" aria-current="page">Applications</li>&nbsp; /
                                                <li class="breadcrumb-item active" aria-current="page">Photograph - Ellesmere Port, North West, GB</li>&nbsp; /
                          </ol>
                        </nav>
                    </div> 
                </div>
                <div class="col-md-4">
                    <div class="d-flex justify-content-end">
                        <div class="dropdown cencel_document">
                            <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-ellipsis-vertical fs-4"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Cancel Application</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-md-3">
                <div class="col-md-12">
                    <div id="crumbs">
                        <ul>

                            <li><a href="#"
                                    class=" application-active  "><i
                                        class="fa-solid fa-check"></i><span> Pay Application Fee</span></a></li>
                            <li><a href="#"
                                    class=" application-active  "><i
                                        class="fa-solid fa-check"></i><span> Prepare Application</span></a></li>
                            <li><a href="#"
                                    class=" application-active  "><i
                                        class="fa-solid fa-check"></i><span> Submission In Progress</span></a></li>
                            <li><a href="#"
                                    class=" application-active  "><i
                                        class="fa-solid fa-check"></i><span> Decision</span></a></li>
                            <li><a href="#"
                                    class=" application-active  "><i
                                        class="fa-solid fa-check"></i><span> Post-Decision Requirements</span></a></li>
                            <li><a href="#"
                                    class=" ''  "><i
                                        class="fa-solid fa-check"></i><span> Enrollment Confirmed</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-4">
                    <div class="application-custom-box">
                        <div class="main-review-left">
                            
                            <div class="css-1p7mtvv">
                                <!--<div class="muiBox-img">-->
                                <!--    <img src="/assetsAgent/img/user.svg" class="img-fluid" alt="">-->
                                <!--</div>-->
                                <div class="css-18xhlkt">
                                    <img src="/assetsAgent/img/college-logo.png" class="img-fluid" alt="">
                                </div>
                                <div class="css-11bq05t">
                                    <div class="css-xdzpz9">
                                        <div class="sidebarcountry">
                                            <img width="73px" height="73px" class="rounded-circle"
                                                src="https://design.enrolhere.com/images/1658944252.jpg"
                                                alt="Photograph" />
                                        </div>
                                        <div class="css-1dt3oac">
                                            <a href="/agent-college-details/3" 
                                                class="fw-bold">Photograph  
                                                - Ellesmere Port, North West, GB
                                            </a>
                                        </div>
                                    </div>
                                    <div class="css-15zjdt5">
                                        <a href="/agent-program-details/2"
                                            class="fw-bold">Certificate </a>
                                    </div>
                                    <div class="muiBox-root">
                                        <span class="css-wjljkp">Delivery Method: </span>
                                        <div class="jss1152">In-class</div>
                                    </div>
                                    <div class="muiBox-root">
                                        <span class="css-wjljkp">Level: </span>
                                        <span> Doctoral Degree (Phd, M.D., ...) </span>
                                    </div>
                                    <div class="muiBox-root">
                                        <span class="css-wjljkp">Required Level: </span>
                                        <span>Grade 12</span>
                                    </div>
                                    <div class="css-1rxnsrf">
                                        <span class="css-wjljkp">Application ID:</span>
                                        <span> 69505131</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-md-2">
                                <div class="col-md-3">
                                    <p class="fs-4 fw-bold">Intake(s):</p>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <select class="form-select form-control" aria-label="Default select example">
                                            <option value="" selected disabled>
                                                2022-Dec
                                            </option>

                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="add-backup-program">
                                <i class="fa-solid fa-plus fs-5"></i>
                                <p class="fs-5">Add Backup Program</p>
                            </div>
                            <div class="row status">
                                <div class="col-md-12">
                                    <p class="fs-4 fw-bold">Status:</p>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="ready-submit"
                                             checked >
                                        <label class="form-check-label" for="ready-submit">
                                            Ready to Submit
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="submitted-school"
                                             checked >
                                        <label class="form-check-label" for="submitted-school">
                                            Submitted to School
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="ready-visa"
                                             checked >
                                        <label class="form-check-label" for="ready-visa">
                                            Ready for Visa
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="ready-enroll"
                                             checked >
                                        <label class="form-check-label" for="ready-enroll">
                                            Ready to Enroll
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value=""
                                            id="enrollment-confirmed"
                                             '' >
                                        <label class="form-check-label" for="enrollment-confirmed">
                                            Enrollment Confirmed
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 mt-md-2 text-center">
                                    <p class="text--custom fs-4 m-0"> <b><i class="fa-solid fa-cart-shopping"></i>
                                            Pending </b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="application-custom-box">
                        <div class="main-review-left">
                            <div class="row students-all-information">
                                <div class="accordion" id="accordionPanelsStayOpenExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="student-profile-headingOne">
                                            <div class="row">
                                                <div class="accordion-button" data-bs-toggle="collapse"
                                                    data-bs-target="#student-profile-collapseOne" aria-expanded="true">
                                                    <div class="col-md-4">
                                                        <p class="fs-4">Student:</p>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <p class="fs-4"><a
                                                                href="/agent-student-profile/28">28</a>
                                                            | <a href="/agent-student-profile/28"
                                                                class="text--custom"> Ram
                                                                RAM
                                                                Ram</a> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </h2>
                                        <div id="student-profile-collapseOne" class="accordion-collapse collapse show"
                                            aria-labelledby="student-profile-headingOne">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <ul>
                                                            <li class="fw-bold">Login Email</li>
                                                            <li class="fw-bold">Primary Email </li>
                                                            <li class="fw-bold">Birthday</li>
                                                            <li class="fw-bold">Phone Number</li>
                                                            <li class="fw-bold">First Language</li>
                                                            <li class="fw-bold">Gender</li>
                                                            <li class="fw-bold">Marital Status</li>
                                                            <li class="fw-bold">Passport Number</li>
                                                            <li class="fw-bold">Passport Expiry Date</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <ul>
                                                                                                                        <li>ram111@gmail.com</li>
                                                            <li>ram111@gmail.com</li>
                                                            <li> <br />Sep 09, 2022
                                                                (0 years old)</li>
                                                            <li><br />+91- 8855669988</li>
                                                            <li><br />Hindi</li>
                                                            <li>Male</li>
                                                            <li>Married </li>
                                                            <li><br />IND14253658</li>
                                                            <li><br />NA</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item border-none">
                                        <h2 class="accordion-header" id="background-headingTwo">
                                            <div class="row">
                                                <div class="accordion-button" data-bs-toggle="collapse"
                                                    data-bs-target="#background-collapseTwo" aria-expanded="false"
                                                    aria-controls="panelsStayOpen-collapseTwo">
                                                    <div class="col-md-4">
                                                        <p class="fs-4">Background :</p>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <p class="fs-5 opacity-50">Nationality</p>
                                                        <p class="fs-5">India
                                                        </p>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <p class="fs-5 opacity-50">Residence</p>
                                                        <p class="fs-5">India</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </h2>
                                        <div id="background-collapseTwo" class="accordion-collapse collapse show"
                                            aria-labelledby="background-headingTwo">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <ul>
                                                            <li class="fw-bold">Street</li>
                                                            <li class="fw-bold">City/Town</li>
                                                            <li class="fw-bold">Country</li>
                                                            <li class="fw-bold">Province/State</li>
                                                            <li class="fw-bold">Postal/Zip</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <ul>
                                                            <li>Noida</li>
                                                            <li>New Kundle</li>
                                                            <li>India</li>
                                                            <li>Delhi</li>
                                                            <li>110096</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="application-custom-box">
                        <div class="main-review-left">
                            <div class="row students-all-information">
                                <div class="accordion" id="accordionPanelsStayOpenExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="education-headingThree">
                                            <div class="row">
                                                <div class="accordion-button" data-bs-toggle="collapse"
                                                    data-bs-target="#education-collapseThree" aria-expanded="false"
                                                    aria-controls="panelsStayOpen-collapseThree">
                                                    <div class="col-md-5">
                                                        <p class="fs-4">Education:</p>
                                                    </div>
                                                    <div class="col-md-7">
                                                        <p class="fs-4">Bachelors <i
                                                                class="fa-solid fa-graduation-cap"></i></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </h2>
                                        <div id="education-collapseThree" class="accordion-collapse collapse show"
                                            aria-labelledby="education-headingThree">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <ul>
                                                            <li>Country of Education</li>
                                                            <li>Grade</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-7">
                                                        <ul>
                                                            <li>India </li>
                                                            <li>4-Year Bachelors Degree</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <p class="fs-4">Schools Attended</p>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <ul>
                                                            <li class="fw-bold">School Name</li>
                                                            <li class="fw-bold">Level</li>
                                                            <li class="fw-bold">Language</li>
                                                            <li class="fw-bold">Attended From</li>
                                                            <li class="fw-bold">Attended To</li>
                                                            <li class="fw-bold">Address</li>
                                                            <li class="fw-bold">Degree Name</li>
                                                            <li class="fw-bold">Graduated?</li>
                                                            <li class="fw-bold">Certificate Awarded?</li>
                                                            <li class="fw-bold">Graduation Date</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-7">
                                                        <ul>
                                                            <li> 0 </li>
                                                            <li>Doctoral Degree (Phd, M.D., ...)</li>
                                                            <li>English </li>
                                                            <li>2022-Sep-09
                                                            </li>
                                                            <li>2022-Sep-23
                                                            </li>
                                                            <li>Noida,
                                                                Saint Albert,
                                                                Delhi</li>
                                                                                                                            <li>MCA</li>
                                                                                                                                                                                        <li>Yes <i class="fa-solid fa-check"></i></li>
                                                            
                                                                                                                            <li>Yes <i class="fa-solid fa-check"></i></li>
                                                            
                                                            <li>2022-Sep-29
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row students-all-payments">
                                <div class="col-md-4">
                                    <p class="fs-5">Payment:</p>
                                </div>
                                <div class="col-md-8">
                                    <p class="fs-5 text-center opacity-50 ">Not Paid </p>
                                    <p class="fs-5 text-center">Application Fee &nbsp; &nbsp;
                                        <span data-bs-toggle="tooltip" data-bs-placement="top" title=""
                                            data-bs-original-title="Application Fee">1200</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="mt-3 student-profile-review1">

                        <div class="alert alert-warning alert-dismissible fade show fs-5" role="alert">
                            <i class="fa-solid fa-triangle-exclamation"></i> Application will not be processed until
                            payment received. <a href=""> View unpaid applications</a>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>

                        <ul class="bg-white p-3 nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="applicant-tab2" data-bs-toggle="pill"
                                    data-bs-target="#pills-applicant2" type="button" role="tab"
                                    aria-controls="pills-applicant" aria-selected="true"><i class="fa fa-file-text"></i>
                                    Applicant Requirements</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="records-tab2" data-bs-toggle="pill"
                                    data-bs-target="#pills-records2" type="button" role="tab"
                                    aria-controls="pills-records" aria-selected="false"><i
                                        class="fa-solid fa-book-medical"></i> Student Records</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="notes-tab2" data-bs-toggle="pill"
                                    data-bs-target="#pills-notes2" type="button" role="tab"
                                    aria-controls="pills-notes" aria-selected="false"><i
                                        class="fa-solid fa-comments"></i> Notes <!--<div class="css-wyw5m9">1</div>--></button>
                            </li>
                        </ul>


                        <div class="row mt-md-3">
                            <div class="col-md-12">
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-applicant2" role="tabpanel"
                                        aria-labelledby="applicant-tab2">

                                        <div class="row">

                                            <div class="col-md-12">
                                                <div class="download-all-btn">
                                                    <a href="">
                                                        <i class="fa fa-download"></i>
                                                        Download All
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="accordion" id="accordionPanelsStayOpenExample">
                                                    <div class="accordion-item">
                                                        <div class="accordion-header" id="panelsStayOpen-headingOne">
                                                            <div class="accordion-button" data-bs-toggle="collapse"
                                                                data-bs-target="#panelsStayOpen-collapseOne"
                                                                aria-expanded="true"
                                                                aria-controls="panelsStayOpen-collapseOne">
                                                                <div class="left-slide-heading">
                                                                    <h2> Status of Documents </h2>
                                                                    <!-- <h6>Last requirement completed on Jul. 14, 2022</h6> -->
                                                                </div>
                                                                <div class="right-side-content">

                                                                    <div class="stage-card-summary">
                                                                        <div class="css-1lrwgxh">
                                                                            <div class="css-10vh6ur" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Missing 8">
                                                                                <img src="/assetsAgent/img/worning-icon.svg">
                                                                                <!-- <div>0</div> -->
                                                                            </div>
                                                                            <div class="css-1q3p0bj" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Reviewing 0">
                                                                                <img src="/assetsAgent/img/load.svg">
                                                                                <!-- <div>0</div> -->
                                                                            </div>
                                                                            <div class="css-n118i9" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Not Approved 2">
                                                                                <img src="/assetsAgent/img/worng-icon.svg">
                                                                                <!-- <div>0</div> -->
                                                                            </div>
                                                                            <div class="css-epjyqf" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Completed 0">
                                                                                <img src="/assetsAgent/img/check-icon.svg">
                                                                                <!-- <div>3</div> -->
                                                                            </div>
                                                                        </div> 
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="panelsStayOpen-collapseOne"
                                                            class="accordion-collapse collapse show"
                                                            aria-labelledby="panelsStayOpen-headingOne" style="">
                                                            <div class="accordion-body">
                                                                <ul class="acccrodion-list-detalis">
                                                                  
                                                             
                                                                    
                                                                                                                                                                                                                    <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete4">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending4">
                                                                                             <span class="fa fa-check"></span> <div class="css-fke44g">Completed</div>                                                                                        </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Post graduation certificate 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload4"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(4,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess4"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg4"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                                            <img src="https://design.enrolhere.com/agentdoc/69505131/1668856868.jpg" alt="img"
                                                                                                                                                                        width="200" id="uploaddoc4">
                                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                                        <div class="download">
                                                                                                                                                        <a href="https://design.enrolhere.com/agentdoc/69505131/1668856868.jpg" download>
                                                                                                                                                            <i class="fa fa-download"></i>
                                                                                                                                                        </a>
                                                                                                                                                    </div>
                                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete5">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending5">
                                                                                             <span class="fa fa-check"></span> <div class="css-fke44g">Completed</div>                                                                                        </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Graduation transcript 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload5"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(5,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess5"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg5"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                                            <img src="https://design.enrolhere.com/agentdoc/69505131/1668605602.jpg" alt="img"
                                                                                                                                                                        width="200" id="uploaddoc5">
                                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                                        <div class="download">
                                                                                                                                                        <a href="https://design.enrolhere.com/agentdoc/69505131/1668605602.jpg" download>
                                                                                                                                                            <i class="fa fa-download"></i>
                                                                                                                                                        </a>
                                                                                                                                                    </div>
                                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete6">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending6">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Post graduation transcript 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload6"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(6,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess6"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg6"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete7">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending7">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            IELTS score certificate 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload7"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(7,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess7"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg7"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete8">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending8">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Experience certificate 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload8"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(8,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess8"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg8"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete9">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending9">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Migration certificate 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload9"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(9,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess9"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg9"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete10">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending10">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Backlog certificate 
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload10"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(10,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess10"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg10"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete11">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending11">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Consent form
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload11"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(11,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess11"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg11"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete12">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending12">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            CV
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                                <input type="hidden" name="_token" value="q9Yr7BOezNMf50pUWfOLh1ody8e2pkdzfcJlu4dH">                                                                        
                                                                      
                                                                            <li>
                                                                                <div role="listitem" class="css-rbi7dp">
                                                                                                                                                                            <div class="css-required">
                                                                                            <div>
                                                                                                <span>Required</span>
                                                                                            </div>
                                                                                        </div>
                                                                                                                                                                        
                                                                                    <div class="css-1lp81ux">
                                                                                        <div class="css-1p0j8nq" style="display: none"
                                                                                            id="complete13">
                                                                                            <span
                                                                                                class="fa fa-check"></span>
                                                                                            <div
                                                                                                class="css-fke44g">
                                                                                                Completed
                                                                                            </div>
                                                                                        </div> 
                                                                                    </div>




                                                                                    <div class="css-1lp81ux">
                                                                                                                                                                                <div class="css-1p0j8nq"
                                                                                            id="pending13">
                                                                                            <span class="fa fa-info-circle" style="color: #FFC72D"></span> <div class="css-fke44g" style="color: #FFC72D">Pending</div>                                                                                         </div>
                                                                                                                                                                            </div>


                                                                                    <div class="css-sohti2">
                                                                                        <div
                                                                                            class="MuiBox-root jss208 sc-dkzDqf jlXQtr">
                                                                                            <div
                                                                                                class="MuiBox-root jss209 sc-dkzDqf jlXQtr css-1iwe4pm">
                                                                                                <div class="css-green">
                                                                                                    


                                                                                                </div>
                                                                                                <div class="css-k28thh">
                                                                                                    <span
                                                                                                        class="title-date">
                                                                                                        <span
                                                                                                            class="requirement-title">
                                                                                                            <div
                                                                                                                class="react_component_tooltip place-top type-dark">
                                                                                                            </div>
                                                                                                            Additional certificate
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <div
                                                                                                        class="req-desc css-lsgy9k">
                                                                                                        <div
                                                                                                            class="wrapped-content">
                                                                                                            <p>For Indian applicants who completed Grade 12 in Central Board of Secondary Education (CBSE), please be advised that EACH of below is required for admission to this program:
                                                                                                            </p>

                                                                                                        </div>
                                                                                                                                                                                                                    <div
                                                                                                                class="req-desc css-lsgy9k">
                                                                                                                <div
                                                                                                                    class="wrapped-content-upload">
                                                                                                                    <p>Please
                                                                                                                        provide
                                                                                                                        a
                                                                                                                        clear
                                                                                                                        and
                                                                                                                        legible
                                                                                                                        photocopy
                                                                                                                        of
                                                                                                                        the
                                                                                                                        applicant's
                                                                                                                        certificate
                                                                                                                        which
                                                                                                                        meets
                                                                                                                        the
                                                                                                                        following
                                                                                                                        requirements:
                                                                                                                    </p>
                                                                                                                    <ul>
                                                                                                                        <li>The
                                                                                                                            acceptable
                                                                                                                            formats
                                                                                                                            of
                                                                                                                            the
                                                                                                                            photocopy
                                                                                                                            are
                                                                                                                            .PDF,
                                                                                                                            .JPEG
                                                                                                                            or
                                                                                                                            .PNG
                                                                                                                        </li>
                                                                                                                        <li>The
                                                                                                                            photocopy
                                                                                                                            needs
                                                                                                                            to
                                                                                                                            be
                                                                                                                            entire
                                                                                                                            with
                                                                                                                            no
                                                                                                                            cut-off
                                                                                                                            at
                                                                                                                            the
                                                                                                                            edges
                                                                                                                        </li>
                                                                                                                    </ul>
                                                                                                                    <p>Please
                                                                                                                        be
                                                                                                                        advised
                                                                                                                        that
                                                                                                                        the
                                                                                                                        file
                                                                                                                        size
                                                                                                                        limit
                                                                                                                        of
                                                                                                                        the
                                                                                                                        photocopy
                                                                                                                        is
                                                                                                                        20MB.
                                                                                                                    </p>

                                                                                                                    <div class="attached-documents">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-4">
                                                                                                                                <p>Attached Documents :
                                                                                                                                </p>
                                                                                                                            </div>
                                                                                                                            <div class="col-md-8">
                                                                                                                                <div
                                                                                                                                    class="dowonload-icon-btn d-flex">
                                                                                                                                    <div
                                                                                                                                        class="form-group">
                                                                                                                                        <input
                                                                                                                                            type="file"
                                                                                                                                            id="img-upload13"
                                                                                                                                            class="form-control fileupload"
                                                                                                                                            onchange="docupload(13,2,69505131);">
                                                                                                                                        <span
                                                                                                                                            id="suceess13"
                                                                                                                                            style="color:green"></span><br />
                                                                                                                                        <span
                                                                                                                                            id="msg13"
                                                                                                                                            style="color:green"></span><br />

                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                    </div>

                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                    
                                                                                                                      
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        
                                                                                                        <div
                                                                                                            class="css-see-less">
                                                                                                            <p>See Less
                                                                                                                <span class="fa fa-caret-up"></span>
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>


                                                                                        </div>
                                                                                    </div>


                                                                                </div>
                                                                            </li>
                                                                                                                                            

                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="tab-pane fade" id="pills-records2" role="tabpanel"
                                        aria-labelledby="records-tab2">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="main-timeline">
                                                                                                                                                            <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Dis Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document DisApproved Comment registered by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Application Cancelled</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/> Application Cancelled by Admin</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 19 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 18 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 17 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Graduation transcript updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Graduation transcript  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Graduation transcript updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Graduation transcript  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 16 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 15 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Disapproved</li>
                                                                <li class="date"> 15 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Disapproved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 15 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (5)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Document Approved</li>
                                                                <li class="date"> 15 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Document Approved by Admin (4)</p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate updated</li>
                                                                <li class="date"> 14 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate  updated successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Graduation transcript  uploaded</li>
                                                                <li class="date"> 12 Nov, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Graduation transcript   uploaded successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Post graduation certificate  uploaded</li>
                                                                <li class="date"> 22 Oct, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Post graduation certificate   uploaded successfully </p>
                                                        </a>
                                                    </div>
                                                                                                        <div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Program Apply</li>
                                                                <li class="date"> 21 Oct, 2022 </li>
                                                            </ul>
                                                            <p class="description"><br/>Program apply by </p>
                                                        </a>
                                                    </div>
                                                                                                        

                                                    <!--<div class="timeline">
                                                        <a href="#" class="timeline-content">
                                                            <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                                            <ul>
                                                                <li class="title">Application Opened</li>
                                                                <li class="date">24 May, 2022</li>
                                                            </ul>
                                                            <p class="description">As you progress through the application
                                                                process, you will see documents provided by ApplyBoard here.
                                                                These could come in the form of questions, documents,
                                                                payments, invoices, and application statuses.</p>
                                                        </a>
                                                    </div>-->
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pills-notes2" role="tabpanel"
                                        aria-labelledby="notes-tab2">
                                        <form id="frmnote">
                                        <div class="bg-white p-3">
                                            <div id="error"></div>
                                            <div id="success"></div>
                                            <div class="textarea-custom-slide">
                                                <div class="form-group">
                                                    <!--<input type="text" name="notes_title" id="notes_title" class="form-control"-->
                                                    <!--    placeholder="Enter title here....">-->
                                                        
                                                    <input type="text" name="editor1" id="notes_title" class="form-control"
                                                        placeholder="Enter title here....">
                                                </div>
                                            </div>
                                            <input type="hidden" name="student_id" id="student_id" value="28">
                                            <input type="hidden" name="appid" id="appid" value="69505131">
                                            <!--<textarea  name="notes" id="notes" class="post-area"> </textarea><br/>-->
                                            <button type="button" class="btn btn-primary" id="msg" onclick="notesSave();">Save</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        #img-upload_pass {
            font-weight: bold;
            color: var(--color);
            height: 2.5em;
            border-radius: 3px;
        }
        .breadcrumb-item.active {
            font-size: 14px;
        }
        .breadcrumb-item{
            color:#2a50ed;
        }
    </style>
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <p>© Enrollhere 2022 All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
            </footer>

        </div>

        <!-- END layout-wrapper -->

        <div class="shadow-md">
            <div class="color_change">Color Scheme</div>
            <ul class="plaette-colors">
                <li class="color-layout" id="blue" data-color="#2a50ed"></li>
                <li class="color-layout" id="yellow" data-color="#064e3b"></li>
                <li class="color-layout" id="dark-green" data-color="#164e63"></li>
                <li class="color-layout" id="green" data-color="#312e81"></li>
            </ul>
        </div>

        <div class="shadow-md1">
            <div class="heading-dark">Dark Mode</div>
            <label class="switch">
                <input type="checkbox" class="checkbox" id="checkbox">
                <span class="slider"></span>
            </label>
        </div>
        <script>
            var base_path = 'https://design.enrolhere.com';
        </script>
        

        <!-- Javascript -->
        <script src="https://design.enrolhere.com/assetsAgent/js/jquery.min.js"></script>
        <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.3.2/ckeditor.js"></script>-->
        
        <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/chosen.jquery.min.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/moment.min.js"></script>
         
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/daterangepicker.min.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/litepicker.js"></script>--> 

        <!--<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.min.js"></script>-->
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <script src="https://cdn.jsdelivr.net/npm/vue-apexcharts"></script>

        <script src="https://design.enrolhere.com/assetsAgent/js/bootstrap.bundle.min.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/metisMenu.min.js"></script> 
        <script src="https://design.enrolhere.com/assetsAgent/js/simplebar.min.js"></script>
        
        <script src="https://cdn.rawgit.com/mdehoog/Semantic-UI/6e6d051d47b598ebab05857545f242caf2b4b48c/dist/semantic.min.js"></script>

        <script src="https://design.enrolhere.com/assetsAgent/js/waves.min.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/jquery.fancybox.min.js"></script>
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/apexcharts.min.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/canvasjs.min.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/chart.js"></script>-->

        <script src="https://design.enrolhere.com/assetsAgent/js/select2.min.js"></script>
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/ecommerce-select2.init.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/dashboard.init.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/ion.rangeSlider.min.js"></script>-->
        <!--<script src="https://design.enrolhere.com/assetsAgent/js/range-sliders.init.js"></script>-->
        
        <!--<script src="https://code.jscharting.com/latest/jscharting.js"></script>-->

        <!-- Main js -->
        <script src="https://design.enrolhere.com/assetsAgent/js/app.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/main.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/custom.js"></script>
        <script src="https://design.enrolhere.com/assetsAgent/js/agent_custom.js"></script>
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            $('body').on('click','#rzp-button1',function(e){
                e.preventDefault();
                var amount = $('.amount').val();
                var email = $('.email').val();
                var mobile = $('.mobile').val();
                var disc = $('.disc').val();
                var appid = $('.appid').val();
                var name = $('.name').val();
                var note = $('.note').val();
                var student_id = $('.sid').val();
                var amount = $('.amount').val();
                var total_amount = amount * 100;
                var options = {
                    "key": "rzp_test_SfRD9LWPD2CAoj", // Enter the Key ID generated from the Dashboard
                    "amount": total_amount, // Amount is in currency subunits. Default currency is INR. Hence, 10 refers to 1000 paise
                    "currency": "INR",
                    "name": name,
                    "description": disc,
                    "image": "https://design.enrolhere.com/mainAssets/assets/img/sdasdad.png",
                    "order_id": "", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                    "handler": function (response){
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type:'POST',
                            url:"https://design.enrolhere.com/payment",
                            data:{razorpay_payment_id:response.razorpay_payment_id,amount:amount,student_id:student_id,appid:appid,disc:disc},
                            success:function(data){
                                if(data.success =='paid'){
                                    $('.success-message').html('<span class="alert alert-success">Thank You ! Your application fees paid successfully</span>');   
            
                                }else
                                {
                                    $('.danger-message').html('<span class="alert alert-danger ">OOPS ! Your application fees payment failed, Please try again</span>');    
                                }
                                setTimeout(function(){
                                window.location.reload(); 
                                },5000); 




                            }
                        });
                    },
                    "prefill": {
                        "name": name,
                        "email": email,
                        "contact": mobile
                    },
                    "notes": {
                        "address": note
                    },
                    "theme": {
                        "color": "#F37254"
                    }
                };
                var rzp1 = new Razorpay(options);
                rzp1.open();
            });
      
            // click body js 
            const checkbox = document.getElementById('checkbox');

            checkbox.addEventListener('change', () => {
                document.body.classList.toggle('dark');
            });

            $(".gallery-list a").fancybox();
            
            $(function() {
                $("#datepicker").datepicker();
            });
            
    
            var _seed = 42;
            Math.random = function() {
                _seed = _seed * 16807 % 2147483647;
                return (_seed - 1) / 2147483646;
            };
            
            const ctxdd = document.getElementById('myChartsdsd');
            new Chart(ctxdd, {
                type: 'pie',
                data: {
                  labels: [
                        '1-Year Post-Secondary Certificate',
                        '2-Year Undergraduate Diploma',
                        'Grade 12'
                      ],
                  datasets: [{
                        // label: 'My First Dataset',
                        data: [300, 50, 100],
                        backgroundColor: [
                          'rgb(255, 99, 132)',
                          'rgb(54, 162, 235)',
                          'rgb(255, 205, 86)'
                        ],
                        hoverOffset: 4
                      }]
                }
              });
            

            
            $(document).ready(function() {
                let data = {
                    dataValues: [
                        [5],
                        [1, 2, 3, 4, 5, 6, 7],
                        [1, 2, 3, 4, 5, 6, 7],
                        [2],
                        [1, 2, 3, 4, 5, 6, 7, 8, 9],
                        [1, 2, 3, 4, 5, 6],
                        [2, 2],
                        [2],
                        [],
                        [],
                        [],
                        [],
                    ],
                    legend: [],
                    legendColors: ["#2a50ed", "#3A458D", "#2a50ed", "#F06370", "#FBB652", "#F06370", "#3A458D", "#3A458D", "#3A458D"],
                    barLabels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    labelColors: ["#444", "#444", "#444", "#444"]
                };
            
                let options = {
                    chartWidth: "60%",
                    chartHeight: "60%",
                    chartTitle: "",
                    chartTitleColor: "black",
                    chartTitleFontSize: "2rem",
                    yAxisTitle: "",
                    xAxisTitle: "",
                    barValuePosition: "center",
                    barSpacing: "1%"
                };
            
                let element = "#testDiv";
            
                drawBarChart(data, options, element);
            
                function drawBarChart(data, options, element) {
                    drawChartContainer(element);
                    drawChartTitle(options);
                    drawChartLegend(data);
                    drawYAxisTitle(options);
                    drawYAxis(data);
                    drawChartGrid(data, options);
                    drawXAxis(data, options);
                    drawXAxisTitle(options);
                }
            
                function drawChartContainer(element) {
                    $(element).prepend("<div class='chartContainer'></div>");
                    $(element).css("height", "100%");
                }
            
                function drawChartTitle(options) {
                    $(".chartContainer").append("<div class='chartTitle'>" + options.chartTitle + "</div>");
                    $(".chartTitle").css("color", options.chartTitleColor);
                    $(".chartTitle").css("font-size", options.chartTitleFontSize);
                }
            
                function drawChartLegend(data) {
                    $(".chartContainer").append("<div class='chartLegend'></div>");
                    for (let i = 0; i < data.legend.length; i++) {
                        $(".chartLegend").append("<div class='legendKey legendKey" + i + "'></div>");
                        $(".legendKey" + i).css("background-color", data.legendColors[i]);
                        $(".chartLegend").append("<span>" + data.legend[i] + "</span>");
                    }
                }
            
                function drawYAxisTitle(options) {
                    $(".chartContainer").append("<div class='yAxisTitle'>" + options.yAxisTitle + "</div>");
                }
            
                function drawYAxis(data) {
                    $(".chartContainer").append("<div class='yAxis'></div>");
                    let maximum = maxScale(tallestBar(data));
                    let order = Math.floor(Math.log(maximum) / Math.LN10 +
                        0.000000001);
                    for (let i = 1; i > 0; i = i - 0.2) {
                        if (order < 0) {
                            $(".yAxis").append("<div class='yAxisLabel'>" + (maximum * i).toFixed(Math.abs(order - 1)) + "</div>");
                        } else {
                            $(".yAxis").append("<div class='yAxisLabel'>" + (maximum * i).toFixed(0) + "</div>");
                        }
                    }
                }
            
                function tallestBar(data) {
                    let sum = 0;
                    for (let i = 0; i < data.dataValues.length; i++) {
                        let sumArray = data.dataValues[i].reduce((a, b) => a + b, 0);
                        if (sumArray > sum) {
                            sum = sumArray;
                        }
                        return sum;
                    }
                }
            
                function maxScale(n) {
                    let order = Math.floor(Math.log(n) / Math.LN10 + 0.000000001); // 2
                    let multiple = Math.pow(10, order);
                    let result = Math.ceil(n * 1.1 / multiple) * multiple;
                    if (order > 0) {
                        return result;
                    } else if (order == 0) {
                        return result.toFixed(1);
                    } else {
                        return result.toFixed(Math.abs(order));
                    }
                }
            
                function drawChartGrid(data, options) {
                    $(".chartContainer").append("<div class='chartGrid'></div>");
            
                    let maximum = maxScale(tallestBar(data));
            
                    let barWidth = 100 / (data.dataValues.length + 2);
            
                    for (let i = 0; i < data.dataValues.length; i++) {
                        $(".chartGrid").append("<div class='bar bar" + i + "'></div>");
                        $(".bar" + i).css("height", "100%");
                        $(".bar" + i).css("width", barWidth + "%");
                        for (let j = 0; j < data.dataValues[i].length; j++) {
            
                            if (data.dataValues[i][j]) {
                                $(".bar" + i).prepend("<div class='innerBar innerBar" + i + j + "'></div");
            
                                let height = data.dataValues[i][j] / maximum * 100;
                                $(".innerBar" + i + j).css("height", height + "%");
                                $(".innerBar" + i + j).css("background-color", data.legendColors[j]);
                                $(".innerBar" + i + j).append("<p class='barValue'>" + data.dataValues[i][j] + "</p>");
                                $(".barValue").css("align-self", options.barValuePosition);
                                $(".barValue").css("margin", "0");
                            }
                        }
                    }
                    $(".bar").css("margin", "0 " + options.barSpacing);
                }
            
                function drawXAxis(data, options) {
                    $(".chartContainer").append("<div class='emptyBox'></div>");
                    $(".chartContainer").append("<div class='xAxis'></div>");
            
                    let barWidth = 100 / (data.barLabels.length + 2);
            
                    for (let i = 0; i < data.barLabels.length; i++) {
                        $(".xAxis").append("<div class='xAxisLabel xAxisLabel" + i + "'>" + data.barLabels[i] + "</div>");
                        $(".xAxisLabel").css("width", barWidth + "%");
                        $(".xAxisLabel" + i).css("color", data.labelColors[i]);
                    }
            
                    $(".xAxisLabel").css("margin", "0 " + options.barSpacing);
                }
            
                function drawXAxisTitle(options) {
                    $(".chartContainer").append("<div class='xAxisTitle'>" + options.xAxisTitle + "</div>");
                }
                
                $("#about_us > div.col-md-8 > div > div.bg-white.p-3.mt-3 > p").addClass("fs-4")
                $("#about_us > div.col-md-8 > div > div.bg-white.p-3.mt-3 > ul li").addClass("fs-4").css("line-height", "1.4285em")
                $("#about_us > div.col-md-8 > div > div.bg-white.p-3.mt-3 > p:nth-child(3)").remove();
                $("#about_us > div.col-md-8 > div > div.bg-white.p-3.mt-3 > p:nth-child(4)").remove();
                $("#about_us > div.col-md-8 > div > div.bg-white.p-3.mt-3 > p:nth-child(6)").remove();
                
                // $(".avatar .avatar-img").on("error", function(){
                //     $(this).attr('src', 'https://via.placeholder.com/56');
                // });
                
                // const imgas = document.querySelector("#school > div > div > div > div.avatar > a > img");
                

                // imgas.addEventListener('error', function handleError() {
                //   const defaultImage =
                //     'https://bobbyhadz.com/images/blog/javascript-show-div-on-select-option/banner.webp';
                
                //   imgas.src = defaultImage;
                //   imgas.alt = 'default';
                // });

            
            });
        </script>
        
        
      

</body>

</html>
