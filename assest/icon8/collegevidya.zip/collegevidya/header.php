<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <!-- Title -->
    <title>Education Employability Employment</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Google Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900&amp;display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/custum.scss">
    <link rel="stylesheet" href="assets/css/responive.css">
    <link rel="stylesheet" href="assets/css/main.css">
    


</head>

<body>

    <div class="as-header header-layout">
        <div class="top-area background-image">
            <div class="header-top">
                <div class="container">
                    <div class="row justify-content-center justify-content-md-between align-items-center ">
                        <div class="col-12 text-center">
                            <p class="header-notice">Welcome to Education Employability Employment</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <!--<nav class="navbar navbar-expand-sm navbar-light bg-light " style="height: 65px;">
            <div class="container ">
                <a class="navbar-brand ms-5" href="index.php">
                    <img src="assets\img\logo-design.png" class="img-fluid" height="70" width="90" alt="">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class=" collapse d-flex main-menu " id="navbarSupportedContent">
                    <ul id="menu-main-menu-1" class="">
                        <li><a href="index.php">Home</a></li>
                        <li class="menu-item-has-children">
                            <a href="#">PG Course</a>
                            <ul class="sub-menu">
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance MBA </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance MCA </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance M.Sc</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance MA</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">M Tech for
                                        Working Professionals </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance M.Com </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online
                                        Executive MBA (1 Year)</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Suggest
                                        University in 2 mins</a>
                                </li>
                                <li class="menu-item">
                                    <a href="">View all</a>
                                </li>

                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href=""> Verify Your University</a>
                                </li>
                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href=""> Why DDD?</a>
                                </li>
                            </ul>
                        </li>

                        <li class="menu-item-has-children">
                            <a href="#">UG Course </a>
                            <ul class="sub-menu">
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">B Tech for
                                        Working Professionals</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance BCA</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance BBA</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Online &
                                        Distance BA</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php"> Online &
                                        Distance B.Com </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Suggest
                                        University in 2 mins </a>
                                </li>

                                <li class="menu-item">
                                    <a href="">View all</a>
                                </li>

                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href="">Verify Your University</a>
                                </li>
                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href=""> Why DDD?</a>
                                </li>
                            </ul>
                        </li>

                        <li class="menu-item-has-children">
                            <a href="#">Diploma </a>
                            <ul class="sub-menu">
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Diploma
                                        Programs </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Certificate
                                        Programs </a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">CMS & ED</a>
                                </li>
                                <li class="menu-item">
                                    <a href="b-tech-for-working-professionals.php">Suggest
                                        University in 2 mins </a>
                                </li>
                                <li class="menu-item">
                                    <a href="">View all</a>
                                </li>

                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href=""> Verify Your University</a>
                                </li>
                                <li class="menu-item" style="background-color:#f0f8ff;">
                                    <a href="">Why DDD?</a>
                                </li>
                            </ul>
                        </li>

                        <li class="menu-item-has-children">
                            <a href="#">More </a>
                            <ul class="sub-menu">
                                <li class="menu-item">
                                    <a href="our-trust.php"><i class="fa-solid fa-shield-halved"></i> Commitment
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-shield-halved"></i>
                                        Important Facts </a>
                                </li>
                                <li class="menu-item">
                                    <a href="verify-university.php"><i class="fa-solid fa-arrow-right"></i> Verify Your
                                        University</a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-question"></i> Why DDD?</a>
                                </li>
                                <li class="menu-item">
                                    <a href="mailto:info@ddd.com"><i class="fa-solid fa-envelope"></i> Info@ddd.com</a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-address-card"></i> Contact
                                        Us</a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-circle-exclamation"></i>
                                        About Us</a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-book"></i> Our Policy</a>
                                </li>
                                <li class="menu-item">
                                    <a href=""><i class="fa-solid fa-users"></i> Meet the
                                        Team</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <div class="col-auto  d-xl-block">
                                <div class="header-button">

                                    <div class="read-more suggest-btn d-sm-inline-block">
                                        <span>New</span>
                                        <a href="suggest-me-an-university.php">
                                            <img src="assets/img/icon/badge.svg" class="img-fluid" alt="">
                                            Suggest University in 2 mins
                                        </a>
                                    </div>

                                    <div class="read-more top-universities d-sm-inline-block">
                                        <a href="">
                                            <img src="assets/img/icon/header-circle.svg" class="img-fluid" alt="">
                                            Top Universities
                                        </a>
                                    </div>


                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="col-auto  d-xl-block">
                                <div class="header-button">

                                    <div class="read-more suggest-btn d-sm-inline-block">
                                    <button class="btn btn-outline-primary mt-2" type="button">Sign in</button>
                                    </div>

                                    <div class="read-more top-universities d-sm-inline-block mt-2">
                                    <span class=" search-icon"><i class="fa-solid fa-magnifying-glass"></i></span>

                                    </div>


                                </div>
                            </div>
                            
                            
                        </li>
                    </ul>


                </div>
            </div>
        </nav>
            -->

        <div class="sticky-wrapper">
            <div class="sticky-active">
                <div class="menu-area">

                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-3">
                                <div class="header-logo text-center">
                                    <a href="index.php">
                                        <img src="assets\img\logo-design.png" class="img-fluid" height="50" width="90"
                                            alt="">

                                    </a>
                                </div>
                            </div>
                            <div class="col-9">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-auto">
                                        <nav class="main-menu d-none d-lg-inline-block">
                                            <ul id="menu-main-menu-1" class="">
                                                <li><a href="index.php">Home</a></li>
                                                <li class="menu-item-has-children">
                                                    <a href="#">PG Course</a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance MBA </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance MCA </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance M.Sc</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance MA</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">M Tech for
                                                                Working Professionals </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance M.Com </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online
                                                                Executive MBA (1 Year)</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Suggest
                                                                University in 2 mins</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="">View all</a>
                                                        </li>

                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href=""> Verify Your University</a>
                                                        </li>
                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href=""> Why DDD?</a>
                                                        </li>
                                                    </ul>
                                                </li>

                                                <li class="menu-item-has-children">
                                                    <a href="#">UG Course </a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">B Tech for
                                                                Working Professionals</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance BCA</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance BBA</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Online &
                                                                Distance BA</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php"> Online &
                                                                Distance B.Com </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Suggest
                                                                University in 2 mins </a>
                                                        </li>

                                                        <li class="menu-item">
                                                            <a href="">View all</a>
                                                        </li>

                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href="">Verify Your University</a>
                                                        </li>
                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href=""> Why DDD?</a>
                                                        </li>
                                                    </ul>
                                                </li>

                                                <li class="menu-item-has-children">
                                                    <a href="#">Diploma </a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Diploma
                                                                Programs </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Certificate
                                                                Programs </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">CMS & ED</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="b-tech-for-working-professionals.php">Suggest
                                                                University in 2 mins </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="">View all</a>
                                                        </li>

                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href=""> Verify Your University</a>
                                                        </li>
                                                        <li class="menu-item" style="background-color:#f0f8ff;">
                                                            <a href="">Why DDD?</a>
                                                        </li>
                                                    </ul>
                                                </li>

                                                <li class="menu-item-has-children">
                                                    <a href="#">More </a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item">
                                                            <a href="our-trust.php"><i
                                                                    class="fa-solid fa-shield-halved"></i> Commitment
                                                            </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-shield-halved"></i>
                                                                Important Facts </a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="verify-university.php"><i
                                                                    class="fa-solid fa-arrow-right"></i> Verify Your
                                                                University</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-question"></i> Why DDD?</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href="mailto:info@ddd.com"><i
                                                                    class="fa-solid fa-envelope"></i> Info@ddd.com</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-address-card"></i> Contact
                                                                Us</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-circle-exclamation"></i>
                                                                About Us</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-book"></i> Our Policy</a>
                                                        </li>
                                                        <li class="menu-item">
                                                            <a href=""><i class="fa-solid fa-users"></i> Meet the
                                                                Team</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <div class="col-auto  d-xl-block">
                                                        <div class="header-button">

                                                            <div class="read-more suggest-btn d-sm-inline-block">
                                                                <span>New</span>
                                                                <a href="suggest-me-an-university.php">
                                                                    <img src="assets/img/icon/badge.svg"
                                                                        class="img-fluid" alt="">
                                                                    Suggest University in 2 mins
                                                                </a>
                                                            </div>

                                                            <div class="read-more top-universities d-sm-inline-block">
                                                                <a href="">
                                                                    <img src="assets/img/icon/header-circle.svg"
                                                                        class="img-fluid" alt="">
                                                                    Top Universities
                                                                </a>
                                                            </div>
                                                            <button type="button"
                                                                class="icon-btn style2 searchBoxToggler">
                                                                <i class="fa-solid fa-magnifying-glass"></i>
                                                            </button>

                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="col-auto  d-xl-block">
                                                        <div class="header-button">

                                                            <div class="read-more suggest-btn d-sm-inline-block">
                                                                <button class="btn btn-outline-primary mt-2"
                                                                    type="button" data-bs-toggle="modal"
                                                                    data-bs-target="#myModalsign">Sign in</button>
                                                            </div>

                                                            <div
                                                                class="read-more top-universities d-sm-inline-block mt-2">
                                                                <span class=" search-icon" data-bs-toggle="modal"
                                                                    data-bs-target="#myModalsearch"><i
                                                                        class="fa-solid fa-magnifying-glass"></i></span>

                                                            </div>


                                                        </div>
                                                    </div>


                                                </li>
                                            </ul>
                                        </nav>
                                        <button type="button" class="as-menu-toggle d-inline-block d-lg-none">
                                            <i class="fa-solid fa-bars"></i>
                                        </button>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logo-shape"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="popup-search-box d-none d-lg-block">
        <button class="searchClose border-theme text-theme">
            <i class="fa-sharp fa-solid fa-xmark"></i>
        </button>
        
    </div>

    <?php include('header-modal.php') ?>
    
    <main id="content">