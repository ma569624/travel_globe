<!-- The Modal -->
<div class="modal fade" id="myModalsign"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered ">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header border-0">

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-12">
                                <h4>
                                    To sign in, <br>
                                    please enter your mobile number
                                </h4>
                            </div>
                            <div class="row text-center mt-2">
                                <p>
                                    First time User? <a href="#" class="text-primary" data-bs-toggle="modal"
                                        data-bs-target="#myModalsignnew">Sign</a>
                                </p>
                            </div>
                            <div class="col-xl-12">
                                <input type="number" class="form-control" id="mobilenumber" placeholder="">
                            </div>
                            <div class="col-xl-12 mt-3 text-center">
                                <a href="verification-otp.php" type="submit" class="btn btn-primary mb-3">Send OTP</a>
                            </div>
                            <div class="col-xl-12 my-2 text-center">
                                <span class="badge bg-light text-dark"> Your personal information is secure with
                                    us</span>
                            </div>

                        </div>
                    </div>


                </div>



            </div>
        </div>
    </div>

    <div class="modal fade" id="myModalsignnew">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header border-0">

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-12">
                                <h4>
                                    To sign in, <br>
                                    please enter your mobile number
                                </h4>
                            </div>
                            <div class="row text-center mt-2">
                                <p>
                                    Already a User? <a href="" class="text-primary" data-bs-toggle="modal"
                                        data-bs-target="#myModalsign">Sign</a>
                                </p>
                            </div>


                            <form action="">
                                <div class="row text-center">
                                    <div class="col-auto">
                                        <input class="form-check-input" type="radio" name="flexRadioDefault"
                                            id="flexRadioDefault1" checked>
                                        <label class="form-check-label" for="flexRadioDefault1">
                                            Male
                                        </label>
                                    </div>
                                    <div class="col-auto">
                                        <input class="form-check-input" type="radio" name="flexRadioDefault"
                                            id="flexRadioDefault2">
                                        <label class="form-check-label" for="flexRadioDefault2">
                                            Female
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-3 mt-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="email" placeholder="Enter Your Name"
                                        name="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="DATE" class="form-label">Date of Birth</label>
                                    <input type="Date" class="form-control" id="pwd" placeholder="Enter password"
                                        name="pswd" required>
                                </div>
                                <div class="mb-3 mt-3">
                                    <label for="number" class="form-label">Number</label>
                                    <input type="number" class="form-control" id="email"
                                        placeholder="Enter Your Mobile Number" name="email" required>
                                </div>
                                <div class="mb-3 mt-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="Enter Your Email"
                                        name="email" required>
                                </div>

                                <div class="form-group mb-3 mt-3">
                                    <label for="email" class="form-label">Course</label>
                                    <select class="form-control" name="city" required="">
                                        <option selected="" disabled="" value="">Select A Course </option>
                                        <option value="MBA">MBA</option>
                                        <option value="MCA">MCA</option>
                                        <option value="BBA">BBA</option>
                                        <option value="BCA">BCA</option>
                                        <option value="B.COM">B.COM</option>
                                        <option value="B.TECH">B.TECH</option>
                                        <option value="B.A">B.A</option>
                                        <option value="B.ED">B.ED</option>

                                    </select>
                                </div>

                                <div class="form-group mb-5 mt-3">
                                    <label for="email" class="form-label">State</label>
                                    <select class="form-control" name="city" required="">
                                        <option selected="" disabled="" value="">Select State </option>
                                        <option value="Delhi">Delhi</option>
                                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                                        <option value="Uttarakhand">Uttarakhand</option>
                                        <option value="West Bengal">West Bengal</option>
                                        <option value="Punjab">Punjab</option>
                                        <option value="Rajasthan">Rajasthan</option>
                                        <option value="Sikkim">Sikkim</option>
                                        <option value="Tamil Nadu">Tamil Nadu</option>
                                        <option value="Telangana">Telangana</option>
                                        <option value="Tripura">Tripura</option>
                                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                        <option value="Assam">Assam</option>
                                        <option value="Bihar">Bihar</option>
                                        <option value="Chandigarh">Chandigarh</option>
                                        <option value="Chhattisgarh">Chhattisgarh</option>
                                        <option value="Goa">Goa</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="Haryana">Haryana</option>
                                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                                        <option value="Jammu &amp; Kashmir">Jammu &amp; Kashmir</option>
                                        <option value="Jharkhand">Jharkhand</option>
                                        <option value="Karnataka">Karnataka</option>
                                        <option value="Kerala">Kerala</option>
                                        <option value="Lakshadweep">Lakshadweep</option>
                                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                                        <option value="Maharashtra">Maharashtra</option>
                                        <option value="Manipur">Manipur</option>
                                        <option value="Meghalaya">Meghalaya</option>
                                        <option value="Mizoram">Mizoram</option>
                                        <option value="Nagaland">Nagaland</option>
                                        <option value="Orissa">Orissa</option>
                                        <option value="Puducherry">Puducherry</option>
                                        <option value="Andaman &amp; Nicobar Islands">Andaman &amp; Nicobar Islands
                                        </option>
                                        <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                                        <option value="Daman and Diu">Daman and Diu</option>
                                        <option value="Ladakh">Ladakh</option>
                                    </select>
                                </div>

                                <div class="row my-2">
                                    <button type="submit" class="btn btn-primary">Send OTP</button>
                                </div>

                                <div class="col-xl-12 mt-4 mb-2 text-center">
                                    <span class="badge bg-info text-dark"> Your personal information is secure with
                                        us</span>
                                </div>

                                <div class="col-xl-12 mb-4 text-center">
                                    <h6>By clicking, you agree to our <a href="#" class="text-primary">Privacy Policy,
                                            Terms of Use</a>& Disclaimers <p>(Standard T&C Apply)</p>
                                    </h6>
                                </div>


                            </form>




                        </div>
                    </div>

                    <!-- end row -->
                </div>



            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="myModalsearch">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header border-0 p-5">

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body m-5">
                    <div class="container">
                        <div class="row text-center">

                            <h2 class="text-primary">Education Emplotability Emptloyment</h2>
                            <h4>#Righttoselect</h4>
                            <div class="mx-auto col-md-6 my-3">
                                <input type="email" class="form-control" id="exampleFormControlInput1"
                                    placeholder="Type Here....">
                            </div>

                            <div class="row">
                            <div class="mx-auto col-md-6 my-3">
                                <p>Trending Searches...</p>
                                <div class="d-flex flex-row justify-content-center gap-2" style="flex-wrap: wrap;">

                                    <div class="items">
                                        <a class="" href="b-tech-for-working-professionals.php">
                                            <div class="card course_content tab-item">
                                                <img class="card-img pt-2 rounded-circle" height="25" weight="25"
                                                    src="assets/img/mba_svg.svg" alt="Card image">
                                                <div class="card-body p-1">
                                                    <h4 class="card-title">MBA</h4>


                                                </div>
                                                <p class="card-text">Compare 43 Universities</p>
                                            </div>
                                        </a>

                                    </div>
                                    <div class="items">

                                        <a class="" href="b-tech-for-working-professionals.php">
                                            <div class="card course_content tab-item">
                                                <img class="card-img pt-2" height="25" weight="25"
                                                    src="assets\img\tab-icon\mca.svg" alt="Card image">
                                                <div class="card-body p-1">
                                                    <h4 class="card-title">MCA</h4>


                                                </div>
                                                <p class="card-text">Compare 13 Universities</p>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="items">
                                        <a class="" href="b-tech-for-working-professionals.php">
                                            <div class="card course_content tab-item">
                                                <img class="card-img pt-2" height="25" weight="25"
                                                    src="assets\img\tab-icon\msc.svg" alt="Card image">
                                                <div class="card-body p-1">
                                                    <h4 class="card-title">M.Sc</h4>


                                                </div>
                                                <p class="card-text">Compare 43 Universities</p>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="items">
                                        <a class="" href="b-tech-for-working-professionals.php">
                                            <div class="card course_content tab-item">
                                                <img class="card-img pt-2" height="25" weight="25"
                                                    src="assets\img\tab-icon\ma.svg" alt="Card image">
                                                <div class="card-body p-1">
                                                    <h4 class="card-title">MA</h4>


                                                </div>
                                                <p class="card-text">Compare 20 Universities</p>
                                            </div>
                                        </a>
                                    </div>



                                </div>

                            </div>
                            </div>


                        </div>
                    </div>


                </div>



            </div>
        </div>
    </div>
