$('.trusted-slide').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: true,
    navText: ["<i class='fa-solid fa-arrow-left'></i>", "<i class='fa-solid fa-arrow-right'></i>"],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 2
        }
    }
});


// $('.compare-slide').owlCarousel({
//     loop: true,
//     margin: 10,
//     nav: true,
//     autoplay: true,
//     autoplayTimeout: 3000,
//     navText: ["<i class='fa-solid fa-arrow-left'></i>", "<i class='fa-solid fa-arrow-right'></i>"],
//     dots: false,
//     responsive: {
//         0: {
//             items: 1
//         },
//         600: {
//             items: 3
//         },
//         1000: {
//             items: 4
//         }
//     }
// });

$('.phone-screen').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 3000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});

$('.testimonial-slide').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 2000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});

$('.real-experts').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})

// popupSarchBox 
function popupSarchBox($searchBox, $searchOpen, $searchCls, $toggleCls) {
    $($searchOpen).on("click", function(e) {
        e.preventDefault();
        $($searchBox).addClass($toggleCls);
    });
    $($searchBox).on("click", function(e) {
        e.stopPropagation();
        $($searchBox).removeClass($toggleCls);
    });
    $($searchBox)
        .find("form")
        .on("click", function(e) {
            e.stopPropagation();
            $($searchBox).addClass($toggleCls);
        });
    $($searchCls).on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        $($searchBox).removeClass($toggleCls);
    });
}
popupSarchBox(
    ".popup-search-box",
    ".searchBoxToggler",
    ".searchClose",
    "show"
);

// home slider
$('.home_slider').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 5000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});


$('.ceo-message').owlCarousel({
    loop: true,
    margin: 10,
    dots: false,
    nav: false,
    autoplay: true,
    autoplayTimeout: 3000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});

$("#typed").typed({
    strings: ["Cross Check", "Verify"],
    typeSpeed: 100,
    startDelay: 0,
    backSpeed: 60,
    backDelay: 2000,
    loop: true,
    cursorChar: "|",
    contentType: 'html'
});

$("#typed1").typed({
    strings: ["Made Simple!"],
    typeSpeed: 100,
    startDelay: 0,
    backSpeed: 60,
    backDelay: 2000,
    loop: true,
    cursorChar: "|",
    contentType: 'html'
});

// Scroll Top addclass and remove
$(window).scroll(function() {
    if ($(this).scrollTop() > 300) {
        $('.scroll_to_top').addClass("open");
    } else {
        $('.scroll_to_top').removeClass("open");
    }
});


// Header Scroll addclass and remove
$(window).scroll(function() {
    if ($(this).scrollTop() > 100) {
        $('.menu-area').addClass("sticky");
    } else {
        $('.menu-area').removeClass("sticky");
    }
});


// window.addEventListener('contextmenu', function(e) {
//     e.preventDefault();
// }, false);




function getrack_id(n) {
    var ids = n;
    $(".track_id").attr("id", ids);
}
$(document).ready(function() {
    $("#suggestregForm").submit(function() {
        $(".loader_modal").click();
    });
});
var currentTab = 0;
showTab(currentTab);

function showTab(n) {
    var x = document.getElementsByClassName("tab");
    x[n].style.display = "block";
    if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
    } else {
        document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == (x.length - 1)) {
        $('#nextBtn').css('display', '');
        document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
        document.getElementById("nextBtn").innerHTML = "next";
    }
    fixStepIndicator(n)
}

function nextPrev(n) {
    var x = document.getElementsByClassName("tab");
    if (n == 1 && !validateForm()) return false;
    x[currentTab].style.display = "none";
    currentTab = currentTab + n;
    if (currentTab >= x.length) {
        document.getElementById("suggestregForm").submit();
        return false;
    }
    showTab(currentTab);
}

function validateForm() {
    var x, y, i, valid = true;
    x = document.getElementsByClassName("tab");
    var course = $("input[name='course']:checked").val();
    yy = x[currentTab].getElementsByTagName("input");
    var att = $("#countcs").val();
    y = x[currentTab].getElementsByTagName("input");
    if (course) {
        y = x[currentTab].getElementsByTagName("input");
        shoval = att - 1;
        $('.showdata').text(shoval);
        $("#prevBtn").click(function() {
            shovals = shoval + 1;
            $('.showdata').text(shovals);
        });
    }
    for (i = 0; i < y.length; i++) {
        if (y[i].value == "") {
            y[i].className += " invalid";
            valid = false;
        }
    }
    if (valid) {
        document.getElementsByClassName("step")[currentTab].className += " finish";
    }
    return valid;
}

function fixStepIndicator(n) {
    var i, x = document.getElementsByClassName("step");
    for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
    }
    x[n].className += " active";
}

$(document).ready(function() {
    $('.category').on('click', function() {
        var courseid = $("input[name='category']:checked").val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function(html) {
                    $('#getcat').html();
                    $('#nextBtn').click();
                }
            });
        } else {
            $('#getcat').html('<option value="">Select Course first</option>');
        }
    });
});

$(document).ready(function() {
    $('.course').on('click', function() {
        var courseid = $("input[name='course']:checked").val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function() {
                    $('#subcourse_idss').html();
                    $(".showdata1").css("display", "");
                    $(".sp").css("display", "none");
                }
            });
        } else {
            $('#subcourse_idss').html('<option value="">Select Course first</option>');
        }
    });
});
$(document).ready(function() {
    $('.course').on('click', function() {
        var courseid = $("input[name='course']:checked").val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function() {
                    $('#subnew').html();
                    $('#nextBtn').click();
                }
            });
        } else {
            $('#subnew').html('<option value="">Select Course first</option>');
        }
    });
});
$(document).ready(function() {
    $('.course').on('click', function() {
        var courseid = $("input[name='course']:checked").val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function() {
                    $('#step_sub_compare').html();
                }
            });
        } else {
            $('#step_sub_compare').html('<option value="">Select Course first</option>');
        }
    });
});
$(document).ready(function() {
    $('.course').on('click', function() {
        var courseid = $("input[name='course']:checked").val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function() {
                    $('#tap_sub_compare').html();
                }
            });
        } else {
            $('#tap_sub_compare').html('<option value="">Select Course first</option>');
        }
    });
});
$(document).ready(function() {
    $('#specialization').on('change', function() {
        var courseid = $(this).val();
        if (courseid) {
            $.ajax({
                type: 'POST',
                data: 'courseids=' + courseid,
                success: function() {
                    $('#sp').html();
                    $("#sp").css("display", " ");
                    // $("#nextBtn").css("display", "block");
                    $('#nextBtn').click();
                }
            });
        } else {
            $('#sp').html('<option value="">Select Course first</option>');
        }
    });
});

$("#nextBtn").click(function() {
    $(this).css("display", "none");
});

$(".working").click(function() {
    $('#nextBtn').click();
});

$(".Qualification").click(function() {
    $('#nextBtn').click();
});

$(".Budget").click(function() {
    $('#nextBtn').click();
});

$(".Hours").click(function() {
    $('#nextBtn').click();
});

$(".matters").click(function() {
    $('#nextBtn').click();
});

$(document).ready(function() {
    $("#suggestregForm").submit(function() {
        alert("Submitted");
        var bla = $('#name').val();
        if (bla != "") {
            $(".track_id").attr("id", "suggest-me-an-university");
            $(".track_id").click();
        }
    });
});