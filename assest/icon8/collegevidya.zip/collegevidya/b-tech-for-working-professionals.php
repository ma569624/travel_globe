<?php include("header.php");?>

    <section class="contact-area"> 
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3><span> Compare & Select Best</span> University for your Online & Distance MBA Course</h3>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                    <ul>
                        <li><i class="fa-sharp fa-solid fa-circle-check"></i> Get Approved University</li>
                        <li><i class="fa-sharp fa-solid fa-circle-check"></i> 100% Placement Assistance</li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-form">
                        <form>
                            <div class="row"> 
                                <div class="col-lg-6">
                                    <label class="plan basic-plan" for="basic">
                                        <input checked type="radio" name="plan" id="basic" />
                                        <div class="plan-content">
                                            <img loading="lazy" src="assets/img/college-icon/male.svg" alt="" />
                                            <div class="plan-details">
                                                <span> Male </span> 
                                            </div>
                                        </div>
                                    </label>
                                </div> 
                                
                                <div class="col-lg-6">
                                    <label class="plan complete-plan" for="complete">
                                        <input type="radio" id="complete" name="plan" />
                                        <div class="plan-content">
                                            <img loading="lazy" src="assets/img/college-icon/female.svg" alt="" />
                                            <div class="plan-details">
                                                <span> Female </span>
                                            </div>
                                        </div>
                                    </label>
                                </div> 

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Full Name" name="name" required="">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="Email Address " name="email" required="">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <select class="form-select" name="city" required="">
                                            <option selected="" disabled="" value="">Select State </option>
                                            <option value="Delhi">Delhi</option>
                                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option value="Uttarakhand">Uttarakhand</option>
                                            <option value="West Bengal">West Bengal</option>
                                            <option value="Punjab">Punjab</option>
                                            <option value="Rajasthan">Rajasthan</option>
                                            <option value="Sikkim">Sikkim</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="Telangana">Telangana</option>
                                            <option value="Tripura">Tripura</option>
                                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option value="Assam">Assam</option>
                                            <option value="Bihar">Bihar</option>
                                            <option value="Chandigarh">Chandigarh</option>
                                            <option value="Chhattisgarh">Chhattisgarh</option>
                                            <option value="Goa">Goa</option>
                                            <option value="Gujarat">Gujarat</option>
                                            <option value="Haryana">Haryana</option>
                                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option value="Jammu &amp; Kashmir">Jammu &amp; Kashmir</option>
                                            <option value="Jharkhand">Jharkhand</option>
                                            <option value="Karnataka">Karnataka</option>
                                            <option value="Kerala">Kerala</option>
                                            <option value="Lakshadweep">Lakshadweep</option>
                                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option value="Maharashtra">Maharashtra</option>
                                            <option value="Manipur">Manipur</option>
                                            <option value="Meghalaya">Meghalaya</option>
                                            <option value="Mizoram">Mizoram</option>
                                            <option value="Nagaland">Nagaland</option>
                                            <option value="Orissa">Orissa</option>
                                            <option value="Puducherry">Puducherry</option>
                                            <option value="Andaman &amp; Nicobar Islands">Andaman &amp; Nicobar Islands</option>
                                            <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                                            <option value="Daman and Diu">Daman and Diu</option>
                                            <option value="Ladakh">Ladakh</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="number" class="form-control" placeholder="Mobile Number">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="date" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <select class="form-select" name="subcourse_id" id="subcourse_id" required="">
                                            <option value=""> All Specialization  </option>
                                            <option value="spe">  mba General  </option>
                                            <option value="finance-management">Finance</option>
                                            <option value="hr-management">HR</option>
                                            <option value="hospitality-management">Hospitality Management</option>
                                            <option value="marketing-management">Marketing</option>
                                            <option value="banking-finance-management">Banking Finance</option>
                                            <option value="marketing-and-finance-management">Marketing And Finance</option>
                                            <option value="information-technology-management">Information Technology</option>
                                            <option value="logistics-and-supply-chain-management">Logistics And Supply Chain</option>
                                            <option value="marketing-and-hr-management">Marketing And HR</option>
                                            <option value="operations-management">Operations</option>
                                            <option value="data-science-and-analytics-management">Data Science And Analytics</option>
                                            <option value="business-analytics">Business Analytics</option>
                                            <option value="hrm-and-finance-management">HRM And Finance Management</option>
                                            <option value="healthcare-management">Healthcare Management</option>
                                            <option value="digital-marketing-e-commerce-management">Digital Marketing E Commerce</option>
                                            <option value="business-management">Business Management</option>
                                            <option value="international-business-management">International Business Management</option>
                                            <option value="project-management">Project Management</option>
                                            <option value="finance-and-leadership-management">Finance And Leadership</option>
                                            <option value="financial-markets-management">Financial Markets</option>
                                            <option value="general-management">General</option>
                                            <option value="banking-financial-services-and-insurance-bfsi">Banking Financial Services and Insurance</option>
                                            <option value="entrepreneurship-and-leadership">Entrepreneurship and Leadership</option>
                                            <option value="business-intelligence-and-analytics">Business Intelligence And Analytics</option>
                                            <option value="advertising-and-branding">Advertising and Branding</option>
                                            <option value="system-and-operations-management">System And Operations</option>
                                            <option value="hospital-administration">Hospital Administration</option>
                                            <option value="business-intelligence-ai">Business Intelligence &amp; AI</option>
                                            <option value="oil-and-gas-management">Oil and Gas Management</option>
                                            <option value="international-trade-management">International Trade</option>
                                            <option value="fintech-management">Fintech</option>
                                            <option value="retail-management">Retail</option>
                                            <option value="tourism-management">Tourism Management</option>
                                            <option value="investment-banking-equity-research-management">Investment Banking Equity Research</option>
                                            <option value="international-finance-management">International Finance</option>
                                            <option value="power-management">Power Management</option>
                                            <option value="sports-management">Sports Management</option>
                                            <option value="hr-analytics">HR Analytics</option>
                                            <option value="digital-entrepreneurship">Digital Entrepreneurship</option>
                                            <option value="leadership-and-strategy">Leadership and Strategy</option>
                                            <option value="strategic-hr-management">Strategic HR Management</option>
                                            <option value="banking-and-insurance">Banking and Insurance</option>
                                            <option value="strategic-marketing">Strategic Marketing</option>
                                            <option value="strategic-finance-management">Strategic Finance</option>
                                            <option value="international-marketing-management">International Marketing</option>
                                            <option value="artificial-intelligence-and-machine-learning">Artificial Intelligence and Machine Learning</option>
                                            <option value="blockchain-management">Blockchain Management</option>
                                            <option value="waste-management">Waste Management</option>
                                            <option value="it-and-fintech">IT and FinTech</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-12 text-center">
                                    <div class="form-group">
                                        <a href="online-distance.php" type="submit" name="submit"  class="btn-submit"><span class="mr-2" >Find Best University</span>
                                            <i class="fa-solid fa-arrow-right ms-2"></i>
                                        </a>
                                    </div>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    <div class="shape-mockup spin d-none d-xl-block">
                        <img src="assets/img/icon/plus_1.png" class="img-fluid" alt="">
                    </div>
                    <div class="shape-7 spin">
                        <img src="assets/img/college-icon/shape-7.png" alt="">
                    </div>
                </div>
            </div>
        </div> 
    </section>

    <section class="distance-online">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="assets/img/college-icon/online-distance-mba.png" class="img-fluid" alt="">
                </div>
                <div class="col-md-8 m-auto">
                    <h4>Distance Online MBA Programs</h4>
                    <p>Online/Distance MBA is a 2-year postgraduate program which is called a Masters of Business Administrative degree. In this modern generation, there is mass competition in every field. Due to this mass competition, students get demented that in which field they should go after graduation or if they go with the course what career they can pursue with that?</p>

                    <ul>
                        <li>
                            <a href="">Watch Video 
                                <!-- <span class="play-btn"><i class="fas fa-play"></i></span> -->
                            </a>
                        </li>
                        <li>
                            <a href="">Listen Podcast</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="approvals-section">
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
                    <div class="approvals-content">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Approvals</th>
                                    <th>Duration</th> 
                                    <th>Eligibility</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>UGC | DEB | AICTE | NAAC</td>
                                    <td>2 - 4 Years</td>
                                    <td>Graduation</td>
                                </tr>
                            </tbody>
                        </table>
                        <p>Online/Distance Education MBA is one of the courses that students can learn after graduation. This online MBA program amplifies the career of the student at a high volume. The MBA course in India can be done in 3 modes - Regular mode, Distance Learning mode, and online mode. If a student doesn’t have time for doing a post-graduation MBA on a regular basis then he or she can apply for the<b> MBA course in the distance and online learning mode.</b> </p>
                        <p>The <b>online/distance MBA</b> course is all about business management. In this course, the student will gain knowledge regarding business for example How to manage the business? How to organize the business? What strategies can be used to start a business? Etc. After MBA students can apply for Business Administrator, Business Analyst, Digital Marketing Manager, etc posts in any company. Students have the option of starting their own business after online MBA programs.</p>
                        <div class="text-center"> 
                            <img src="assets/img/college-icon/why-online-mba.jpg" alt="">
                        </div>
                        <p>There are various MBA online colleges in India that provide the best online/distance learning MBA is an advantageous course for those students who can not apply for the regular MBA course due to any circumstances. The fees for online/distance MBA are also a bit lower than the regular MBA courses. Online/Distance MBA courses also have some specialized courses in them. The student can choose any of the courses according to their interest, this will boost your career and can give you many career opportunities.</p>
                        <p><b>Key Highlights of Distance Online MBA Programs In India</b></p>
                        <ul>
                            <li>Online MBA programs in blended mode focus on different areas of business administration like business ethics, business communication, human resource management, etc.&nbsp;</li>
                            <li>MBA distance course in blended mode is the most popular post-graduation degree among students. Most of the students pursue this course even after completing graduation in different streams.&nbsp;&nbsp;</li>
                            <li>This MBA course is best for working professionals who want to upgrade their knowledge and seek the best salary packages.</li>
                            <li>Online MBA programs in blended mode are a good opportunity for those students who want to get the degree the MBA but don’t have time to take regular classes because of some circumstances.&nbsp;</li>
                            <li>The MBA course in online and distance education gives the appropriate knowledge of business management and administration.</li>
                            <li>For applying to this course students must have a degree of bachelor in any field.</li>
                        </ul>
                        <p><b>Online Distance MBA Subjects</b></p>
                        <p>The course is divided into four semesters. Distance online MBA for working professionals' syllabus comprises core subjects and elective subjects that differ as per the specializations. The first two semesters focus on core subjects while in the third and fourth-semesters students need to choose elective subjects. </p>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td><strong>Semester I</strong></td>
                                    <td><strong>Semester II</strong></td>
                                </tr>
                                <tr>
                                    <td>Principles and Practice of Management</td>
                                    <td>Production/Operation Management</td>
                                </tr>
                                <tr>
                                    <td>Management Economics</td>
                                    <td>Financial Management</td>
                                </tr>
                                <tr>
                                    <td>Organizational Behaviour</td>
                                    <td>Human Resource Management</td>
                                </tr>
                                <tr>
                                    <td>Business Law</td>
                                    <td>Marketing Management</td>
                                </tr>
                                <tr>
                                    <td>Management Accounting</td>
                                    <td>Marketing Management</td>
                                </tr>
                                <tr>
                                    <td>-</td>
                                    <td>Management Information system</td>
                                </tr>
                            </tbody>
                        </table>
                        <p><b>Distance Online MBA Programs Eligibility </b></p>
                        <p>Distance online MBA is a program that can be enrolled by the aspirants who have done their graduation from any stream. For admission in this program, there are some universities that take entrance examinations or some take direct admission. The aspirants having 3 years of work experience are preferred by some universities. </p>
                        <p><i>The general eligibility criteria for distance online MBA programs are as follows:</i></p>
                        <ul>
                            <li>Some universities require a simple graduation degree from a recognized university.</li>
                            <li>Some universities require the student to have at least 45%-50% aggregate marks at the graduation level for being eligible.&nbsp;</li>
                            <li>Some universities may require the candidate to have a graduation degree along with 1-2 years of professional experience.</li>
                        </ul>
                        <p><b>Distance Online MBA Programs Duration </b></p>
                        <p>The minimum duration of an online MBA program is 2 years and the maximum duration is 4 years. The candidates get extra 2 years to pass all the exams of their degree course. The curriculum of the program is divided into 4 different semesters of 6 months each. </p>
                        <p><b>Distance Online MBA Programs Admission Requirements </b></p>
                        <p><i>There are some common steps that you need to follow to take admissions to universities in the online MBA program: </i></p>
                        <ul>
                            <li>Go to the official website of the university (the university to which you are willing to take admission).</li>
                            <li>Register yourself as a new user and fill out the application form with your details.</li>
                            <li>Submit the required documents with the application form and the registration fees.</li>
                            <li>In the next step, submit your academic fee via any mode of payment mentioned on the website.</li>
                            <li>In the end, you will get a confirmation mail along with your student enrollment number/student number.</li>
                        </ul>


                        <div class="section-title">
                            <h3><span> Admission </span>Procedure</h3>
                            <div class="icon">
                                <i class="fa-solid fa-graduation-cap"></i>
                            </div>
                        </div>
 
                        <div class="main-timeline">
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-globe"></i></div>
                                    <h3 class="title">Signup</h3>
                                    <p class="description">Login to the website by signing up as the new user.</p>
                                </a>
                            </div>
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                    <h3 class="title">Registration</h3>
                                    <p class="description">Register by filling in a few personal detalis.</p>
                                </a>
                            </div>
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                    <h3 class="title">Application</h3>
                                    <p class="description">Fill in the application form for the course you select.</p>
                                </a>
                            </div>
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                    <h3 class="title">Fee Submission</h3>
                                    <p class="description">Submit the fee via online or any other method if available.</p>
                                </a>
                            </div>
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                    <h3 class="title">Doc - Verification</h3>
                                    <p class="description">Submit scanned copies if your documents for verification.</p>
                                </a>
                            </div>
                            <div class="timeline">
                                <a href="#" class="timeline-content">
                                    <div class="timeline-icon"><i class="fa fa-rocket"></i></div>
                                    <h3 class="title">LMC</h3>
                                    <p class="description">Login to the LMS via credentials sent on your mail.</p>
                                </a>
                            </div>
                             
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php include("footer.php");?>