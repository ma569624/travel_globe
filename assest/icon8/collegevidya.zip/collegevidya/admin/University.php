<?php require('header.php') ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">University</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                                <li class="breadcrumb-item active">University</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="add-university.php" class="btn btn-success">Add University</a>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="">
                        <div class="table-responsive">
                            <table class="table project-list-table table-nowrap align-middle table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col" style="width: 100px"> University</th>
                                        <th scope="col">Approvals</th>
                                        <th scope="col">Student Choice</th>
                                        <th scope="col">Student Rating</th>
                                        <th scope="col">Proceed to University</th>
                                        <th scope="col">CV Advisor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><img src="assets\images\collage\Jain-University.jpg" alt="" class="avatar">
                                        </td>
                                        <td>
                                            <p class="text-muted mb-0">UGC | AICTE | AIU | NAAC A</p>
                                        </td>
                                        <td>73 %</td>
                                        <td><span class="text-success">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i></span>
                                        </td>
                                        <td>
                                        <span class="badge bg-success p-2">
                                        ₹ 30,000 / Yr </span>
                                        </td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="#" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img src="assets\images\collage\manav-rachna-online-logo.jpg" alt="" class="avatar">
                                        </td>
                                        <td>
                                            <p class="text-muted mb-0">UGC | AICTE | AIU | NAAC A</p>
                                        </td>
                                        <td>87 %</td>
                                        <td><span class="text-success">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i></span>
                                        </td>
                                        <td>
                                        <span class="badge bg-success p-2">
                                        ₹ 30,000 / Yr </span>
                                        </td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="#" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-12">
                    <div class="text-center my-3">
                        <a href="javascript:void(0);" class="text-success"><i
                                class="bx bx-loader bx-spin font-size-18 align-middle me-2"></i> Load more </a>
                    </div>
                </div> <!-- end col-->
            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    
    <?php include('footer.php') ?>