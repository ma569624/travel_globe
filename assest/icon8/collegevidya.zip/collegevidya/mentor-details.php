<?php include('header.php') ?>

<div class="container mb-4">
    <div class="row">

        <div class="mentor-profile-details shadow-lg mt-2 pt-2">
            <div class="row">
                <div class="bg-white pt-3 col-lg-12">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="text-center " style="padding: 20px; background-color:#f0f8ff;">
                                        <div class="mx-auto">
                                            <img src="assets\img\New\isha-sharma.jpg" alt=""
                                                class="img-fluid rounded-circle w-50">
                                        </div>
                                        <div class="my-2">
                                            <p class="mb-0">Verified</p>
                                            <h4 class="mb-0">Isha Sharma</h4>
                                            <p class="mb-1">(Sr. Mentor)</p>
                                            <p class="mb-1">MBA (Finance) & PG Diploma in Career Counselling</p>
                                            <span class="badge bg-primary">7 Years Exp</span>
                                        </div>




                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="p-3">
                                        <h4>About</h4>
                                        <span><i class="fa fa-star text-warning"></i> 4.7 (7 votes)</span>
                                        <p class="pt-2">
                                            Praveen is a qualified Life Coach, Image Consultant, and Soft Skills Trainer
                                            who has served as the Director for over twenty years. He is now coaching and
                                            mentoring students to attain the profile that universities seek. Praveen has
                                            an unrivalled drive to succeed, which he instils in her mentees.
                                        </p>
                                        <span class="text-primary float-end " data-bs-toggle="modal"
                                            data-bs-target="#review" style="cursor: pointer;">Share your
                                            experience</span>



                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="border p-3 h-100">
                                <div class="row">
                                    <div class="time-slot mt-4">
                                        <p>PICK A TIME SLOT</p>
                                        <div class="my-2">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <div>

                                                    <h6 class="">
                                                        <span class="bg-primary p-1 rounded-circle me-4"><i
                                                                class="fa fa-video text-light"></i></span>
                                                        VIDEO CONSULTATION
                                                    </h6>
                                                </div>
                                                <div>
                                                    <h5 class="mb-0">₹ 199</h5>
                                                </div>
                                            </div>
                                            <div class="ms-5 border-bottom">
                                                <p>Includes Audio, Video and Chat</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="times">

                                        <ul class="nav nav-tabs nav-tabs-custom border-0" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active border-0" data-bs-toggle="tab" href="#Today"
                                                    role="tab">

                                                    <span class="d-none d-sm-block">Today</span>
                                                </a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link border-0" data-bs-toggle="tab" href="#Tommorow"
                                                    role="tab">

                                                    <span class="d-none d-sm-block">Tomorrow</span>
                                                </a>
                                            </li>


                                        </ul>
                                        <div class="slotes">
                                            <div class="tab-content ">
                                                <div class="tab-pane active" id="Today" role="tabpanel">
                                                    <ul class="list-unstyled d-flex flex-wrap ">
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">10:00
                                                                AM</span>

                                                        </li>
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">12:00
                                                                PM</span>

                                                        </li>
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">1:00
                                                                PM</span>
                                                        </li>


                                                    </ul>
                                                </div>
                                                <div class="tab-pane" id="Tommorow" role="tabpanel">
                                                    <ul class="list-unstyled d-flex flex-wrap ">
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">12:00
                                                                PM</span>

                                                        </li>
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">2:00
                                                                PM</span>

                                                        </li>
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">3:00
                                                                PM</span>

                                                        </li>
                                                        <li>
                                                            <span class="text-primary float-end " data-bs-toggle="modal"
                                                                data-bs-target="#time" style="cursor: pointer;">4:00
                                                                PM</span>

                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 mt-3">
                        <div class="row">
                            <div class="row">
                                <ul class="nav nav-tabs nav-tabs-custom border-0" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active border-0" data-bs-toggle="tab" href="#info"
                                            role="tab">
                                            <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                            <span class="d-none d-sm-block">Info</span>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link border-0" data-bs-toggle="tab" href="#reviews" role="tab">
                                            <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                            <span class="d-none d-sm-block">Reviews (7)</span>
                                        </a>
                                    </li>


                                </ul>
                            </div>

                            <div class="col-xl-12">
                                <div class="">
                                    <div class="">



                                        <!-- Nav tabs -->


                                        <!-- Tab panes -->
                                        <div class="tab-content p-3 ">
                                            <div class="tab-pane active" id="info" role="tabpanel">
                                                <div class="row shadow card py-2">
                                                    <p class="m-0 fw-bold"><i class="fa fa-map-marker"></i> India</p>

                                                </div>
                                                <div class="row shadow card py-3 mt-4">
                                                    <div class="d-inline">
                                                        <span class="badge bg-info text-dark"> MON</span>
                                                        <span class="badge bg-info text-dark"> TUE</span>
                                                        <span class="badge bg-info text-dark"> WED</span>
                                                        <span class="badge bg-info text-dark"> THU</span>
                                                        <span class="badge bg-info text-dark"> FRI</span>
                                                        <span class="badge bg-info text-dark"> SAT</span>
                                                    </div>
                                                    <div class="mt-4">
                                                        <p class="mb-0">10:00 AM - 2:00 PM</p>
                                                        <p>2:30 PM - 6:00 PM</p>
                                                    </div>

                                                </div>
                                                <div class="row shadow card py-2 mt-4">
                                                    <p class="fw-bold m-0">Consultation Fee</p>
                                                    <h4 class="text-primary">₹199</h4>
                                                    <p class="fw-bold m-0">Specializations</p>
                                                    <ul class="list-unstyled d-flex flex-wrap p-3 ">
                                                        <li>
                                                            MBA (Online)
                                                        </li>
                                                        <li>
                                                            BA (Online)
                                                        </li>
                                                        <li>
                                                            BBA (Online)
                                                        </li>
                                                        <li>
                                                            B.Com (Online)
                                                        </li>
                                                        <li>MA (Online)</li>
                                                        <li>MCA (Online)</li>
                                                        <li>M.Com (Online)</li>
                                                        <li>M.Sc (Online)</li>
                                                        <li>Executive MBA (Online)</li>
                                                        <li>M.Tech (Online)</li>

                                                    </ul>



                                                </div>
                                            </div>


                                            <div class="tab-pane" id="reviews" role="tabpanel">
                                                <div class="row">
                                                    <p class="fw-bold m-0">Student Reviews for Praveen Chauhan</p>
                                                    <p>These are student's opinions and do not necessarily reflect the
                                                        counsellor's capabilities.</p>
                                                    <div class="d-flex star">
                                                        <i class="fa fa-star text-warning "></i>
                                                        <i class="fa fa-star text-warning"></i>
                                                        <i class="fa fa-star text-warning"></i>
                                                        <i class="fa fa-star text-warning"></i>
                                                        <i class="fa fa-star text-light"></i>

                                                        <p class="fw-bold">4 out of 5</p>
                                                    </div>
                                                    <p>7 global ratings</p>

                                                    <div class="progress-bars">
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <p class="text-primary">5 star</p>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                                        style="width:90%"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <p class="text-primary">90.00%</p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <p class="text-primary">4 star</p>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                                        style="width:97%"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <p class="text-primary">98.00%</p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <p class="text-primary">3 star</p>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                                        style="width:0%"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <p class="text-primary">0.00%</p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <p class="text-primary">2 star</p>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                                        style="width:0%"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <p class="text-primary">0.00%</p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <p class="text-primary">2 star</p>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                                        style="width:0%"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <p class="text-primary">0.00%</p>
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="given-review border-bottom mt-2">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div class="d-flex ">
                                                                <div><span class="badge bg-warning me-2">f</span></div>
                                                                <p class="">Fiza</p>
                                                            </div>
                                                            <div>
                                                                <p>4 months ago</p>
                                                            </div>

                                                        </div>
                                                        <div class="ms-4">
                                                            <p class=" fw-bold">interaction was so good</p>
                                                            <span class="bg-info p-2">5 <span><i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i></span>
                                                            </span>
                                                            <p class="my-3">they guide me very well , they also show my
                                                                carrier</p>

                                                        </div>
                                                    </div>
                                                    <div class="given-review border-bottom mt-2">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div class="d-flex ">
                                                                <div><span class="badge bg-warning me-2">f</span></div>
                                                                <p class="">Fiza</p>
                                                            </div>
                                                            <div>
                                                                <p>4 months ago</p>
                                                            </div>

                                                        </div>
                                                        <div class="ms-4">
                                                            <p class=" fw-bold">interaction was so good</p>
                                                            <span class="bg-info p-2">5 <span><i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i> <i
                                                                        class="fa fa-star text-warning"></i></span>
                                                            </span>
                                                            <p class="my-3">they guide me very well , they also show my
                                                                carrier</p>

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<?php include 'mentor-details-modal.php'; ?>

<!-- owl.carousel js -->
<script src="admin/assets/libs/owl.carousel/owl.carousel.min.js"></script>

<!-- timeline init js -->
<script src="admin/assets/js/pages/timeline.init.js"></script>

<script src="admin/assets/js/app.js"></script>


<?php include('footer.php') ?>