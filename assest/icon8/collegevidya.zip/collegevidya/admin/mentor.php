<?php require('header.php') ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card mx-n4 mt-n4 bg-info bg-soft">
                                    <div class="card-body">
                                        <div class="text-center mb-4">
                                            <img src="assets/images/users/avatar-6.jpg" alt="" class="avatar-md rounded-circle mx-auto d-block" />
                                            <h5 class="mt-3 mb-1">Steven Franklin</h5>
                                            <p class="text-muted mb-3">(Sr. Mentor)</p>
                                            
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <ul class="list-unstyled hstack gap-3 mb-0 flex-grow-1">
                                                <li>
                                                    <i class="bx bx-map align-middle"></i> India
                                                </li>
                                                
                                            </ul>
                                            <div class="hstack gap-2">
                                                <button type="button" class="btn btn-primary">Video Consulation<i class=' align-baseline ms-1'></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="card-body">
                                        <ul class="list-unstyled vstack gap-3 mb-0">
                                            <li>
                                                <div class="d-flex">
                                                    <i class='bx bx-calendar font-size-18 text-primary'></i>
                                                    <div class="ms-3">
                                                        <h6 class="mb-1 fw-semibold">Experience:</h6>
                                                        <span class="text-muted">2+ Years</span>
                                                    </div>
                                                </div>
                                            </li>
                                            
                                            <li>
                                                <div class="d-flex">
                                                    <i class='bx bx-user font-size-18 text-primary'></i>
                                                    <div class="ms-3">
                                                        <h6 class="mb-1 fw-semibold">Gender:</h6>
                                                        Male
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="d-flex">
                                                    <i class='mdi mdi-book-education font-size-18 text-primary'></i>
                                                    <div class="ms-3">
                                                        <h6 class="mb-1 fw-semibold">Qualification:</h6>
                                                        <span class="text-muted">Master Degree</span>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="d-flex">
                                                    <i class='mdi mdi-google-translate font-size-18 text-primary'></i>
                                                    <div class="ms-3">
                                                        <h6 class="mb-1 fw-semibold">Languages:</h6>
                                                        <span class="text-muted">English, France</span>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="hstack gap-2 mt-3">
                                                <a href="#!" class="btn btn-soft-primary w-100">Hire Now</a>
                                                <a href="#!" class="btn btn-soft-danger w-100">Contact Us</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <ul class="list-unstyled vstack gap-3 mb-0">
                                            
                                            <li>
                                                <div class="d-flex">
                                                
                                                    <i class='bx bx-money font-size-18 text-primary'></i>
                                                    <div class="ms-3">
                                                        <h6 class="mb-1 fw-semibold">Consulation fee</h6>
                                                        <h4 class="mt-3">₹ 199</h4>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="hstack gap-2 mt-3">
                                                <a href="#!" class="btn btn-soft-primary w-100">Book your counsellor</a>
                                                
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!--end col-->
                            <div class="col-lg-9">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="mb-3">About Us</h5>
                                        <p class="text-muted">Very well thought out and articulate communication. Clear milestones, deadlines and fast work. Patience. Infinite patience. No shortcuts. Even if the client is being careless. Some quick example text to build on the card title and bulk the card's content Moltin gives you platform.</p>
                                        <p class="text-muted mb-4">As a highly skilled and successfull product development and design specialist with more than 4 Years of My experience lies in successfully conceptualizing, designing, and modifying consumer products specific to interior design and home furnishings.</p>
                                        
                                        <h5 class="mb-3">Specialist</h5>
                                        <ul class="verti-timeline list-unstyled">
                                            <li class="event-list">
                                                <div class="event-timeline-dot">
                                                    <i class="bx bx-right-arrow-circle"></i>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="flex-grow-1">
                                                        <div>
                                                            <h6 class="font-size-14 mb-1">BCA - Bachelor of Computer Applications</h6>
                                                            <p class="text-muted">International University - (2004-2010)</p>
                                                            
                                                            <p class="text-muted mb-0">There are many variations of passages of available, but the majority alteration in some form. As a highly skilled and successfull product development and design specialist with more than 4 Years of My experience.</p>
                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="event-list">
                                                <div class="event-timeline-dot">
                                                    <i class="bx bx-right-arrow-circle"></i>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="flex-grow-1">
                                                        <div>
                                                            <h6 class="font-size-14 mb-1">MCA - Master of Computer Application</h6>
                                                            <p class="text-muted">International University - (2010-2012)</p>
                                                            
                                                            <p class="text-muted mb-0">There are many variations of passages of available, but the majority alteration in some form. As a highly skilled and successfull product development and design specialist with more than 4 Years of My experience.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="event-list">
                                                <div class="event-timeline-dot">
                                                    <i class="bx bx-right-arrow-circle"></i>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="flex-grow-1">
                                                        <div>
                                                            <h6 class="font-size-14 mb-1">Design Communication Visual</h6>
                                                            <p class="text-muted">International University - (2012-2015)</p>

                                                            <p class="text-muted mb-0">There are many variations of passages of available, but the majority alteration in some form. As a highly skilled and successfull product development and design specialist with more than 4 Years of My experience.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                

                            </div><!--end col-->
                        </div><!--end row-->

                        
                        

                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
                
                
    <?php include('footer.php') ?>