<?php include('header.php') ?>

<div class="container mb-4 mt-2">
    <div class="row shadow-lg">

        <div class="filter-form  px-5 py-3 " style="background-color: #0079d3;">
            <div class="row g-3">
                <div class="col-4">
                    <div class="form-group">
                        <label for="email" class="form-label text-light">Course*</label>
                        <select class="form-control" name="city" required="">
                            <option selected="" disabled="" value="">Select A Course </option>
                            <option value="MBA">MBA</option>
                            <option value="MCA">MCA</option>
                            <option value="BBA">BBA</option>
                            <option value="BCA">BCA</option>
                            <option value="B.COM">B.COM</option>
                            <option value="B.TECH">B.TECH</option>
                            <option value="B.A">B.A</option>
                            <option value="B.ED">B.ED</option>
                        </select>
                    </div>
                </div>
                <div class="col-4">

                    <div class="form-group">
                        <label for="email" class="form-label text-light">Made of Education*</label>
                        <select class="form-control" name="city" required="">
                            <option selected="" disabled="" value="">Select A Course </option>
                            <option value="MBA">MBA</option>
                            <option value="MCA">MCA</option>
                            <option value="BBA">BBA</option>
                            <option value="BCA">BCA</option>
                            <option value="B.COM">B.COM</option>
                            <option value="B.TECH">B.TECH</option>
                            <option value="B.A">B.A</option>
                            <option value="B.ED">B.ED</option>

                        </select>
                    </div>

                </div>
                <div class="col-4">

                    <div class="form-group">
                        <label for="email" class="form-label text-light">Specialization*</label>
                        <select class="form-select" name="subcourse_id" id="subcourse_id" required="">
                                            <option value=""> All Specialization  </option>
                                            <option value="spe">  mba General  </option>
                                            <option value="finance-management">Finance</option>
                                            <option value="hr-management">HR</option>
                                            <option value="hospitality-management">Hospitality Management</option>
                                            <option value="marketing-management">Marketing</option>
                                            <option value="banking-finance-management">Banking Finance</option>
                                            <option value="marketing-and-finance-management">Marketing And Finance</option>
                                            <option value="information-technology-management">Information Technology</option>
                                            <option value="logistics-and-supply-chain-management">Logistics And Supply Chain</option>
                                            <option value="marketing-and-hr-management">Marketing And HR</option>
                                            <option value="operations-management">Operations</option>
                                            <option value="data-science-and-analytics-management">Data Science And Analytics</option>
                                            <option value="business-analytics">Business Analytics</option>
                                            <option value="hrm-and-finance-management">HRM And Finance Management</option>
                                            <option value="healthcare-management">Healthcare Management</option>
                                            <option value="digital-marketing-e-commerce-management">Digital Marketing E Commerce</option>
                                            <option value="business-management">Business Management</option>
                                            <option value="international-business-management">International Business Management</option>
                                            <option value="project-management">Project Management</option>
                                            <option value="finance-and-leadership-management">Finance And Leadership</option>
                                            <option value="financial-markets-management">Financial Markets</option>
                                            <option value="general-management">General</option>
                                            <option value="banking-financial-services-and-insurance-bfsi">Banking Financial Services and Insurance</option>
                                            <option value="entrepreneurship-and-leadership">Entrepreneurship and Leadership</option>
                                            <option value="business-intelligence-and-analytics">Business Intelligence And Analytics</option>
                                            <option value="advertising-and-branding">Advertising and Branding</option>
                                            <option value="system-and-operations-management">System And Operations</option>
                                            <option value="hospital-administration">Hospital Administration</option>
                                            <option value="business-intelligence-ai">Business Intelligence &amp; AI</option>
                                            <option value="oil-and-gas-management">Oil and Gas Management</option>
                                            <option value="international-trade-management">International Trade</option>
                                            <option value="fintech-management">Fintech</option>
                                            <option value="retail-management">Retail</option>
                                            <option value="tourism-management">Tourism Management</option>
                                            <option value="investment-banking-equity-research-management">Investment Banking Equity Research</option>
                                            <option value="international-finance-management">International Finance</option>
                                            <option value="power-management">Power Management</option>
                                            <option value="sports-management">Sports Management</option>
                                            <option value="hr-analytics">HR Analytics</option>
                                            <option value="digital-entrepreneurship">Digital Entrepreneurship</option>
                                            <option value="leadership-and-strategy">Leadership and Strategy</option>
                                            <option value="strategic-hr-management">Strategic HR Management</option>
                                            <option value="banking-and-insurance">Banking and Insurance</option>
                                            <option value="strategic-marketing">Strategic Marketing</option>
                                            <option value="strategic-finance-management">Strategic Finance</option>
                                            <option value="international-marketing-management">International Marketing</option>
                                            <option value="artificial-intelligence-and-machine-learning">Artificial Intelligence and Machine Learning</option>
                                            <option value="blockchain-management">Blockchain Management</option>
                                            <option value="waste-management">Waste Management</option>
                                            <option value="it-and-fintech">IT and FinTech</option>
                                        </select>
                    </div>
                </div>
                <div class="col-4">

                    <div class="form-group">
                        <label for="email" class="form-label text-light">Sort By</label>
                        <select class="form-control" name="city" required="">
                            <option selected="" disabled="" value="">Select A Course </option>
                            <option value="MBA">MBA</option>
                            <option value="MCA">MCA</option>
                            <option value="BBA">BBA</option>
                            <option value="BCA">BCA</option>
                            <option value="B.COM">B.COM</option>
                            <option value="B.TECH">B.TECH</option>
                            <option value="B.A">B.A</option>
                            <option value="B.ED">B.ED</option>

                        </select>
                    </div>
                </div>
                <div class="col-4">

                    <div class="form-group mt-3">
                        <label class="form-check-label text-light" for="flexCheckDefault">
                            Gender
                        </label>
                        <div>
                            <input class="form-check-input " type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label text-light" for="flexCheckDefault">
                                Male
                            </label>

                            <input class="form-check-input " type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label text-light" for="flexCheckDefault">
                                Female
                            </label>
                        </div>

                    </div>




                </div>

            </div>
        </div>

        <div class="mentors card px-4 pb-5">

            <div
                class="mentor-card border border-primary d-flex justify-content-around align-items-center mt-4 py-4 shadow">
                <div class="profile text-center">
                    <img src="assets\img\New\preeti.jpg" alt="" class="rounded-circle img-fluid w-50">
                    <div class="mt-2">
                    <a href="mentor-details.php" class="text-primary">View Profile</a>
                    </div>
                </div>
                <div class="details">
                    <h4 class="text-primary mb-0">Isha Sharma</h4>
                    <p class="m-0">() + 24 more</p>
                    <p class="m-0">7 years experience overall</p>
                    <p class="m-0">MBA (Finance) & PG Diploma in Career Counselling</p>
                    <h4 class="mt-2 mb-0">₹199 consultation fee</h4>
                    <span><span class="badge bg-warning"><i class="fa fa-star"></i> 4.7 </span> 7 student reviews</span>

                </div>
                <div class="book">
                    <a href="mentor-details.php" class="btn btn-primary">Book appointment <div class="fw-bold"
                            style="font-size: 10px;">Schedule a consultation</div></a>

                </div>
            </div>

            <div class="mentor-card border border-primary d-flex justify-content-around align-items-center mt-4 py-4 shadow">
                <div class="profile text-center">
                    <img src="assets\img\New\Ankit Singh.jpg" alt="" class="rounded-circle img-fluid w-50">
                    <div class="mt-2">
                        <a href="mentor-details.php" class="text-primary">View Profile</a>
                    </div>
                </div>
                <div class="details">
                    <h4 class="text-primary mb-0">Isha Sharma</h4>
                    <p class="m-0">() + 24 more</p>
                    <p class="m-0">7 years experience overall</p>
                    <p class="m-0">MBA (Finance) & PG Diploma in Career Counselling</p>
                    <h4 class="mt-2 mb-0">₹199 consultation fee</h4>
                    <span><span class="badge bg-warning"><i class="fa fa-star"></i> 4.7 </span> 7 student reviews</span>

                </div>
                <div class="book">
                    <a href="mentor-details.php" class="btn btn-primary">Book appointment <div class="fw-bold"
                            style="font-size: 10px;">Schedule a consultation</div></a>

                </div>
            </div>
            <div class="mentor-card border border-primary d-flex justify-content-around align-items-center mt-4 py-4 shadow">
                <div class="profile text-center">
                    <img src="assets\img\New\isha-sharma.jpg" alt="" class="rounded-circle img-fluid w-50">
                    <div class="mt-2">
                    <a href="mentor-details.php" class="text-primary">View Profile</a>
                    </div>
                </div>
                <div class="details">
                    <h4 class="text-primary mb-0">Isha Sharma</h4>
                    <p class="m-0">() + 24 more</p>
                    <p class="m-0">7 years experience overall</p>
                    <p class="m-0">MBA (Finance) & PG Diploma in Career Counselling</p>
                    <h4 class="mt-2 mb-0">₹199 consultation fee</h4>
                    <span><span class="badge bg-warning"><i class="fa fa-star"></i> 4.7 </span> 7 student reviews</span>

                </div>
                <div class="book">
                    <a href="mentor-details.php" class="btn btn-primary">Book appointment <div class="fw-bold"
                            style="font-size: 10px;">Schedule a consultation</div></a>

                </div>
            </div>
            <div class="mentor-card border border-primary d-flex justify-content-around align-items-center mt-4 py-4 shadow">
                <div class="profile text-center">
                    <img src="assets\img\New\pallavi.jpg" alt="" class="rounded-circle img-fluid w-50">
                    <div class="mt-2">
                    <a href="mentor-details.php" class="text-primary">View Profile</a>
                    </div>
                </div>
                <div class="details">
                    <h4 class="text-primary mb-0">Isha Sharma</h4>
                    <p class="m-0">() + 24 more</p>
                    <p class="m-0">7 years experience overall</p>
                    <p class="m-0">MBA (Finance) & PG Diploma in Career Counselling</p>
                    <h4 class="mt-2 mb-0">₹199 consultation fee</h4>
                    <span><span class="badge bg-warning"><i class="fa fa-star"></i> 4.7 </span> 7 student reviews</span>

                </div>
                <div class="book">
                    <a href="mentor-details.php" class="btn btn-primary">Book appointment <div class="fw-bold"
                            style="font-size: 10px;">Schedule a consultation</div></a>

                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php') ?>