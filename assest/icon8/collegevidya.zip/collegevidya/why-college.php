<?php include("header.php");?>

    <div class="why-college-section">
        
    </div>

<?php include("footer.php");?>