<?php include('header.php') ?>

<div class="container my-5">
    <div class="justify-content-center row">
        <div class="col-lg-8">
            <div class="border shadow row pb-3">

                <div class="card border-0 col-6">
                    <div class="card-body border-end">
                        <h4>Confirm & Pay</h4>
                        <p>Verified Mentors online now</p>
                        <div class="mentor-img mb-3">
                            <img src="assets\img\New\isha-sharma.jpg" alt="" class="img-fluid rounded-circle">
                        </div>
                        <h6>One of them will speak to you shortly.</h6>
                        <span>
                            <p>93% of users found online consultation helpful.</p>
                        </span>
                        <span>
                            <p> Consultation will include video, audio and chat.</p>
                        </span>
                        <p class="fw-bold">Final Fee</p>
                        <div class="d-flex align-items-center">
                            <div>
                                <h3 class="fw-bold">₹199</h3>

                            </div>
                            <div style="text-decoration-line: line-through;color: rgb(200, 200, 200);">₹499</div>
                            <div>
                                <span class="badge bg-warning p-2 ms-3">
                                    Deal of the day
                                </span>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary">Proceed now &nbsp;&nbsp;<i class="fa fa-handshake-o text-light" aria-hidden="true"></i></button>
                        </div>
                        
                    </div>

                </div>
                <div class=" col-6">
                    <div class="text-center">
                        <div class="justify-content-center align-items-center mt-1">
                            <img src="assets\img\New\payment.png" alt="" class="img-fluid rounded-circle">
                        </div>
                        <div class="mb-1">
                            <h4 >#Irreversible Decision</h4>
                            
                            <span>
                                <p> Connect with Senior Mentor and select best online university according to your needs!</p>
                            </span>
                        </div>
                        
                        
                    </div>

                </div>


            </div>
        </div>
    </div>
</div>

<?php include('footer.php') ?>