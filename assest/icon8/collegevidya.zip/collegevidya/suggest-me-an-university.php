<?php include("header.php");?>
    <section class="suggest-me">
        <div class="container">
            <div class="row px-md-2 suggest-me-row">
                <div class="col-md-6 d-flex justify-content-center align-items-center flex-column">
                    <div class="suggest-left"> 
                        <div class="d-flex align-items-start desk-on"> 
                            <p><i class="fa-solid fa-book"></i> AI University Finder </p>
                        </div>
                        <h1>Just a few steps away from your dream career</h1>
                        <p> With tons of information online, we are here to make your life simpler. We want to take your load off and help you choose the best for your career. Education Emplotability Emptloyment empowers you to choose the best from the rest of the
                            colleges and universities out there.&nbsp; With the given compare feature, you can scroll down on our website comparing different universities with one another. You can pick the best option that suits you considering
                            the parameters of the E-learning system, EMI, fees, faculty and placement cells offering. We have more than 75+ distance online universities that you can compare from! We can’t wait for you to try! </p> 
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="suggest-right">
                        <form id="suggestregForm" action="online-distance.php" method="POST"> 

                            <marquee class="suggest-marquee">5,00,000+ Students received their right university from this AI powered tool.</marquee>
                            
                            <button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display: inline;">
                              <img style="width: 15px;" src="assets/img/icon/next-black.png" />
                            </button>
                                <img class="suggest-dot-img" src="assets/img/icon/suggest-dot.svg" />
                            <p class="text-white text-center mb-0 fs-4">#Chunowahijohaisahi</p>
                            <p class="up-head">Get Best Online University in 2 mins     </p>
                            
                            <div class="mb-3 text-center" id="step_sub_compare">
                                <span class="step finish">1</span>
                                <span class="step active">2</span>
                                <span class="step">3</span>
                                <span class="step">4</span>
                                <span class="step">5</span>
                                <span class="step">6</span>
                                <span class="step">7</span>
                                <span class="step">8</span>
                            </div>

                            <div class="tab" style="display: none;">
                                <p class="text-center font-weight-bold suggest-head">Select Distance &amp; Online Course</p>
                                <div class="form-check-wrapper">
                                    <div class="form-check">
                                        <input class="form-check-input d-none category" type="radio" value="online-distance-pg-course" name="category" id="exampleRadios1" required="" />
                                        <label class="form-check-label" for="exampleRadios1"> Online Master's Programs </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none category" type="radio" value="online-distance-ug-course" name="category" id="exampleRadios2" required="" />
                                        <label class="form-check-label" for="exampleRadios2"> Online Bachelor's Programs </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none category" type="radio" value="online-distance-diploma-certificate" name="category" id="exampleRadios4" required="" />
                                        <label class="form-check-label" for="exampleRadios4"> Online Diploma &amp; Certificate Programs </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none category" type="radio" value="online-distance-study-abroad" name="category" id="exampleRadios5" required="" />
                                        <label class="form-check-label" for="exampleRadios5"> Study Abroad </label>
                                    </div>
                                </div>
                            </div>

                            <span id="getcat">
                                <div class="tab" >
                                    <p class="text-center font-weight-bold suggest-head">Select Distance &amp; Online Course</p>
                                    <div class="form-check-wrapper">
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-distance-mba" name="course" id="exampleRadios28" required="" />
                                            <label class="form-check-label" for="exampleRadios28"> MBA </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-distance-mca" name="course" id="exampleRadios29" required="" />
                                            <label class="form-check-label" for="exampleRadios29"> MCA </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-distance-mcom" name="course" id="exampleRadios30" required="" />
                                            <label class="form-check-label" for="exampleRadios30"> M.Com </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-distance-ma" name="course" id="exampleRadios31" required="" />
                                            <label class="form-check-label" for="exampleRadios31"> MA </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="m-tech-for-working-professionals" name="course" id="exampleRadios37" required="" />
                                            <label class="form-check-label" for="exampleRadios37"> M.Tech </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-distance-msc" name="course" id="exampleRadios39" required="" />
                                            <label class="form-check-label" for="exampleRadios39"> M.Sc </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none course" type="radio" value="online-executive-mba" name="course" id="exampleRadios43" required="" />
                                            <label class="form-check-label" for="exampleRadios43"> Executive MBA (1 Year) </label>
                                        </div>
                                    </div>
                                </div>
                                
                            </span>

                            <span id="subnew">
                                <div class="tab">
                                    <p class="text-center font-weight-bold suggest-head">Select Specialization</p>
                                    <div class="form-check-wrapper">
                                        <div class="form-check">
                                            <select class="form-select specialization" name="specialization" id="specialization">
                                                <option value="finance-management">Finance</option>
                                                <option value="hr-management">HR</option>
                                                <option value="hospitality-management">Hospitality Management</option>
                                                <option value="marketing-management">Marketing</option>
                                                <option value="banking-finance-management">Banking Finance</option>
                                                <option value="marketing-and-finance-management">Marketing And Finance</option>
                                                <option value="information-technology-management">Information Technology</option>
                                                <option value="logistics-and-supply-chain-management">Logistics And Supply Chain</option>
                                                <option value="marketing-and-hr-management">Marketing And HR</option>
                                                <option value="operations-management">Operations</option>
                                                <option value="data-science-and-analytics-management">Data Science And Analytics</option>
                                                <option value="business-analytics">Business Analytics</option>
                                                <option value="hrm-and-finance-management">HRM And Finance Management</option>
                                                <option value="healthcare-management">Healthcare Management</option>
                                                <option value="digital-marketing-e-commerce-management">Digital Marketing E Commerce</option>
                                                <option value="business-management">Business Management</option>
                                                <option value="international-business-management">International Business Management</option>
                                                <option value="project-management">Project Management</option>
                                                <option value="finance-and-leadership-management">Finance And Leadership</option>
                                                <option value="financial-markets-management">Financial Markets</option>
                                                <option value="general-management">General</option>
                                                <option value="banking-financial-services-and-insurance-bfsi">Banking Financial Services and Insurance</option>
                                                <option value="entrepreneurship-and-leadership">Entrepreneurship and Leadership</option>
                                                <option value="business-intelligence-and-analytics">Business Intelligence And Analytics</option>
                                                <option value="advertising-and-branding">Advertising and Branding</option>
                                                <option value="system-and-operations-management">System And Operations</option>
                                                <option value="hospital-administration">Hospital Administration</option>
                                                <option value="business-intelligence-ai">Business Intelligence &amp; AI</option>
                                                <option value="oil-and-gas-management">Oil and Gas Management</option>
                                                <option value="international-trade-management">International Trade</option>
                                                <option value="fintech-management">Fintech</option>
                                                <option value="retail-management">Retail</option>
                                                <option value="tourism-management">Tourism Management</option>
                                                <option value="investment-banking-equity-research-management">Investment Banking Equity Research</option>
                                                <option value="international-finance-management">International Finance</option>
                                                <option value="power-management">Power Management</option>
                                                <option value="sports-management">Sports Management</option>
                                                <option value="hr-analytics">HR Analytics</option>
                                                <option value="digital-entrepreneurship">Digital Entrepreneurship</option>
                                                <option value="leadership-and-strategy">Leadership and Strategy</option>
                                                <option value="strategic-hr-management">Strategic HR Management</option>
                                                <option value="banking-and-insurance">Banking and Insurance</option>
                                                <option value="strategic-marketing">Strategic Marketing</option>
                                                <option value="strategic-finance-management">Strategic Finance</option>
                                                <option value="international-marketing-management">International Marketing</option>
                                                <option value="artificial-intelligence-and-machine-learning">Artificial Intelligence and Machine Learning</option>
                                                <option value="blockchain-management">Blockchain Management</option>
                                                <option value="waste-management">Waste Management</option>
                                                <option value="it-and-fintech">IT and FinTech</option>
                                            </select>
                                            <input type="hidden" value="49" id="myInputss" name="specializationcount" />
                                            <label class="form-check-label d-none" for="exampleRadiosfg"></label>
                                        </div>
                                    </div>
                                </div>
                            </span>

                            <div class="tab">
                                <p class="text-center font-weight-bold suggest-head">Are you Currently Working ?</p>
                                <div class="form-check-wrapper">
                                    <div class="form-check">
                                        <input class="form-check-input d-none working" type="radio" name="working" id="working1" value="YES" required="" />
                                        <label class="form-check-label" for="working1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none working" type="radio" name="working" id="working2" value="NO" required="" />
                                        <label class="form-check-label" for="working2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <span id="question">
                                <div class="tab">
                                    <p class="text-center font-weight-bold suggest-head">Your Highest Qualification?</p>
                                    <div class="form-check-wrapper">
                                        <div class="form-check">
                                            <input class="form-check-input d-none Qualification" type="radio" name="qualification" id="Qualification1" value="College Graduate" required="" />
                                            <label class="form-check-label" for="Qualification1">
                                                College Graduate
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Qualification" type="radio" name="qualification" id="Qualification2" value="Completed 12th" required="" />
                                            <label class="form-check-label" for="Qualification2">
                                                Completed 12th
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Qualification" type="radio" name="qualification" id="Qualification3" value="Completed 10th" required="" />
                                            <label class="form-check-label" for="Qualification3">
                                                Completed 10th
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Qualification" type="radio" name="qualification" id="Qualification4" value="Diploma Holder" required="" />
                                            <label class="form-check-label" for="Qualification4">
                                                Diploma Holder
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Qualification" type="radio" name="qualification" id="Qualification5" value="ITI" required="" />
                                            <label class="form-check-label" for="Qualification5">
                                                ITI
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </span>

                            <span id="abroad">
                                <div class="tab">
                                    <p class="text-center font-weight-bold suggest-head">Select Your Budget Options ?</p>
                                    <div class="form-check-wrapper">
                                        <div class="form-check">
                                            <input class="form-check-input d-none Budget" type="radio" name="rate_para" id="Budget1" value="Less than 60,000" required="" />
                                            <label class="form-check-label" for="Budget1">
                                                Less than 60,000
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Budget" type="radio" name="rate_para" id="Budget2" value="60,000 to 1 lac" required="" />
                                            <label class="form-check-label" for="Budget2">
                                                60,000 to 1 lac
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Budget" type="radio" name="rate_para" id="Budget3" value="1 lac to 1.9 lac" required="" />
                                            <label class="form-check-label" for="Budget3">
                                                1 lac to 1.9 lac
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Budget" type="radio" name="rate_para" id="Budget4" value="2 lac to 3.5 lac" required="" />
                                            <label class="form-check-label" for="Budget4">
                                                2 lac to 3.5 lac
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Budget" type="radio" name="rate_para" id="Budget5" value="3.6 lac +" required="" />
                                            <label class="form-check-label" for="Budget5">
                                                3.6 lac +
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab">
                                    <p class="text-center font-weight-bold suggest-head">How many Study Hours can you Dedicate on the Weekly Basis?</p>
                                    <div class="form-check-wrapper">
                                        <div class="form-check">
                                            <input class="form-check-input d-none Hours" type="radio" name="rate_hour" id="Hours1" value="2-4 Hours" required="" />
                                            <label class="form-check-label" for="Hours1">
                                                2-4 Hours
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Hours" type="radio" name="rate_hour" id="Hours2" value="4-8 Hours" required="" />
                                            <label class="form-check-label" for="Hours2">
                                                4-8 Hours
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Hours" type="radio" name="rate_hour" id="Hours3" value="8-16 Hours" required="" />
                                            <label class="form-check-label" for="Hours3">
                                                8-16 Hours
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input d-none Hours" type="radio" name="rate_hour" id="Hours4" value="16+ Hours" required="" />
                                            <label class="form-check-label" for="Hours4">
                                                16+ Hours
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </span>

                            <div class="tab">
                                <p class="text-center font-weight-bold suggest-head">What matters to you more?</p>
                                <div class="form-check-wrapper">
                                    <div class="form-check">
                                        <input class="form-check-input d-none matters" type="radio" name="matters" id="matters1" value="The Right University +Right Course" required="" />
                                        <label class="form-check-label" for="matters1">
                                            The Right University +Right Course
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none matters" type="radio" name="matters" id="matters2" value="Less Fee Structure" required="" />
                                        <label class="form-check-label" for="matters2">
                                            Less Fee Structure
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input d-none matters" type="radio" name="matters" id="matters3" value=" I only care about the degree" required="" />
                                        <label class="form-check-label" for="matters3">
                                            I only care about the degree
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="tab submit-section">
                                <p class="text-center font-weight-bold suggest-head">Select Best University</p>
                                <div class="form-check-wrapper suggest-form-wrap">
                                    <div class="form-group">
                                        <input type="text" class="form-control forms" name="name" id="name" placeholder="Enter Name" required="" />
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control forms" name="email" id="email" placeholder="Enter Email" required="" />
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control forms" name="mobile" id="number" pattern="^\d{10}$" placeholder="Enter Number" required="" />
                                    </div>
                                     
                                    <div class="form-group">
                                        <select class="form-select" name="city" required="">
                                            <option value="Delhi">Delhi</option>
                                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option value="Uttarakhand">Uttarakhand</option>
                                            <option value="West Bengal">West Bengal</option>
                                            <option value="Punjab">Punjab</option>
                                            <option value="Rajasthan">Rajasthan</option>
                                            <option value="Sikkim">Sikkim</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="Telangana">Telangana</option>
                                            <option value="Tripura">Tripura</option>
                                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option value="Assam">Assam</option>
                                            <option value="Bihar">Bihar</option>
                                            <option value="Chandigarh">Chandigarh</option>
                                            <option value="Chhattisgarh">Chhattisgarh</option>
                                            <option value="Goa">Goa</option>
                                            <option value="Gujarat">Gujarat</option>
                                            <option value="Haryana">Haryana</option>
                                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option value="Jammu &amp; Kashmir">Jammu &amp; Kashmir</option>
                                            <option value="Jharkhand">Jharkhand</option>
                                            <option value="Karnataka">Karnataka</option>
                                            <option value="Kerala">Kerala</option>
                                            <option value="Lakshadweep">Lakshadweep</option>
                                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option value="Maharashtra">Maharashtra</option>
                                            <option value="Manipur">Manipur</option>
                                            <option value="Meghalaya">Meghalaya</option>
                                            <option value="Mizoram">Mizoram</option>
                                            <option value="Nagaland">Nagaland</option>
                                            <option value="Orissa">Orissa</option>
                                            <option value="Puducherry">Puducherry</option>
                                            <option value="Andaman &amp; Nicobar Islands">Andaman &amp; Nicobar Islands</option>
                                            <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                                            <option value="Daman and Diu">Daman and Diu</option>
                                            <option value="Ladakh">Ladakh</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <span class="text-white">Date of Birth :</span>
                                        <input type="date" name="age" class="form-control forms" title="Please enter valid age" maxlength="2" required="" />
                                    </div>
                                </div>
                            </div>
 
                            <div class="suggest-nav-btn-wrap" style="overflow: auto;">
                                <div class="ps-3">
                                    <p class="m-0 sub-text">
                                       <svg style="position: absolute; left: 6px;" xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 20 20" fill="#1acc8d">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                        </svg>
                                        <span id="subcourse_idss" class="showdata1"> 38 
                                            <input type="hidden" value="38" id="countcs" /> 
                                        </span> 
                                        <span id="sp" class="sp"></span> University Found
                                    </p>
                                    <p class="m-0 sub_text">Matching above criteria</p>
                                </div> 
                                <button type="submit" id="nextBtn" name="submit" onclick="nextPrev(1)" style="display:none;">next</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="faq-section">
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3>Frequently  <span> asked </span>questions</h3>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    What is ‘Suggest Me a University’?
                                    <i class="fa-solid fa-angle-up"></i>
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Suggest Me a University is a feature to help individuals get the most suited Online university for them according to their budget, qualifications,student ratings, preference and much more.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    How does it work?
                                    <i class="fa-solid fa-angle-up"></i>
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Our AL-powered feature goes through various top online universities according to your preference and presents a specially designed dedicated list just for you to choose from.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Do I have to pay any fee to Education Emplotability Emptloyment for suggesting me a university?
                                    <i class="fa-solid fa-angle-up"></i>
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    No, Education Emplotability Emptloyment does not charge any sort of fees. Any person asking for fees or money on the pretext of Education Emplotability Emptloyment should be reported at 18003097947
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingfour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                    Are the universities suggested by Education Emplotability Emptloyment approved?
                                    <i class="fa-solid fa-angle-up"></i>
                                </button>
                            </h2>
                            <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Every university suggested by Education Emplotability Emptloyment is UGC/DEB and AICTE approved with all the required government certifications. To know about approvals required before choosing a university, kindly see this video- watch video
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include("footer.php");?>

