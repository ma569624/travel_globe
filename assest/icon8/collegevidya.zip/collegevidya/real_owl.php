
<div class="container mt-5">
    <div class="row  text-center mt-5">
        <h4>Real Advice from Real Experts</h4>
        <p>Education Emplotability Emptloyment has more than 2500+ mentors who work closely with you to give a realistic viewpoint about
            your
            career goals and
            enable you to build a successful career.</p>

        <div class="row mt-4 owl-carousel owl-carousel-1">
            <!-- The slideshow/carousel -->



            <div class="item1 mx-4">
                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets/img/New/Joshi-sir.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Ashok Joshi</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>

            </div>
            <div class="item2 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\Ankit Singh.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Ankit Singh</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>
            <div class="item3 mx-4 ">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\eexpert-team3.jpg"
                        alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Ashok Joshi</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>
            <div class="item4 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\Neeta.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Neeta</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>
            <div class="item5 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\preeti.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">preeti</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>
            <div class="item6 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\pallavi.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">pallavi</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>
            <div class="item7 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\Tabassum.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Tabassum</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>

            <div class="item8 mx-4">

                <div class="card border-0">
                    <img class="card-img-top rounded-circle w-70" src="assets\img\New\isha-sharma.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">isha-sharma</h4>

                        <a href="mentor-details.php" class="btn btn-primary">Know More</a>
                    </div>
                </div>
            </div>

        </div>


    </div>

</div>