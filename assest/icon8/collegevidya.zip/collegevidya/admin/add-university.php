<?php include 'header.php' ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Add University</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                                <li class="breadcrumb-item active">Add University</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Add New University</h4>

                            <form>
                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="name" class="form-label">University Name</label>
                                            <input type="text" class="form-control" id="name"
                                                placeholder="Enter University name">
                                        </div>
                                    </div>

                                </div>

                                <div class="row-flex d-flex flex-wrap mb-4 justify-content-between">

                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="UGC" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                        UGC
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="AICTE" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            AICTE 
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="AIU" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                        AIU
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="NAAC A" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                        NAAC A
                                        </label>
                                    </div>


                                </div>


                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="image" class="form-label">University Image</label>
                                            <input type="file" class="form-control" id="image"
                                                placeholder="Enter University name">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="choice" class="form-label">Student Choice</label>
                                            <input class="form-control" type="number"
                                                placeholder="Enter Student Choice In Number Out 5" id="choice">
                                        </div>


                                    </div>

                                </div>
                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="fee" class="form-label">Semester Fee In Rs</label>
                                            <input class="form-control" type="number"
                                                placeholder="Enter Student Choice In Number Out 5" id="fee">
                                        </div>


                                    </div>

                                </div>
                                <div class="row-flex d-flex flex-wrap">

                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            Default checkbox
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            Default checkbox
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            Default checkbox
                                        </label>
                                    </div>


                                </div>




                                <div class="row">

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="formrow-inputState" class="form-label">Reviews</label>
                                            <input class="form-control" type="number" placeholder="Enter Review"
                                                id="reviews">
                                        </div>
                                    </div>


                                </div>

                                <div class="row">

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="formrow-inputState" class="form-label">Status</label>
                                            <select id="formrow-inputState" class="form-select">
                                                <option selected>Select Status</option>
                                                <option value="active"> Active </option>
                                                <option value="deactive"> Deactive </option>

                                            </select>
                                        </div>
                                    </div>


                                </div>


                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                                </div>
                            </form>

                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
            </div>







        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->



    <?php include('footer.php') ?>