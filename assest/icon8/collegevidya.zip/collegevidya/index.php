<?php include("header.php"); ?>
<!--  slider 
<section class="slider">
    <div class="owl-carousel owl-theme home_slider">
        <div class="item">
            <div class="home_slide_content">
                <div class="img">
                    <img src="assets/img/home_slider/slide1.jpg" class="img-fluid" alt="">
                </div>
                <div class="content">
                    <span class="span_content">Starting with Acadu best learning Center</span>
                    <h1>Get your best career by</h1>
                    <h1>practicing with Acadu</h1>
                    <p>World class learning for anyone, anywhere for Increasing Knowledge. Let your creativity shine and
                        start bighting your future today and impress your audiences.</p>
                    <div class="btn-wrap">
                        <div class="read-more">
                            <a href="">Explore Courses <i class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                        <a href="" class="video-link popup-video" tabindex="0">
                            <span class="play-btn"><i class="fas fa-play"></i></span>
                            <span class="btn-text">Watch Video</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="home_slide_content">
                <div class="img">
                    <img src="assets/img/home_slider/slide1.jpg" class="img-fluid" alt="">
                </div>
                <div class="content">
                    <span class="span_content">Starting with Acadu best learning Center</span>
                    <h1>Get your best career by</h1>
                    <h1>practicing with Acadu</h1>
                    <p>World class learning for anyone, anywhere for Increasing Knowledge. Let your creativity shine and
                        start bighting your future today and impress your audiences.</p>
                    <div class="btn-wrap">
                        <div class="read-more">
                            <a href="">Explore Courses <i class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                        <a href="" class="video-link popup-video" tabindex="0">
                            <span class="play-btn"><i class="fas fa-play"></i></span>
                            <span class="btn-text">Watch Video</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="home_slide_content">
                <div class="img">
                    <img src="assets/img/home_slider/slide1.jpg" class="img-fluid" alt="">
                </div>
                <div class="content">
                    <span class="span_content">Starting with Acadu best learning Center</span>
                    <h1>Get your best career by</h1>
                    <h1>practicing with Acadu</h1>
                    <p>World class learning for anyone, anywhere for Increasing Knowledge. Let your creativity shine and
                        start bighting your future today and impress your audiences.</p>
                    <div class="btn-wrap">
                        <div class="read-more">
                            <a href="">Explore Courses <i class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                        <a href="" class="video-link popup-video" tabindex="0">
                            <span class="play-btn"><i class="fas fa-play"></i></span>
                            <span class="btn-text">Watch Video</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="hero-shape"></div>
</section> -->
<section class="verify-section top-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="section-title">
                    <h3>University Selection</h3>
                </div>
                <div class="type-wrap ">
                    <span id="typed1" style="white-space:pre;" class="typed"></span>
                </div>
            </div>
        </div>
    </div>
    <a href="#" data-bs-toggle="modal" data-bs-target="#myModal">#Righttoselect</a><img scr="assets/img/happy_icon.png"
        class="img-fluid " style="height:50px;">
    <p>Explore, Compare, & Apply to 50+ Online Universities</p>
    <p>Unbiased & Free Comparison</p>
    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal1"> Watch Video </a>
</section>

<?php include 'home_modal.php' ?>

<section class="course-tabs pb-5">
    <div class="shape-mockup spin d-none d-xl-block">
        <img src="assets/img/icon/plus_1.png" class="img-fluid" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Our <span> Course</span></h3>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pg-course-tab" data-bs-toggle="pill"
                            data-bs-target="#pg-course" type="button" role="tab" aria-controls="pg-course"
                            aria-selected="true">PG Course </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="ug-course-tab" data-bs-toggle="pill" data-bs-target="#ug-course"
                            type="button" role="tab" aria-controls="ug-course" aria-selected="false">UG Course</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="diploma-tab" data-bs-toggle="pill" data-bs-target="#diploma"
                            type="button" role="tab" aria-controls="diploma" aria-selected="false">Diploma</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="study-abroad-tab" data-bs-toggle="pill"
                            data-bs-target="#study-abroad" type="button" role="tab" aria-controls="study-abroad"
                            aria-selected="false">Study Abroad</button>
                    </li>
                </ul>


                <div class="tab-content mt-4" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pg-course" role="tabpanel"
                        aria-labelledby="pg-course-tab" tabindex="0">
                        <div class="container d-flex justify-content-center">
                            <div class="d-flex flex-row  gap-2" style="flex-wrap: wrap;">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2 rounded-circle" height="25" weight="25"
                                                src="assets/img/mba_svg.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">MBA</h4>


                                            </div>
                                            <p class="card-text">Compare 43 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\mca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">MCA</h4>


                                            </div>
                                            <p class="card-text">Compare 13 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\msc.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">M.Sc</h4>


                                            </div>
                                            <p class="card-text">Compare 43 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\ma.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">MA</h4>


                                            </div>
                                            <p class="card-text">Compare 20 Universities</p>
                                        </div>
                                    </a>
                                </div>



                            </div>
                        </div>

                        <div class="container mt-3 d-flex justify-content-center ">
                            <div class="d-flex flex-row gap-2">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\mtech.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">M.Tech</h4>


                                            </div>
                                            <p class="card-text">Compare 4 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\mcom.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">M.Com</h4>


                                            </div>
                                            <p class="card-text">Compare 20 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">Executive MBA</h4>


                                            </div>
                                            <p class="card-text">Compare 10 Universities</p>
                                        </div>
                                    </a>
                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="ug-course" role="tabpanel" aria-labelledby="ug-course-tab"
                        tabindex="0">
                        <div class="container mt-3 d-flex justify-content-center ">
                            <div class="d-flex flex-row gap-2">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\btech.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">B.Tech</h4>


                                            </div>
                                            <p class="card-text">Compare 4 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BCA</h4>


                                            </div>
                                            <p class="card-text">Compare 20 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\ba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BA</h4>


                                            </div>
                                            <p class="card-text">Compare 14 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bcom.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">B.Com</h4>


                                            </div>
                                            <p class="card-text">Compare 27 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BBA</h4>


                                            </div>
                                            <p class="card-text">Compare 29 Universities</p>
                                        </div>
                                    </a>
                                </div>


                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="diploma" role="tabpanel" aria-labelledby="diploma-tab" tabindex="0">
                        <div class="container mt-3 d-flex justify-content-center ">
                            <div class="d-flex flex-row gap-2">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">Diploma</h4>


                                            </div>
                                            <p class="card-text">Compare 8 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">Certificate</h4>


                                            </div>
                                            <p class="card-text">Compare 19 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">CMS & ED</h4>


                                            </div>
                                            <p class="card-text">Compare 1 Universities</p>
                                        </div>
                                    </a>
                                </div>


                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="study-abroad" role="tabpanel" aria-labelledby="study-abroad-tab"
                        tabindex="0">
                        <div class="container mt-3 d-flex justify-content-center ">
                            <div class="d-flex flex-row gap-2">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BCA In USA</h4>


                                            </div>
                                            <p class="card-text">Compare 1 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BCA In UK</h4>


                                            </div>
                                            <p class="card-text">Compare 1 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BBA In UK</h4>


                                            </div>
                                            <p class="card-text">Compare 2 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BBA In Canada</h4>


                                            </div>
                                            <p class="card-text">Compare 2 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BCA In Australia</h4>


                                            </div>
                                            <p class="card-text">Compare 33 Universities</p>
                                        </div>
                                    </a>
                                </div>


                            </div>
                        </div>
                        <div class="container mt-3 d-flex justify-content-center ">
                            <div class="d-flex flex-row gap-2">

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BBA In Australia</h4>


                                            </div>
                                            <p class="card-text">Compare 4 Universities</p>
                                        </div>
                                    </a>

                                </div>
                                <div class="items">

                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\bba.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">BBA In Germany</h4>


                                            </div>
                                            <p class="card-text">Compare 1 Universities</p>
                                        </div>
                                    </a>
                                </div>

                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2" height="25" weight="25"
                                                src="assets\img\tab-icon\mca.svg" alt="Card image">
                                            <div class="card-body p-1">
                                                <h4 class="card-title">MBA In Abroad</h4>


                                            </div>
                                            <p class="card-text">Compare 2 Universities</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="items">
                                    <a class="" href="b-tech-for-working-professionals.php">
                                        <div class="card course_content tab-item">
                                            <img class="card-img pt-2 " height="25" weight="25"
                                                src="assets\img\tab-icon\bcom.svg" alt="Card image">
                                            <div class="card-body p-0">
                                                <h4 class="card-title p-0">BSc Computer Science In Germany</h4>


                                            </div>
                                            <p class="card-text">Compare 1 Universities</p>
                                        </div>
                                    </a>
                                </div>



                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="admission-guidance">
    <div class="container">
        <div class="row">


            <div class="col-md-3">
                <div class="box-addmission-guidance h-100">
                    <img src="assets\img\icon\studend (1).png" class="img-fluid">
                    <h3>5 Million +</h3>
                    <p>Students trust Education Employability Employment for providing Unbiased Counselling.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="box-addmission-guidance h-100">
                    <img src="assets\img\icon\thumb (2).png" class="img-fluid text-primary"
                        style="width: 60px;padding-top: 10px; padding-bottom:15px;">
                    <h3>50 + Approved (Only UGC-DEB)</h3>
                    <p>Online & Distance Education Colleges & Universities listed on Education Employability
                        Employment.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="box-addmission-guidance h-100">
                    <img src="assets\img\icon\hand ske (1).png" class="img-fluid">
                    <h3>Unbiased & Expert</h3>
                    <p>Guidance by our certified counselors.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="box-addmission-guidance h-100">
                    <img src="assets\img\icon\degre (1).png" class="img-fluid">
                    <h3>Degree Support</h3>
                    <p>till the student has complete his degree program.</p>
                </div>
            </div>

        </div>
    </div>
</section>
<!--
    <section class="admission-guidance">
    <div class="container">
        <div class="row">
            <div class="col-md-6 m-md-auto">
                <div class="title-area">
                    <h2 class="sec-title">What makes Education Employability Employment the best place to take admission
                        guidance in online degree education in India?</h2>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-6">
                        <div class="box-addmission-guidance">
                            <i class="fa-solid fa-user"></i>
                            <h3>5 Million +</h3>
                            <p>Students trust Education Employability Employment for providing Unbiased Counselling.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="box-addmission-guidance" style="margin-top: 30px;">
                            <i class="fa-solid fa-thumbs-up"></i>
                            <h3>50 + Approved (Only UGC-DEB)</h3>
                            <p>Online & Distance Education Colleges & Universities listed on Education Employability
                                Employment.</p>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="box-addmission-guidance">
                            <i class="fa-regular fa-handshake"></i>
                            <h3>Unbiased & Expert</h3>
                            <p>Guidance by our certified counselors.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="box-addmission-guidance" style="margin-top: 30px;">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <h3>Degree Support</h3>
                            <p>till the student has complete his degree program.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="slide-owl">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel owl-theme trusted-slide">
                    <div class="item">
                        <div class="cta-card" style="background-image: url('assets/img/slide/verify.jpg');">
                            <div class="title-area">
                                <span class="sub-title"><i class="fa-solid fa-book"></i> Popular Courses</span>
                                <h4 class="sec-title">
                                    Get The Best Courses &amp;<br />
                                    Upgrade Your Skills
                                </h4>
                            </div>
                            <div class="read-more">
                                <a href="">JOIN WITH US <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="cta-card" style="background-image: url('assets/img/slide/verify1.jpg');">
                            <div class="title-area">
                                <span class="sub-title"><i class="fa-solid fa-book"></i> Popular Courses</span>
                                <h4 class="sec-title">
                                    Get The Best Courses &amp;<br />
                                    Upgrade Your Skills
                                </h4>
                            </div>
                            <div class="read-more">
                                <a href="">JOIN WITH US <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="cta-card" style="background-image: url('assets/img/slide/verify1.jpg');">
                            <div class="title-area">
                                <span class="sub-title"><i class="fa-solid fa-book"></i> Popular Courses</span>
                                <h4 class="sec-title">
                                    Get The Best Courses &amp;<br />
                                    Upgrade Your Skills
                                </h4>
                            </div>
                            <div class="read-more">
                                <a href="">JOIN WITH US <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
-->
<!--
<section class="all-expert">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-box6">
                    <div class="img1">
                        <img src="assets/img/why_1_1.jpg" class="img-fluid" alt="why">
                    </div>

                    <div class="shape2 d-none d-xl-block">
                        <img src="assets/img/icon/circle.png" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-6 m-md-auto">

                <div class="shape1 d-none d-xl-block">
                    <img src="assets/img/icon/circle_6.png" class="img-fluid" alt="shape">
                </div>
                <div>
                    <div class="check-box">
                        <div class="icon-list">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <div class="content">
                            <h3 class="title">Telephonic Sessions</h3>
                            <p class="text">Per Day 5000+</p>
                        </div>
                    </div>
                    <div class="check-box">
                        <div class="icon-list">
                            <i class="fa-solid fa-people-carry-box"></i>
                        </div>
                        <div class="content">
                            <h3 class="title">Face-To-Face Counseling</h3>
                            <p class="text">Sessions- 3200+</p>
                        </div>
                    </div>
                    <div class="check-box">
                        <div class="icon-list">
                            <i class="fa-solid fa-pen"></i>
                        </div>
                        <div class="content">
                            <h3 class="title">Choose The Best One</h3>
                            <p class="text">with us</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="shape-expert"><img src="assets/img/icon/line_3.png" class="img-fluid" alt="shape"></div> 
            </div>

        </div>
    </div>

</section>
<section class="compare-features">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Compare <span>Features</span></h3>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 m-md-auto">
                <div class="feature-content">
                    <p>In Compare Feature of Education Employability Employment, it is not just about comparing but to
                        get all the information about colleges & universities and selecting the best from the bag full
                        of approved universities and colleges. We have listed down all the UGC-DEB approved universities
                        and colleges with other accreditations if they have any. Education Employability Employment is
                        being unbiased to give candidates the right information about each & every university which
                        eventually helps them to choose nothing but the best.</p>
                    <div class="read-more">
                        <a href="">Know More <i class="fa-solid fa-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <!-- <div class="features-shape1 d-none d-xl-block" style="right: 25%; top:10%">
                        <img src="assets/img/icon/circle_6.png" height="100px" width="100px" class="img-fluid" alt="shapes">
                    </div>
                    <div class="features-shape1 d-none d-xl-block" style="bottom: 30%; right: 10%;">
                        <img src="assets/img/icon/circle_2.png" class="img-fluid" alt="shapes">
                    </div>
                    <div class="d-flex justify-content-center">
                        <img src="assets/img/features.png" class="img-fluid" alt="">
                    </div> --
                <ul>
                    <li>
                        <div class="feature-icon-content">
                            <i class="fa-solid fa-indian-rupee-sign"></i>
                            <h3>Affordable Fees</h3>
                        </div>
                    </li>
                    <li>
                        <div class="feature-icon-content">
                            <i class="fa-solid fa-users"></i>
                            <h3>Unbiased Guidance</h3>
                        </div>
                    </li>
                    <li>
                        <div class="feature-icon-content">
                            <i class="fa-solid fa-star"></i>
                            <h3>Most Reliable</h3>
                        </div>
                    </li>
                    <li>
                        <div class="feature-icon-content">
                            <i class="fa-solid fa-user-secret"></i>
                            <h3>Easy Accessibility</h3>
                        </div>
                    </li>
                    <li>
                        <div class="feature-icon-content">
                            <i class="fa-solid fa-laptop"></i>
                            <h3>Face-to-face Counseling</h3>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="compare-features-box">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme compare-slide">
                        <div class="item">
                            <div class="compare-features-icon">
                                <div class="img-features">
                                    <img src="assets/img/features-rupay.png" class="img-fluid" alt="">
                                </div>
                                
                            </div>
                            <div class="compare-features-content">
                                <h3>Affordable Fees</h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="compare-features-icon">
                                <div class="img-features">
                                    <img src="assets/img/features-guidance.png" class="img-fluid" alt="">
                                </div>
                                
                            </div>
                            <div class="compare-features-content">
                                <h3>Unbiased Guidance</h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="compare-features-icon">
                                <div class="img-features">
                                    <img src="assets/img/features-reliable.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <div class="compare-features-content">
                                <h3>Most Reliable</h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="compare-features-icon">
                                <div class="img-features">
                                    <img src="assets/img/features-accessibility.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <div class="compare-features-content">
                                <h3>Easy Accessibility</h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="compare-features-icon">
                                <div class="img-features">
                                    <img src="assets/img/features-face-to-face.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <div class="compare-features-content">
                                <h3>Face-to-face Counseling</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> --


<section class="one-stop-solution">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Your <span>One Stop </span>Solution</h3>
                    <p>Answer simple questions and choose the best online university for you anywhere, anytime.</p>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>

                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-4 ">
                <ul>
                    <li>
                        <div class="category-list">
                            <div class="category-list_icon">
                                <i class="fa-solid fa-hand"></i>
                            </div>
                            <div class="category-list_content">
                                <h3>Select Your Desired course</h3>
                                <p>Get one step closer to your dream career with the right course</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="category-list">
                            <div class="category-list_icon">
                                <i class="fa-solid fa-book"></i>
                            </div>
                            <div class="category-list_content">
                                <h3>Fill In the Basic Details</h3>
                                <p>Help us know you better with basic information & few questions</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="category-list">
                            <div class="category-list_icon">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div class="category-list_content">
                                <h3>Explore Your Options</h3>
                                <p>Don't limit yourself, explore top universities with our specially designed list</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-md-4">
                <div class="owl-carousel owl-theme phone-screen">
                    <div class="item">
                        <img src="assets/img/screen4.png" class="img-fluid" alt="">
                    </div>
                    <div class="item">
                        <img src="assets/img/screen4.png" class="img-fluid" alt="">
                    </div>
                    <div class="item">
                        <img src="assets/img/screen4.png" class="img-fluid" alt="">
                    </div>

                </div>
            </div>
            <div class="col-md-4 ">
                <ul>
                    <li>
                        <div class="category-list">
                            <div class="category-list_icon">
                                <i class="fa-solid fa-code-compare"></i>
                            </div>
                            <div class="category-list_content">
                                <h3>Compare & Apply</h3>
                                <p>Compare top universities on various aspects to find the best & then directly apply to
                                    the university with ‘Proceed To University’</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="category-list">
                            <div class="category-list_icon">
                                <i class="fa-sharp fa-solid fa-venus-double"></i>
                            </div>
                            <div class="category-list_content">
                                <h3>With You, For You</h3>
                                <p>Call our team of experts for all your queries and questions.</p>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>
        </div>

    </div>
</section>
<section class="real-advice">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Real <span>Advice from Real </span> Experts</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae sed aspernatur accusantium
                        vitae officiis eaque atque. Officiis alias asperiores tempora hic, ipsum ea fuga eius in
                        voluptatum, magni itaque. Ea!</p>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel owl-theme real-experts">
                    <div class="item">
                        <div class="real-experts-content">
                            <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                            <h3>Rahul Gupta </h3>
                            <h4><a href="">Consult Now</a></h4>
                            <a href="" class="real-experts-btn">
                                <img src="assets/img/icon/arrow.svg" class="img-fluid" alt="">

                                Know More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->



<section class="our-testimonial">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="our-testimonial-heading">
                    <span class="sub-title"><i class="fa-solid fa-book"></i> Happy Students</span>
                    <h2>Our Student's Says</h2>
                    <h3>About Our University</h3>
                </div>
                <div class="read-more">
                    <a href="">GIVE FEEDBACK <i class="fa-solid fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="owl-carousel owl-theme testimonial-slide">
                    <div class="item">
                        <div class="testimonial-slide-content">
                            <p>Vectors restore is intermandateds ideas with 24/365 quality vectors Assertively seize
                                extensible leadership skills for revolutionary array of technology extensive materials.
                                Energistically procrastinate market driven growth strategies whereas excellent process
                                Intrinsicly unleash cost effective applications</p>
                            <h3>Abraham Khalil</h3>
                            <span>Store Manager</span>
                            <img src="assets/img/testimonial/testimonial1.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-slide-content">
                            <p>Vectors restore is intermandateds ideas with 24/365 quality vectors Assertively seize
                                extensible leadership skills for revolutionary array of technology extensive materials.
                                Energistically procrastinate market driven growth strategies whereas excellent process
                                Intrinsicly unleash cost effective applications</p>
                            <h3>Abraham Khalil</h3>
                            <span>Store Manager</span>
                            <img src="assets/img/testimonial/testimonial1.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-slide-content">
                            <p>Vectors restore is intermandateds ideas with 24/365 quality vectors Assertively seize
                                extensible leadership skills for revolutionary array of technology extensive materials.
                                Energistically procrastinate market driven growth strategies whereas excellent process
                                Intrinsicly unleash cost effective applications</p>
                            <h3>Abraham Khalil</h3>
                            <span>Store Manager</span>
                            <img src="assets/img/testimonial/testimonial1.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section style="background-color:#030a21" class="py-sm-5 py-1 mb-5">
    <div class="container my-5">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="text-center">
                    <h2 class="main-heading h3 m-0 text-white bottom_line">Right Guidance from Experts</h2>
                </div>
                <p class="text-center text-white mb-sm-5 mb-3 mt-3">College Vidya has a team of 2500+ experts who are
                    there to assist you and give you the right guidance for your successful career ahead.</p>
            </div>
        </div>

        <div class="row mb-5">
            <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="card text-bg-light">
                        <img src="assets/img/owl.png" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <div class="box bg-light p-3 position-absolute rounded text-center" style="width:calc(100% - 32px);bottom:20px">
                                <h6 class="card-title">Rohit Pandey</h6>
                                <span class="text-primary">Sr. Mentor</span>
                                <p class="card-text"><small>6 years experience</small></p>
                                <button class="d-inline-block rounded px-3 py-1 fs-14 border" style="background-color: aliceblue;">Consult Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <!-- <div class="swiper-pagination"></div> -->
            </div>

        </div>

        <div class="col-md-8 mx-auto">
            <div class="text-center"> 
                <h2 class="main-heading h3 m-0 text-white pb-1">Registered Yourself As a Mentor
                    <!-- <a href="#"><button class="bg-success text-white rounded">Mentor</button></a> -->
                    <a href="form.php"><p class="btn d-block w-25 mx-auto btn-primary mt-3">Register Now</p></a>
                </h2>
            </div>
        </div>
        
    </div>
</section>

<section class="client-logo">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Approved <span> Online & Distance Education</span> Universities</h3>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <ul>
                    <li>
                        <img src="assets\img\collage-logo\01nmims-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\02CHandigarh-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\04Sv-uNiversity.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Acharya-Nagarjuna.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Amity-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\andhra-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\bits-pilani.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\calorx-teacger.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\dayalbaghuniversity.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Delhi-technology-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Devi-Ahilya.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\DR-cv-Raman-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\dypatil.png" class="img-fluid" width="130"
                            style="height:66px">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\guru-jambheshwar.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\hindustan_logo.jpg" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\ICFAI.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\ignou.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\imt.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\integral-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\jagannath.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Jain-University.jpg" class="img-fluid" width="130"
                            style="height:66px">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\jamia-millia-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\jnu.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\kalinga-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Karnataka-State-Open-Univesity.png" class="img-fluid"
                            width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\kuvempu-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\lingayash.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\lovely-professional .png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\maharishi-international-university.png" class="img-fluid"
                            width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\manav-rachna.png" class="img-fluid" width="130"
                            style="height:66px">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\mangalora-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\maulana -azad-national-University.png" class="img-fluid"
                            width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\patna-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\pondicherry-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\punjab-Technical-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Rajiv-gandhi-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Shivaji-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Sikkim-Manipal-University .png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Suresh-gyan-vihar-university.png" class="img-fluid"
                            width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\swami-vivekanand.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\symbiosis.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\tripura-university.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\University-of-delhi.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\University-of-kashmir.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\University-of-Kerala.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\University-of-mumbai.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\University-of-north-bengal.png" class="img-fluid" width="130"
                            height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\upes.png" class="img-fluid" width="130" height="66">
                    </li>
                    <li>
                        <img src="assets\img\collage-logo\Vidyasagar-University.png" class="img-fluid" width="130"
                            height="66">
                    </li>

                </ul>
            </div>
        </div>
    </div>
</section>

<!--
<section class="ask-us-section">
    <div class="container">
        <div class="row">
            <div class="co-md-12">
                <div class="section-title">
                    <h3>Ask us <span> anything, we'd love</span> to answer!</h3>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="Ask_us_One">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#Ask_us_collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                How is Education Employability Employment different from others ?
                            </button>
                        </h2>
                        <div id="Ask_us_collapseOne" class="accordion-collapse collapse" aria-labelledby="Ask_us_One"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>We at Collegevidya aspire to be your one-stop-solution for anything related to Higher
                                    Education Needs. We really believe that Selecting Right University matters for your
                                    better career.This means:</p>
                                <ul>
                                    <li>We only list approved (UGC-DEB) Online and Distance Universities in India and
                                        let you compare all the universities available in these modes, all in one place.
                                        You do not have to visit other websites or speak to other Counselors. It's all
                                        here, on one platform</li>
                                    <li>We remove all jargon from approval details, course details, and explain
                                        everything in plain English.</li>
                                    <li>Our experts like to keep it simple. They readily give advice, and do not force a
                                        certain University on you.</li>
                                </ul>
                                <p>But don't just blindly believe what we say. We have a 92.76% student retention rate,
                                    which is by far one of the best in india. We are also the highest-rated Higher
                                    Education website on Facebook and Google+. :)"</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="Ask_us_Two">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#Ask_us_collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Do payments made by students go directly into the university account?
                            </button>
                        </h2>
                        <div id="Ask_us_collapseTwo" class="accordion-collapse collapse" aria-labelledby="Ask_us_Two"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>Of course yes. Education Employability Employment is an information portal and it is
                                    illegal to accept payments on behalf of the university. To be honest, Education
                                    Employability Employment does not even have a bank account. All the payments made by
                                    students go directly to the University account and we request everyone to make
                                    payment only on the official website of University.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="Ask_us_Three">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#Ask_us_collapseThree" aria-expanded="false"
                                aria-controls="collapseThree">
                                What are <span> Education Employability Employment</span> Advantages?
                            </button>
                        </h2>
                        <div id="Ask_us_collapseThree" class="accordion-collapse collapse"
                            aria-labelledby="Ask_us_Three" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5><b>Trusted</b></h5>
                                        <p>We’ve been in this student support services for over 12 years with 50 lakh+
                                            Satisfied students and a rating on 4.8 on Google</p>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><b>Unbiased & Free Expert Counselling</b></h5>
                                        <p>Our student advisors help you choose the right university based on your
                                            specific needs. We are just a call away, call us at 18004205757 between 9:30
                                            am to 7 pm.</p>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-md-6">
                                        <h5><b>Proceed To University</b></h5>
                                        <p>You can directly apply to your chosen University using ‘Proceed To
                                            University’ feature. You do not have to waste time looking for the official
                                            website as this feature does the work for you by redirecting you to the
                                            official university website.</p>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><b>Coordination with University</b></h5>
                                        <p>Education Employability Employment works closely with the Universities and we
                                            ensure that Student queries are resolved immediately and you get your books,
                                            LMS etc on time!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="Ask_us_Four">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#Ask_us_collapseFour" aria-expanded="false"
                                aria-controls="collapseFour">
                                Can there be errors on Education Employability Employment?
                            </button>
                        </h2>
                        <div id="Ask_us_collapseFour" class="accordion-collapse collapse" aria-labelledby="Ask_us_Four"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>We research & we let you stay away from all the hard work. As humans we are bound to
                                    make mistakes, but at Education Employability Employment we strongly believe in
                                    corrections and rectifications too. We have a dedicated team whose aim is to provide
                                    you with accurate information. With the evolving education industry and its
                                    curriculum we are always on our toes to keep the most accurate information on our
                                    portal. In case of any misinformation found you can inform us on our info@eee.com.
                                </p>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </div>
</section>

<section class="upcoming-event">
    <div class="container z-index-common">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Upcoming <span> Events</span></h3>
                    <div class="icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="event-card">
                    <div class="event-card_img">
                        <img src="assets/img/event/event1.jpg" alt="event" />
                    </div>
                    <div class="event-card_content">
                        <div class="event-meta">
                            <p><i class="fa-solid fa-location-dot"></i> 259 Hilton Street, NewYork</p>
                            <p><i class="fa-sharp fa-solid fa-clock"></i>08:00 am - 10:00 am</p>
                        </div>
                        <h3 class="event-card_title">
                            <a href="#">What Soul Can Tech Us About Web Design</a>
                        </h3>
                        <div class="event-card_bottom">
                            <div class="event-author">
                                <div class="avater">
                                    <img src="assets/img/event/avater.jpg" alt="avater" />
                                </div>
                                <span class="author-name">David Smith</span>
                            </div>
                            <div class="read-more">
                                <a href="">Know More <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="event-card">
                    <div class="event-card_img">
                        <img src="assets/img/event/event1.jpg" alt="event" />
                    </div>
                    <div class="event-card_content">
                        <div class="event-meta">
                            <p><i class="fa-solid fa-location-dot"></i> 259 Hilton Street, NewYork</p>
                            <p><i class="fa-sharp fa-solid fa-clock"></i>08:00 am - 10:00 am</p>
                        </div>
                        <h3 class="event-card_title">
                            <a href="#">What Soul Can Tech Us About Web Design</a>
                        </h3>
                        <div class="event-card_bottom">
                            <div class="event-author">
                                <div class="avater">
                                    <img src="assets/img/event/avater.jpg" alt="avater" />
                                </div>
                                <span class="author-name">David Smith</span>
                            </div>
                            <div class="read-more">
                                <a href="">Know More <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="event-card">
                    <div class="event-card_img">
                        <img src="assets/img/event/event1.jpg" alt="event" />
                    </div>
                    <div class="event-card_content">
                        <div class="event-meta">
                            <p><i class="fa-solid fa-location-dot"></i> 259 Hilton Street, NewYork</p>
                            <p><i class="fa-sharp fa-solid fa-clock"></i>08:00 am - 10:00 am</p>
                        </div>
                        <h3 class="event-card_title">
                            <a href="#">What Soul Can Tech Us About Web Design</a>
                        </h3>
                        <div class="event-card_bottom">
                            <div class="event-author">
                                <div class="avater">
                                    <img src="assets/img/event/avater.jpg" alt="avater" />
                                </div>
                                <span class="author-name">David Smith</span>
                            </div>
                            <div class="read-more">
                                <a href="">Know More <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="event-card">
                    <div class="event-card_img">
                        <img src="assets/img/event/event1.jpg" alt="event" />
                    </div>
                    <div class="event-card_content">
                        <div class="event-meta">
                            <p><i class="fa-solid fa-location-dot"></i> 259 Hilton Street, NewYork</p>
                            <p><i class="fa-sharp fa-solid fa-clock"></i>08:00 am - 10:00 am</p>
                        </div>
                        <h3 class="event-card_title">
                            <a href="#">What Soul Can Tech Us About Web Design</a>
                        </h3>
                        <div class="event-card_bottom">
                            <div class="event-author">
                                <div class="avater">
                                    <img src="assets/img/event/avater.jpg" alt="avater" />
                                </div>
                                <span class="author-name">David Smith</span>
                            </div>
                            <div class="read-more">
                                <a href="">Know More <i class="fa-solid fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-20 mt-xl-3">
            <div class="read-more">
                <a href="">View All Events <i class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>
    <div class="upcoming-event-vector d-none d-xl-block" style="top: 20%; left: 0%;">
        <img src="assets/img/icon/dot_shape.png" alt="shapes" />
    </div>
    <div class="upcoming-event-vector d-none d-xl-block" style="top: 24%; right: 0%;">
        <img src="assets/img/icon/cloud_1.png" alt="shapes" />
    </div>
    <div class="upcoming-event-vector d-none d-xl-block" style="top: 28%; right: 0%;">
        <img src="assets/img/icon/cloud_2.png" alt="shapes" />
    </div>
</section>
-->

<?php include("footer.php"); ?>