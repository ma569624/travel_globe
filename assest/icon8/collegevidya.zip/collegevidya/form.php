<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" href="#" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css" />
    <link rel="stylesheet" href="assets/css/main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
</head>
<body class="form-page">
<div id="layout-wrapper">
<div class="main-content">
    <div class="page-content">
        <div class="container pt-5">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Add Mentor</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                <li class="breadcrumb-item active">Add Mentor</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Add New Mentor</h4>

                            <!-- /.box-header -->
                            <!-- form start -->

                            <form action="#" enctype="multipart/form-data" method="post" class="needs-validation" novalidate>
                                <div class="row">
                                
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="validationCustom01" class="form-label">Name</label>
                                            <input type="text" class="form-control" name="mentor_name" id="mentor_name" id="validationCustom01" placeholder="Enter Your Name" required/>
                                            <div class="invalid-feedback">
                                            Please enter your name.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="title" class="form-label">Job Title</label>
                                            <input type="text" class="form-control" name="mentor_title" id="mentor_title" placeholder="Enter Your Title" required/>
                                            <div class="invalid-feedback">
                                            Please enter your job title.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Gender</label>
                                            <select id="formrow-inputState" class="form-select" name="mentor_gender" required>
                                                <option selected disabled value="">Select Gender</option>
                                                <option value="Male"> Male </option>
                                                <option value="Female"> Female </option>
                                            </select>
                                            <div class="invalid-feedback">
                                            Please select a valid state.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="title" class="form-label">Languages</label>
                                            <input type="text" class="form-control" name="mentor_languages" id="mentor_languages" placeholder="Enter Your Languages" />
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="Course" class="form-label">Courses</label>
                                            <input type="text" class="form-control" name="mentor_course" id="mentor_course" placeholder="Enter Your Course" required/>
                                            <div class="invalid-feedback">
                                            Please enter a valid value.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="expression" class="form-label">Experience</label>
                                            <input type="number" class="form-control" name="mentor_expression" id="mentor_expression" placeholder="Enter Your Year Expression" required/>
                                            <div class="invalid-feedback">
                                            Please enter a valid value.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="Course" class="form-label"> Domain Name</label>
                                            <select id="formrow-inputState" class="form-select" name="mentor_domain" id="mentor_domain">
                                                <option value="" selected>Select Domain</option>
                                                <option value="PG Course"> PG Course</option>
                                                <option value="UG Course"> UG Course</option>
                                                <option value="Diploma Course"> Diploma Course</option>
                                                <option value=" Skilling & Certification"> Skilling & Certification</option>
                                                <option value="Study Abroad"> Study Abroad </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="expression" class="form-label">Education Mode</label>
                                            <select id="formrow-inputState" class="form-select" name="education_mode" required>
                                                <option selected disabled value="">Select Education Mode</option>
                                                <option value="Online"> Online</option>
                                                <option value="Distance">Distance</option>
                                                
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid state.
                                                </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="Course" class="form-label">Specialization</label>
                                            <select name="skills" multiple="" class="form-select label ui fluid dropdown">
                                                <option value=""> All Specialization </option>
                                                <option value="spe"> mba General </option>
                                                <option value="finance-management">Finance</option>
                                                <option value="hr-management">HR</option>
                                                <option value="hospitality-management">Hospitality Management</option>
                                                <option value="marketing-management">Marketing</option>
                                                <option value="banking-finance-management">Banking Finance</option>
                                                <option value="marketing-and-finance-management">Marketing And Finance</option>
                                                <option value="information-technology-management">Information Technology</option>
                                                <option value="logistics-and-supply-chain-management">Logistics And Supply Chain</option>
                                                <option value="marketing-and-hr-management">Marketing And HR</option>
                                                <option value="operations-management">Operations</option>
                                                <option value="data-science-and-analytics-management">Data Science And Analytics</option>
                                                <option value="business-analytics">Business Analytics</option>
                                                <option value="hrm-and-finance-management">HRM And Finance Management</option>
                                                <option value="healthcare-management">Healthcare Management</option>
                                                <option value="digital-marketing-e-commerce-management">Digital Marketing E Commerce</option>
                                                <option value="business-management">Business Management</option>
                                                <option value="international-business-management">International Business Management</option>
                                                <option value="project-management">Project Management</option>
                                                <option value="finance-and-leadership-management">Finance And Leadership</option>
                                                <option value="financial-markets-management">Financial Markets</option>
                                                <option value="general-management">General</option>
                                                <option value="banking-financial-services-and-insurance-bfsi">Banking Financial Services and Insurance</option>
                                                <option value="entrepreneurship-and-leadership">Entrepreneurship and Leadership</option>
                                                <option value="business-intelligence-and-analytics">Business Intelligence And Analytics</option>
                                                <option value="advertising-and-branding">Advertising and Branding</option>
                                                <option value="system-and-operations-management">System And Operations</option>
                                                <option value="hospital-administration">Hospital Administration</option>
                                                <option value="business-intelligence-ai">Business Intelligence &amp; AI</option>
                                                <option value="oil-and-gas-management">Oil and Gas Management</option>
                                                <option value="international-trade-management">International Trade</option>
                                                <option value="fintech-management">Fintech</option>
                                                <option value="retail-management">Retail</option>
                                                <option value="tourism-management">Tourism Management</option>
                                                <option value="investment-banking-equity-research-management">Investment Banking Equity Research</option>
                                                <option value="international-finance-management">International Finance</option>
                                                <option value="power-management">Power Management</option>
                                                <option value="sports-management">Sports Management</option>
                                                <option value="hr-analytics">HR Analytics</option>
                                                <option value="digital-entrepreneurship">Digital Entrepreneurship</option>
                                                <option value="leadership-and-strategy">Leadership and Strategy</option>
                                                <option value="strategic-hr-management">Strategic HR Management</option>
                                                <option value="banking-and-insurance">Banking and Insurance</option>
                                                <option value="strategic-marketing">Strategic Marketing</option>
                                                <option value="strategic-finance-management">Strategic Finance</option>
                                                <option value="international-marketing-management">International Marketing</option>
                                                <option value="artificial-intelligence-and-machine-learning">Artificial Intelligence and Machine Learning</option>
                                                <option value="blockchain-management">Blockchain Management</option>
                                                <option value="waste-management">Waste Management</option>
                                                <option value="it-and-fintech">IT and FinTech</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">From Date</label>
                                            <input class="form-control" type="date" value="2019-08-19" id="example-date-input" name="mentor_date" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">From Time</label>
                                            <input class="form-control" type="datetime-local" id="mentor_time" name="mentor_time" value="2019-08-19T13:45:00" id="example-datetime-local-input" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">To Date</label>
                                            <input class="form-control" type="date" value="2019-08-19" id="example-date-input" name="mentor_date1" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">To Time</label>
                                            <input class="form-control" type="datetime-local" id="mentor_time1" name="mentor_time1" value="2019-08-19T13:45:00" id="example-datetime-local-input" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                            
                                        <div class="mb-3">
                                            <label for="country" class="form-label">Country</label>
                                            <select id="country" class="form-select" name="mentor_country" required>
                                                <option selected disabled value="">Select Gender</option>
                                                <option value="India"> India </option>
                                                
                                            </select>
                                            <div class="invalid-feedback">
                                            Please select a valid state.
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="state" class="form-label">State</label>
                                            <span id="state-code" class="form-control" >
                                                <input type="text" class="form-control" id="state" placeholder="Enter Your Living City">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">About</label>
                                            <textarea name="about_mentor" class="form-control" placeholder="Write About Mentor" id="exampleFormControlTextarea1" rows="3"></textarea>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="formFileLg" class="form-label">Upload Mentor Image</label>
                                        <input class="form-control" type="file" name="mentor_image" required />
                                        <div class="invalid-feedback">
                                                Please select a valid Image.
                                                </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="formrow-email-input" class="form-label">Consultation Fee</label>
                                        <input class="form-control" type="number"  placeholder="Enter Consultation Fee" id="example-number-input" name="mentor_fee" required/>
                                        <div class="invalid-feedback">
                                                Please enter a valid value.
                                                </div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="formrow-inputState" class="form-label">Status</label>
                                            <select id="formrow-inputState" class="form-select" name="mentor_status" required>
                                                <option selected disabled value="">Select Status</option>
                                                <option value="active"> Active </option>
                                                <option value="deactive"> Deactive </option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid state.
                                                </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
            </div>
        </div>
        <!-- container-fluid -->
    </div>

    <footer class="footer pb-5">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <script>document.write(new Date().getFullYear())</script> © Best MBA Collage.
                </div>
            </div>
        </div>
    </footer>
</div>
</div>
     

    <script src='assets/js/jquery.min.js'></script>
    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.0/js/bootstrap.min.js'></script>
    <script src="assets/js/country-states.js"></script>
    <script src="assets/js/semantic.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('.label.ui.dropdown').dropdown();
        CKEDITOR.tools.setTimeout(function ()
        {
        }, 2000);
        const sleep = (s) =>
            new Promise((p) => setTimeout(p, (s * 1000) | 0))

        async function timeoutHandler()
        {
            await sleep(1)
            CKEDITOR.replace("about_mentor");
            let user_country_code = "IN";
            (function ()
            {
                // Get the country name and state name from the imported script.
                let country_list = country_and_states['country'];
                let states_list = country_and_states['states'];
                // creating country name drop-down
                let option = '';
                option += '<option>select country</option>';
                for (let country_code in country_list)
                {
                    // set selected option user country
                    let selected = (country_code == user_country_code) ? ' selected' : '';
                    option += '<option value="' + country_code + '"' + selected + '>' + country_list[country_code] + '</option>';
                }
                document.getElementById('country').innerHTML = option;

                // creating states name drop-down
                let text_box = '<input type="text" class="input-text border-0 w-100" id="state" placeholder="Loading...">';
                let state_code_id = document.getElementById("state-code");

                function create_states_dropdown()
                {
                    // get selected country code
                    let country_code = document.getElementById("country").value;
                    let states = states_list[country_code];
                    // invalid country code or no states add textbox
                    if (!states)
                    {
                        state_code_id.innerHTML = text_box;
                        return;
                    }
                    let option = '';
                    if (states.length > 0)
                    {
                        option = '<select id="state">\n';
                        for (let i = 0; i < states.length; i++)
                        {
                            option += '<option value="' + states[i].code + '">' + states[i].name + '</option>';
                        }
                        option += '</select>';
                    } else
                    {
                        // create input textbox if no states 
                        option = text_box
                    }
                    state_code_id.innerHTML = option;
                }

                // country select change event
                const country_select = document.getElementById("country");
                country_select.addEventListener('change', create_states_dropdown);

                create_states_dropdown();
            })(jQuery);
        }
        setTimeout(timeoutHandler, 1000)
    </script>
    <script>// Example starter JavaScript for disabling form submissions if there are invalid fields
        (() => {
        'use strict';

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        const forms = document.querySelectorAll('.needs-validation');

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms).forEach((form) => {
            form.addEventListener('submit', (event) => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
            }, false);
        });
        })();
    </script>
</body>
</html>