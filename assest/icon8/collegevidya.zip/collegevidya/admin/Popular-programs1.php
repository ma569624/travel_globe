<?php require('header.php') ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Popular Programs</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                <li class="breadcrumb-item">Popular Programs</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->



            <div class="row">

                <div class="col-md-3 ">
                    <div class="card ">
                        <h4 class="card-title text p-2 mt-3">Browse by Domains</h4>
                        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                            aria-orientation="vertical">
                            <a class="nav-link mb-2 active" id="v-pills-pg-tab" data-bs-toggle="pill"
                                href="#v-pills-pg" role="tab" aria-controls="v-pills-pg"
                                aria-selected="true">PG Course</a>
                            <a class="nav-link mb-2" id="v-pills-ug-tab" data-bs-toggle="pill"
                                href="#v-pills-ug" role="tab" aria-controls="v-pills-ug"
                                aria-selected="false">UG Course</a>
                            <a class="nav-link mb-2" id="v-pills-Diploma-tab" data-bs-toggle="pill"
                                href="#v-pills-Diploma" role="tab" aria-controls="v-pills-Diploma"
                                aria-selected="false">Diploma Courses</a>
                            <a class="nav-link" id="v-pills-skilling-tab" data-bs-toggle="pill" href="#v-pills-skilling"
                                role="tab" aria-controls="v-pills-skilling" aria-selected="false">Skilling & Certificate</a>
                            <a class="nav-link" id="v-pills-study-tab" data-bs-toggle="pill" href="#v-pills-study"
                                role="tab" aria-controls="v-pills-study" aria-selected="false">Study Abroad(On-Campus)</a>
                        </div>
                    </div>



                </div>
                <div class="col-md-9 tab-content text-muted mt-4 mt-md-0" id="v-pills-tabContent">

                    <div class="tab-pane fade show active" id="v-pills-pg" role="tabpanel"
                        aria-labelledby="v-pills-pg-tab">
                        <div class="row">
                            
                            <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 my-2"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 my-2"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 my-2"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 my-2"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 my-2"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="v-pills-ug" role="tabpanel"
                        aria-labelledby="v-pills-ug-tab">

                        <div class="col-xl-3 col-sm-6">
                                <div class="card text-left">
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <img class="rounded-circle avatar-sm" src="assets/images/users/avatar-5.jpg"
                                                alt="">
                                        </div>
                                        <h5 class="font-size-15 mb-1"><a href="javascript: void(0);"
                                                class="text-dark">Online & Distance MBA</a></h5>
                                        

                                        <div>
                                            <a href="javascript: void(0);"
                                                class="badge bg-primary font-size-11 m-1">2 Years</a>
                                        </div>

                                        <p class="text-muted my-4">Compare 45 Universites</p>
                                        <a href="javascript: void(0);"
                                                class="text-rimary">View Specialisations -></a>
                                    </div>
                                    
                                </div>
                            </div>
                    </div>
                </div>


            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-12">
                    <div class="text-center my-3">
                        <a href="javascript:void(0);" class="text-success"><i class="bx bx-hourglass bx-spin me-2"></i>
                            Load more </a>
                    </div>
                </div> <!-- end col-->
            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    
    <?php include('footer.php') ?>