<?php include("header.php"); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-4">
            <img src="assets/img/hero-img.png" class="img-fluid w-100 mt-5" alt="">
            <p>Did you now ?</p>
            <h5>Recently, UGC Declared 33 universities fake and its degrees invalid.</h5>
            <p>Save Yourself from Falling for such traps!</p>


        </div>
        <div class="col-lg-8">
            <div class="row">
                <h4>Welcome back ujjhgyhj,</h4>
                <p>Checkout Some Most Searched Online and Distance Universities</p>
                
                <ul class="list-group list-group-horizontal mt-2" style="height:">
                    <li class="list-group-item text-center" style="width: 30%;">
                        <img src="assets\img\icon\Jain-University.jpg" class="img-fluid" alt="" width="250">
                        <span class="badge bg-warning ">Jain University</span>

                    </li>

                    <li class="list-group-item hide">

                        <p class="pt-2">UGC-DEB, AICTE, NIRF NAAC A++</p>
                    </li>
                    <li class="list-group-item ">
                        <p class="pt-2">₹ 50000/ Semester </p>
                        <span class="badge bg-warning ">Loan Facility Available
                        </span>
                    </li>

                    <li class="list-group-item "><a href="online-distance.php" type="button"
                            class="btn default-btn1 btn-sm mt-3">
                            Compare</a>
                    </li>
                </ul>

                <ul class="list-group list-group-horizontal mt-2" style="height:">
                    <li class="list-group-item text-center" style="width: 30%;">
                        <img src="assets\img\icon\Jain-University.jpg" class="img-fluid" alt="" width="250">
                        <span class="badge bg-warning ">Jain University</span>

                    </li>

                    <li class="list-group-item hide">

                        <p class="pt-2">UGC-DEB, AICTE, NIRF NAAC A++</p>
                    </li>
                    <li class="list-group-item ">

                        <p class="pt-2">₹ 50000/ Semester </p>
                        <span class="badge bg-warning ">Loan Facility Available
                        </span>

                    </li>

                    <li class="list-group-item "><a href="online-distance.php" type="button"
                            class="btn default-btn1 btn-sm mt-3">
                            Compare</a>
                    </li>
                </ul>
                <ul class="list-group list-group-horizontal mt-2" style="height:">
                    <li class="list-group-item text-center" style="width: 30%;">
                        <img src="assets\img\icon\Jain-University.jpg" class="img-fluid" alt="" width="250">
                        <span class="badge bg-warning ">Jain University</span>

                    </li>

                    <li class="list-group-item hide">

                        <p class="pt-2">UGC-DEB, AICTE, NIRF NAAC A++</p>
                    </li>
                    <li class="list-group-item ">

                        <p class="pt-2">₹ 50000/ Semester </p>
                        <span class="badge bg-warning ">Loan Facility Available
                        </span>

                    </li>

                    <li class="list-group-item "><a href="online-distance.php" type="button"
                            class="btn default-btn1 btn-sm mt-3">
                            Compare</a>
                    </li>
                </ul>
                <div class="row text-center mt-3">
                    <div class="col-6">
                        <a href="online-distance.php" class="btn btn-primary"> View More University </a>
                    </div>
                    <div class="col-6">
                        <a href="suggest-me-an-university.php" class="btn btn-primary"> Suggest Me an University </a>
                    </div>
                </div>


            </div>
        </div>

        <div class="row mt-5 border">
            <div class="col-lg-4">
                <img src="assets/img/btech for working professional.jpg" class="img-fluid" width="300" alt="">
            </div>
            <div class="col-lg-8 pt-3">
                <h4>B.Tech for Working Professionals</h4>
                <p>B.Tech for Working Professionals is a bachelor degree programme exclusively designed for
                    working
                    professionals with a duration of either 3 years (6 semesters) or 3.5 years (7 semesters).
                    This
                    programme is suitable for the candidates who want to pursue higher education degrees for
                    professional growth and simultaneously managing regular jobs . As B.Tech through distance
                    mode
                    is invalid, AICTE allowed universities to enroll candidates in B.Tech for working
                    professionals
                    course.</p>

                <div class="row">
                    <div class="col-6">
                        <a href="https://www.youtube.com/watch?v=Diao6b6lfpE" target="_blank"> Watch Video <img
                                src="assets/img/video-play.png" alt="" width="40px"  ></a>
                    </div>
                    <div class="col-6">
                        <a href="#"> Listen Podcast <img src="assets/img/Listen.png" alt=""></a>
                    </div>

                </div>
            </div>
        </div>

        <div class="row border mt-5 p-3 ps-5">

            <div class="row text-center bg-info pt-2">
                <div class="col-4 ">
                    <h5> Approvals </h5>
                    <p>UGC | AICTE | NAAC</p>
                </div>
                <div class="col-4">
                    <h5>Duration</h5>
                    <p>3 - 3.5 Years</p>
                </div>
                <div class="col-4">
                    <h5>Eligibility</h5>
                    <p>Diploma/Polytechnic pass out</p>
                </div>

            </div>
            <div class="row mt-5">
                <p>The classes for B.Tech working professionals are hosted in such a fashion that suits working
                    professionals either in the evenings or at weekends. B.Tech in various branches such as Mechanical,
                    CS, Civil, Electronics is offered for working professionals. <a href="#"
                        class="text-primary">B.Tech. For Working Professionals: The
                        Definitive Guide (2020-2021).</a></p>
            </div>
            <div class="row mt-5">
                <img src="assets/img/CVCourse-Pursue-B.Tech_.png" alt="">
            </div>
            <h4>Key Highlights of B.Tech for Working Professionals Programme/WILP</h4>
            <ul class="ms-4" style="list-style: unset;">
                <li>Candidates must have passed Diploma/Polytechnic. </li>
                <li>The course duration is between 3 - 3.5 years based on your last qualifications. </li>
                <li>For Diploma professionals, B.Tech for Working Professionals programme is for 3 years duration. </li>
                <li>B.Tech for working professionals programme fees costs less than the regular mode fees.</li>
                <li>Industry-related updated Curriculum.</li>
                <li>Similar value as Regular B.Tech.</li>
            </ul>
            <h4 class="mt-2">Who is this program for?</h4>
            <ul class="ms-4" style="list-style: unset;">
                <li>Students who have recently passed Diploma/Polytechnic. </li>
            </ul>
            <h4 class="mt-3">Course Specialisations for B.Tech Working Professionals</h4>
            <ul class="ms-4" style="list-style: unset;">
                <li><a href="#" class="text-primary">B.Tech Civil Engineering</a></li>
                <li><a href="#" class="text-primary">B.Tech Mechanical Engineering</a></li>
                <li><a href="#" class="text-primary">B.Tech Computer Science Engineering </a></li>
                <li><a href="#" class="text-primary">B.Tech Electronics & Communication Engineering</a></li>
                <li><a href="#" class="text-primary">B Tech Mechanical And Automobile Engineering</a></li>
            </ul>
            <h4 class="mt-2">Job Prospects After B.Tech for Working Professionals/WILP</h4>
            <ul class="ms-4" style="list-style: unset;">
                <li>
                    <p> <b>Higher Studies: </b> After completion of B.Tech, you can pursue M.Tech through IITs,NITs &
                        reputed national level colleges by writing GATE exam. Also,one can pursue MBA after doing B
                        Tech.
                    </p>
                </li>
                <li>
                    <p><b>Enter Ever Growing Private Sector: </b>With a B.Tech degree combined with industrial
                        experience will enhance your salary multifold and provide you opportunities to explore more in
                        the relevant industry.</p>
                </li>
                <li>
                    <p><b>Enter PSU and Government Sectors: </b> Various PSUs such as NTPC, BHEL, ONGC,etc. release
                        vacancies for B.Tech with relevant experience. Also, the government bodies such as the Indian
                        Army, Navy and Airforce, PWD, Electrical Departments of states have a direct entry on the
                        qualifications and experience.</p>
                </li>
                <li>
                    <p><b>Campus Placements: </b>The campus placement drive gives you the opportunities to be hired in
                        highly reputed MNCs.
                    </p>
                </li>
            </ul>

            <div class="row">
                <img src="assets/img/CVCourse-Salary-Graph.png" alt="" class="img-fluid" style="width: 80%;">
            </div>

            <div class="row mt-3">
                <img src="assets/img/CVCourse-btech-salary.png" alt="" class="img-fluid w-100">
            </div>


        </div>


    </div>
</div>
<section class="bg mt-5">
    <div class="container">
        <div class="row">
            <div class="col-4 ">
                <h2 class="mt-5">Choose Your <br>
                    University Wisely! </h2>
                <img src="assets/img/info.png" class="img-fluid " width="90" alt="" data-bs-toggle="tooltip"
                    title="Compare universities on parameters like, Approvals, Student rating, Education Emplotability Emptloyment Score Score, LMS etc">
            </div>
            <di class="col-8">


                <div class="row  text-center ">


                    <div class="row mt-4 owl-carousel owl-carousel-1">
                        <!-- The slideshow/carousel -->



                        <div class="item1 mx-1">
                            <div class="card ">
                                <img class="card-img-top  w-100  mt-3" src="assets/img/collage/Amity-University.jpg"
                                    alt="Card image">
                                <div class="card-body">
                                    <p>Rating : 4.4/5</p>
                                    <p class="pt-0">Placement : 9.6/10</p>

                                    <a href="#" class="btn btn-primary">Compare</a>
                                </div>
                            </div>

                        </div>
                        <div class="item2 mx-1">

                            <div class="card ">
                                <img class="card-img-top  w-100  mt-3" src="assets/img/collage/Amity-University.jpg"
                                    alt="Card image">
                                <div class="card-body">
                                    <p>Rating : 4.4/5</p>
                                    <p class="pt-0">Placement : 9.6/10</p>

                                    <a href="#" class="btn btn-primary">Compare</a>
                                </div>
                            </div>
                        </div>
                        <div class="item3 mx-1">
                            <div class="card ">
                                <img class="card-img-top  w-100  mt-3" src="assets/img/collage/Amity-University.jpg"
                                    alt="Card image">
                                <div class="card-body">
                                    <p>Rating : 4.4/5</p>
                                    <p class="pt-0">Placement : 9.6/10</p>

                                    <a href="#" class="btn btn-primary">Compare</a>
                                </div>
                            </div>

                        </div>
                        <div class="item4 mx-1">
                            <div class="card ">
                                <img class="card-img-top  w-100  mt-3" src="assets/img/collage/Amity-University.jpg"
                                    alt="Card image">
                                <div class="card-body">
                                    <p>Rating : 4.4/5</p>
                                    <p class="pt-0">Placement : 9.6/10</p>

                                    <a href="#" class="btn btn-primary">Compare</a>
                                </div>
                            </div>

                        </div>
                        <div class="item5 mx-1">

                            <div class="card ">
                                <img class="card-img-top  w-100  mt-3" src="assets/img/collage/Amity-University.jpg"
                                    alt="Card image">
                                <div class="card-body">
                                    <p>Rating : 4.4/5</p>
                                    <p class="pt-0">Placement : 9.6/10</p>

                                    <a href="#" class="btn btn-primary">Compare</a>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
        </div>
    </div>
    </div>
</section>

<section class="container mb-5">
    <div class="row">
        <h2 class="text-center mt-5">B Tech for Working Professionals FAQ</h2>

    </div>
    <div class="row ">
        <div id="accordion">

            <div class="card">
                <div class="card-header">
                    <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                        <i class="fa fa-hand-o-right"></i> Is B.Tech WILP degree valid?
                    </a>
                </div>
                <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        If your university is AICTE approved, the degree is valid for B.Tech WILP. B. Tech WILP is
                        allowed as per AICTE norms.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
                        <i class="fa fa-hand-o-right"></i> How good is B.Tech WILP?
                    </a>
                </div>
                <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        B.Tech WILP is good as you get a degree as well as work experience with you. The combination of
                        degree and experience makes you a good candidate in the market.
                    </div>
                </div>
            </div>

            <div class="card">

                <div class="card-header">
                    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
                        <i class="fa fa-hand-o-right"></i> Is WILP AICTE approved?
                    </a>
                </div>
                <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        Yes, B.Tech WILP is AICTE approved.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <a class="btn" data-bs-toggle="collapse" href="#collapse4">
                        <i class="fa fa-hand-o-right"></i> What are the universities offering this course?
                    </a>
                </div>
                <div id="collapse4" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        Some top universities offering B.Tech WILP are DTU, Lingayas University, Jamia Millila Islamia,
                        SV University, BITS.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse5">
                        <i class="fa fa-hand-o-right"></i> Is B.Tech. WILP is good for future growth?
                    </a>
                </div>
                <div id="collapse5" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        Yes, B.Tech WILP has a future growth as after passing out from it gives you edge due to the work
                        experience.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse6">
                        <i class="fa fa-hand-o-right"></i> What Salary packages I can expect after b tech course?
                    </a>
                </div>
                <div id="collapse6" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        The average salary package offered after completion of this course ranges from 8 LPA to 14 LPA.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse7">
                        <i class="fa fa-hand-o-right"></i> Will I be eligible to apply for government and public sector
                        jobs after b tech lateral entry course?
                    </a>
                </div>
                <div id="collapse7" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        Yes, students will be eligible provided they do the course from universities that are recognised
                        by AICTE and UGC.
                    </div>
                </div>
            </div>


        </div>

    </div>
</section>

<section class="container mb-5">
    <div class="row text-center">
        <h6>By clicking, you agree to our Privacy Policy, & Our Trust</h6>
        <p>The intend of Education Emplotability Emptloyment Score is to provide unbiased precise information & comparative guidance on Universities
            and its
            Programs of Study to the Admission Aspirants. The contents of the Collegevidya Site, such as Texts,
            Graphics,
            Images, Blogs, Videos, University Logos, and other materials contained on Collegevidya Site (collectively,
            “Content”) are for information purpose only. The content is not intended to be a substitute for in any form
            on
            offerings of its Academia Partner. Infringing on intellectual property or associated rights is not intended
            or
            deliberately acted upon. The information provided by Education Emplotability Emptloyment Score on www.collegevidya.com or any of its
            mobile or
            any other applications is for general information purposes only. All information on the site and our mobile
            application is provided in good faith with accuracy and to the best of our knowledge, however, we make nor
            representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity,
            reliability,
            completeness of any information on the Site or our mobile application. Collegevidya & its fraternity will
            not be
            liable for any errors or omissions and damages or losses resultant if any from the usage of its information.
            <br> Build with in India </p>
    </div>
</section>


<!-- The Modal1 -->
<div class="modal fade" id="myModal2">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body text-center">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                <div>
                    <div class="barder-1">
                        <img src="assets\img\icon\Jain-University.jpg" alt="" class="img-fluid" alt="" width="150"
                            height="100">
                    </div>

                    <h4 class="text-left">
                        Hi cvxbfg 👋
                    </h4>

                </div>

                <div class="alert alert-info">
                    <strong>⚠</strong> Pay Your Fees only at the Official Website of the University
                </div>

                <div class="shadow-lg p-2 mt-4">
                    <p>“ Thank you for taking the first step towards a fruitful journey towards your career growth. We
                        have shared your interest with the University and they will call you shortly. Till then, as this
                        decision of your life is very important, we recommend to explore other options and choose best
                        for you 😊</p>
                </div>

                <button type="submit" class="btn btn-success text-start my-5">I want to Explore More</butto>


            </div>

        </div>
    </div>
</div>




<?php include 'footer.php' ?>