<section class="footer-call-action" style="margin-bottom: -180px;">
    <div class="container">
        <div class="cta-wrap ">
            <div class="row flex-row-reverse justify-content-between">
                <div class="col-lg-6">
                    <div class="cta-img"><img src="assets/img/footer-call.png" class="img-fluid" alt="Image"></div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="cta-content">
                        <h2>Learn From Our Platform</h2>
                        <h1>That Take You Next Level</h1>
                        <div class="read-more">
                            <a href="">Register Now <i class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-icon-vector" style="top: 0%; left: 44%;">
                <img src="assets/img/icon/dot_shape_1.png" alt="shapes">
            </div>
        </div>
    </div>
</section>

<footer class="footer-wrapper">
    <div class="widget-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-md-6 col-xxl-3 col-xl-4">
                    <div class="footer-widget">
                        <div class="as-widget-about">
                            <div class="about-logo">
                                <a href="index.php">
                                    <!-- <img src="assets/img/logo-white.svg" alt=""> -->
                                    <h3>Education Employability Employment</h3>
                                </a>
                            </div>
                            <p class="about-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Laudantium
                                vero earum, praesentium velit doloremque iusto.</p>
                            <h4 class="footer-info-title">Follow Us On:</h4>
                            <div class="as-social">
                                <a href="https://www.facebook.com/">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="https://www.twitter.com/">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="https://www.linkedin.com/">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                                <a href="https://www.instagram.com/">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="https://www.youtube.com/">
                                    <i class="fab fa-youtube"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-auto">
                    <div class="widget_nav_menu footer-widget">
                        <h3 class="widget_title">Quick link</h3>
                        <div class="menu-all-pages-container">
                            <ul class="menu">
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-auto">
                    <div class="widget widget_nav_menu footer-widget">
                        <h3 class="widget_title">Resources</h3>
                        <div class="menu-all-pages-container">
                            <ul class="menu">
                                <li><a href="">Click here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                                <li><a href="">Click Here</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="widget footer-widget">
                        <h3 class="widget_title">Get in touch!</h3>
                        <form class="newsletter-widget">
                            <p class="footer-text">Fusce varius, dolor tempor interdum tristiquei bibendum service life.
                            </p>
                            <div class="form-group">
                                <input class="form-control" type="email" placeholder="Enter Email" required="">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <button type="submit" class="btn-submit">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright-wrap">
            <div class="row justify-content-between align-items-center">
                <div class="col-lg-6">
                    <p class="copyright-text">Copyright <i class="fa-solid fa-copyright"></i> 2022.</p>
                </div>
                <div class="col-lg-6 text-end d-none d-lg-block">
                    <div class="footer-links">
                        <ul>
                            <li><a href="">Privacy Policy</a></li>
                            <li><a href="">Terms of Use</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shape-vector d-none d-xl-block" style="top: 24%; left: 4%;">
        <img src="assets/img/icon/footer_shape_1.png" alt="">
    </div>
    <div class="shape-vector d-none d-xl-block" style="right: 4%; bottom: 20%;">
        <img src="assets/img/icon/footer_shape_2.png" alt="shapes">
    </div>
    <div class="shape-vector" style="top: 0px; right: 0px;">
        <img src="assets/img/icon/footer_shape_3.png" alt="shapes">
    </div>
</footer>



</main>

<a href="#" class="scroll_to_top">
    <i class="fa-solid fa-arrow-up"></i>
</a>

<script src="assets/js/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/typed.js/1.1.1/typed.min.js"></script>
<script src="assets/js/main.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
<script>
  
 var swiper = new Swiper(".mySwiper", {
        slidesPerView: 4,
        spaceBetween: 30,
        slidesPerGroup: 1,
        loop: true,
        loopFillGroupWithBlank: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    $('.owl-carousel-1').owlCarousel({
        loop: true,
        // margin:10,
        navigation: true,
        nav: true,
        mouseDrag: false,
        touchDrag: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 4
            }
        },
        navText: ['<img src="assets/img/college-icon/prev.png" width="50" />', '<img src="assets/img/college-icon/next.png" width="50" />']

    });
    $(".owl-carousel-1").find(".owl-nav").removeClass("disabled");
    $(".owl-carousel-1").find(".active").eq("2").hide();
    $(".owl-carousel-1 .owl-nav button").click(function () {
        $(".owl-carousel-1").find(".owl-nav").removeClass("disabled");
    });

    
</script>

<style>
    .owl-carousel-1 .owl-nav {
        position: absolute;
        top: 40%;
        display: flex;
        justify-content: space-between;
    }

    .owl-prev {
        position: absolute;
        left: -50px;
    }

    .owl-next {
        position: absolute;
        right: -50px;
    }

</style>

</body>

</html>