<?php include 'header.php' ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Add Mentor</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                <li class="breadcrumb-item active">Add Mentor</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Add New Mentor</h4>

                            <form>
                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label">Name</label>
                                            <input type="text" class="form-control" id="email"
                                                placeholder="Enter Your Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="title" class="form-label">Title</label>
                                            <input type="text" class="form-control" id="title"
                                                placeholder="Enter Your Title">
                                        </div>
                                    </div>
                                </div>


                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="Course" class="form-label">Courses</label>
                                            <input type="text" class="form-control" id="course"
                                                placeholder="Enter Your Course" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="expression" class="form-label">Expression</label>
                                            <input type="number" class="form-control" id="expression"
                                                placeholder="Enter Your Year Expression">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">Date</label>
                                            <input class="form-control" type="date" placeholder="2019-08-19"
                                                id="example-date-input" required>
                                        </div>


                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">Time</label>
                                            <input class="form-control" type="datetime-local"
                                                value="2019-08-19T13:45:00" id="example-datetime-local-input">
                                        </div>


                                    </div>
                                </div>




                                <div class="row">
                                    
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="formrow-inputState" class="form-label">Country</label>
                                            <select id="formrow-inputState" class="form-select" required>
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="formrow-inputCity" class="form-label">City</label>
                                            <input type="text" class="form-control" id="formrow-inputCity"
                                                placeholder="Enter Your Living City">
                                        </div>
                                    </div>

                                    
                                    
                                </div>

                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">About</label>
                                            <textarea class="form-control" placeholder="Write About Mentor"
                                                id="exampleFormControlTextarea1" rows="3"></textarea>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="mb-3">
                                        <label for="formFileLg" class="form-label">Upload Mentor Image</label>
                                        <input class="form-control " id="formFileLg" type="file" required>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="mb-3">
                                        <label for="formrow-email-input" class="form-label">Consultation Fee</label>
                                        <input class="form-control" type="number" placeholder="Enter Consultation Fee"
                                            id="example-number-input" required>
                                    </div>

                                </div>



                                <div class="row mb-4">
                                    
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="formrow-inputState" class="form-label">Status</label>
                                            <select id="formrow-inputState" class="form-select" required>
                                                
                                                <option value="active" > Active </option>
                                                <option value="deactive" > Deactive </option>
                                                
                                            </select>
                                        </div>
                                    </div>

                                    
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
            </div>







        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    
    <?php include('footer.php') ?>
