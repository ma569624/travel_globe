<?php include("header.php"); ?>




<section class="verify-section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="type-wrap">
          <span id="typed" style="white-space:pre;" class="typed"></span>
        </div>
        <div class="section-title">
          <h3>your <span> University </span>before applying!</h3>
        </div>
      </div>
    </div>
  </div>
</section>
<br>


<!--FONT_FAMILY CSS LINK-->
<link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>


<section class="online-service">
  <div class="container-fluid">

  </div>

  <div class="container">

    <div class="row" id="row2">
      <div class="col-12">
        <div class="d-flex flex-nowrap">
          <div class="order-1 p-2"> Hey , I'm Pooja , Below are the best approved universities for you according to the
            questions filled by you for MCA Data Analytics</div>
          <div class="order-2 p-2"><button>Video Consultation</button></div>
          <div class="order-3 p-2"><img src="assets\img\icon\img_avatar2.png" alt="" srcset="" class="img-thumbnail"
              height="30" width="50"></div>
        </div>
      </div>
    </div>
    <br>
    <div></div>
    <br>
    <div class="row" id="row3">
      <div class="col-12">Proceed to University <span>&#62
        </span></div>
    </div>
    <br>
    <div class="row" id="row">
      <div class="col">University</div>
      <div class="col" class="dropdown"> <a class="btn  dropdown-toggle" id="dropdownMenuButton1"
          data-bs-toggle="dropdown" aria-expanded="false">
          Dropdown button</a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="#">Recommended</a></li>
          <li><a class="dropdown-item" href="#">Low to High</a></li>
          <li><a class="dropdown-item" href="#">High to low</a></li>
        </ul>
      </div>
      <div class="col" class="dropdown"> <a class="btn  dropdown-toggle" id="dropdownMenuButton1"
          data-bs-toggle="dropdown" aria-expanded="false">
          Fee</a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="#">Recommended</a></li>
          <li><a class="dropdown-item" href="#">Low to High</a></li>
          <li><a class="dropdown-item" href="#">High to low</a></li>
        </ul>
      </div>
      <div class="col" class="dropdown"> <a class="btn  dropdown-toggle" id="dropdownMenuButton1"
          data-bs-toggle="dropdown" aria-expanded="false">
          Education Emplotability Emptloyment Score</a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="#">Recommended</a></li>
          <li><a class="dropdown-item" href="#">Low to High</a></li>
          <li><a class="dropdown-item" href="#">High to low</a></li>
        </ul>
      </div>
      <div class="col">Compare</div>
    </div>
    <br>
    <div class="row" id="row1">
      <div class="col">
        <img src="" alt="" srcset="">
        <img src="assets\img\icon\Jain-University.jpg" alt="" srcset="" height="77" width="300">
      </div>
      <div class="col">
        <p class="p">UGC-DEB,AICTE,NIRPF,NAAC,A++</p>
      </div>
      <div class="col">
        <p class="p1">
        <p><span>&#8377</span>
          5000/SEMESTER</p>
      </div>
      <div class="col">
        <p class="p2"><span>&#11088</span>9.1/10</p>
      </div>
      <div class="col">
        <p class="p3"><span>&#11088</span>4.7/10</p>
      </div>

    </div>
    <br>

    <div class="row" id="row4">
      <div class="col-12">
        <img src="" alt="" srcset="">
        <p>Hey there, looks like the course in which you are interested is so unique that only a single university
          provides it. If in future any university starts providing the course and matches our strict parameters of
          Approvals, Learning Management System, Placement Assistance & Faculty we will notify you. Education Emplotability Emptloyment
          strictly inspects all the factors before listing any universities.</p>
      </div>
    </div>

    <br>
    <div class="row" id="row5">
      <div class="col-4"><img src="assets/img/confused.png" alt="" srcset="" height="300" width="300">
      </div>
      <div class="col-4">
        <p>Education Emplotability Emptloyment Recommender</p>

        <h2>Not Sure, Which University to choose?</h2>
        <p>Let us help you find the dream University</p>
      </div>
      <div class="col-4">
        <button>Schedule an Appointment</button>
      </div>
    </div>
    <br>
    <div class="row" id="row6">
      <div class="col-3">
        <h4>Popular University</h4>
        <div class='bg'>
          <img src="assets\img\icon\Jain-University.jpg" alt="" srcset="">
          <button class='btn'>Jain University</button>

        </div>
      </div>
    </div>
  </div>

  </div>
  <br>
</section>
<br>

<section class="extras">


  </div>
</section>

<?php include("footer.php"); ?>