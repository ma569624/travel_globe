<?php include("header.php");?>

    <section class="compare-banner our-trust">
        <div class="container">
            <div class="row">
                <div class="col-md-7 mr-auto">
                <h1 id="seo-h1"> Trust Comes First<br>Always. </h1>
                    <p>Collegevidya is the smartest and most intuitive platform for Compare university. Thrive digitally as we guide your career with the right comparing tools.</p>
                    <div class="font my-3">
                        <p> Right University For Your Right Degree</p>
                        <p> #Righttoselect</p>
                        <div class="d-flex">
                            <a class="curveimg-block me-2" href="">
                                <img class="ht-img m-0" src="assets/img/ht-logo.svg">
                            </a>
                            <a class="curveimg-block" href="">
                                <img class="ht-img m-0" src="assets/img/forbes-logo.png">
                            </a> 
                        </div>
                    </div>
                </div>
                <div class="col-md-5 compare_rbanner">
                    <img src="assets/img/stamp.png" class="w-100" alt="Education Emplotability Emptloyment seal of trust"> 
                </div>
        </div>
        <div class="row main-icon3">
                <div class="col-md-4">
                    <div class="compare_detail_key">
                        <div class="comare_tag">
                            <i class="fa-solid fa-shield-halved"></i>
                        </div>
                        <div class="compare_tag_detail">
                            <p>India's Only Portal with Unbiased Guidance</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="compare_detail_key">
                        <div class="comare_tag">
                            <i class="fa-solid fa-building"></i>
                        </div>
                        <div class="compare_tag_detail">
                            <p>Only UGC-DEB approved University Listed </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="compare_detail_key">
                        <div class="comare_tag">
                            <i class="fa-solid fa-arrow-pointer"></i>
                        </div>
                        <div class="compare_tag_detail">
                            <p>75+ Distance &amp; Online Universities at One Click</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ceo-msg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3>CEO <span> Message For</span> Students</h3>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme ceo-message">
                        <div class="item">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="assets/img/our-trust/our-trust.png" class="img-fluid" alt="">
                                </div>
                                <div class="col-md-8">
                                    <div class="ceo-content">
                                        <p><span><i class="fa-solid fa-quote-left"></i></span>  Education Employability Employment: Transparency, Authenticity & Unbiasedness are three principles around which Education Emplotability Emptloyment revolves. With a dream to make education accessible to every single individual, we know the importance of providing true and neutral information. We will never compromise on our principles as education is the future defining factor of everyone and we strive for everyone's upliftment and growth. <span class="bottom"><i class="fa-solid fa-quote-right"></i></span> </p>
                                        <h3 class="ceo-name">Mayank Gupta</h3>
                                        <p>(CEO, Education Employability Employment)</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="assets/img/our-trust/our-trust.png" class="img-fluid" alt="">
                                </div>
                                <div class="col-md-8">
                                    <div class="ceo-content">
                                        <p><span><i class="fa-solid fa-quote-left"></i></span>  Education Employability Employment: Transparency, Authenticity & Unbiasedness are three principles around which Education Emplotability Emptloyment revolves. With a dream to make education accessible to every single individual, we know the importance of providing true and neutral information. We will never compromise on our principles as education is the future defining factor of everyone and we strive for everyone's upliftment and growth. <span class="bottom"><i class="fa-solid fa-quote-right"></i></span> </p>
                                        <h3 class="ceo-name">Mayank Gupta</h3>
                                        <p>(CEO, Education Employability Employment)</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="assets/img/our-trust/our-trust.png" class="img-fluid" alt="">
                                </div>
                                <div class="col-md-8">
                                    <div class="ceo-content">
                                        <p><span><i class="fa-solid fa-quote-left"></i></span>  Education Employability Employment: Transparency, Authenticity & Unbiasedness are three principles around which Education Emplotability Emptloyment revolves. With a dream to make education accessible to every single individual, we know the importance of providing true and neutral information. We will never compromise on our principles as education is the future defining factor of everyone and we strive for everyone's upliftment and growth. <span class="bottom"><i class="fa-solid fa-quote-right"></i></span> </p>
                                        <h3 class="ceo-name">Mayank Gupta</h3>
                                        <p>(CEO, Education Employability Employment)</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>


    <section class="trust-transparency">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3 style="font-size:30px">Education Employability Employment <span> A Seal of Trust and Transparency</span> </h3>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="trust-transparency-box">
                        <i class="fa-solid fa-shield-halved"></i>
                        <h3>Secured</h3>
                        <p>We Don’t Share or Sell your personal Information.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-transparency-box">
                        <i class="fa-solid fa-handshake-slash"></i>
                        <h3>No Hidden Fees</h3>
                        <p>Comparing Distance & Online Universities is absolutely free. No fee is charged at any stage.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-transparency-box">
                        <i class="fa-solid fa-disease"></i>
                        <h3>Ease of Use</h3>
                        <p>The Interface of Education Emplotability Emptloyment Compare is hassle free and fast.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-transparency-box">
                        <i class="fa-solid fa-building-circle-check"></i>
                        <h3>Seal of Trust</h3>
                        <p>Information on Education Emplotability Emptloyment Compare is trusted by all listed universities.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="comparem-any">
        <div class="container">
            <div class="row">
                <div class="col-md-7 m-auto">
                    <h3>Compare as many Universities as you Want</h3>
                    <p>You can compare all the universities based on your Distance & Online Course and select the university that fits your parameters.</p>
                </div>
                <div class="col-md-5">
                    <img src="assets/img/our-trust/our-trust-01.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="comparem-any">
        <div class="container">
            <div class="row">
                <div class="col-md-7 m-auto">
                    <h3>Get a Personalized Mentor</h3>
                    <p>Personalized Mentorship with a dedicated Mentor for you to connect over text, phone, or <b>video consultation.</b></p>
                </div>
                <div class="col-md-5">
                    <img src="assets/img/our-trust/our-trust-02.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="why-benefits">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="why-benefits-list">
                        <h3>Why Education Employability Employment</h3>
                        <ul>
                            <li>Education Employability Employment gives you unbiased guidance to choose the best distance & online education university providing the best of its courses.</li>
                            <li>Education Employability Employment is the first that has introduced Compare feature where you can compare all the distance & Online colleges and universities</li>
                            <li>We also have introduced the Education Emplotability Emptloyment Score which gives scores to all the colleges and universities yearly as per its performances and the quality of education they are providing. Also reviews from the alumni and present students.</li>
                        </ul>
                        <h3>Benefits of Distance Learning</h3>
                        <ul>
                            <li>Distance & Online Education allows you to study wherever and whenever you want as it offers the flexibility of time and money by giving online classes both live and recorded video lectures with no barrier.</li>
                            <li>Learning at your own pace as there is no fixed time to study you can attend classes or look into the recorded lectures.</li>
                            <li>Distance & Online enables you to have industry expert guest lectures where you’ll be having a genuine and advanced experience of learning and strategies and tactics of how to take a step forward.</li>
                            <li>With the Distance & Online education program, one has the advantage of continuing the course along with the current job as it’s a distance program in which classes held online can be taken anytime.</li>
                            <li>While pursuing the Distance & Online program in parallel with the job can get a hike promotion in your career.</li>
                            <li>All the Distance & Online education programs are cost-effective. They have a lesser fee structure as compare to regular programs.</li>
                            <li>Distance & Online education eventually can boost your skill set by inculcating experience, credentials along with the current job or course if you’re pursuing.</li>
                            <li>The Industry revised the curriculum by adding new technologies and the latest syllabus in the programs to serve quality of education and not quantity.</li>
                        </ul>
                        <h3>Key Factors When Education Employability Employment Lists Universities</h3>
                        <ul>
                            <li>Education Emplotability Emptloyment only lists universities that are approved by UGC-DEB, AICTE, NAAC, and NIRF.</li>
                            <li>Education Emplotability Emptloyment examines the Learning Management system. If they match the parameters, then only it gets listed.</li>
                            <li>Placement Support Cells is also the parameter for the university to get on Education Emplotability Emptloyment.</li>
                            <li>Other parameters include Alumni Connect, Faculty, Placement Records, and EMI facilities.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
     
<?php include("footer.php");?>