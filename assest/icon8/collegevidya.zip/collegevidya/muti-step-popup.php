
    <link rel="stylesheet" type="text/css" href="multi-step-popup/css/MultiStep.min.css" />
    <link rel="stylesheet" type="text/css" href="multi-step-popup/css/MultiStep-theme.min.css" />
     
    <div id="submitModal" class="multi-step" data-bs-backdrop="static"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="multi-step-popup/js/MultiStep.min.js"></script>
    <script type="text/javascript" src="multi-step-popup/js/index.js"></script>
    
    <script>
      $(document).ready(function(){
        $("#submitModal").modal('show');
      });
    </script>

