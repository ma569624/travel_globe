<!-- Modal -->
<div class="modal fade" id="review" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="padding: 30px 90px;">
                <form class="was-validated">
                    <div class="row">
                        <div class="col">
                            <div><span class="close_modal_button" style="margin-right: 7px;"></span></div>
                        </div>
                    </div>
                    <div class="mt-3 row">
                        <div class="col"><h4>How was your counselling experience with Praveen
                                Chauhan?</h4></div>
                    </div>
                    <div class="row">
                        <div class="col"><span style="font-size: 14px; color: rgb(120, 120, 135);">Your experience will
                                help over 83678+ people choose the right Mentor, daily.</span></div>
                    </div>
                    <div class="mt-4 row">
                        <div class="col" ><p class="">Q1.How would you rate our Mentor?*</p></div>
                    </div>
                    <div class="mt-2 d-flex align-items-center justify-content-between">
                        <span class="text-info">
                        <i class="fa fa-star fs-4"></i>
                        <i class="fa fa-star fs-4"></i>
                        <i class="fa fa-star fs-4"></i>
                        <i class="fa fa-star fs-4"></i>
                        <i class="fa fa-star fs-4"></i>
                        </span>
                    </div>
                    <div class="invalid-feedback"></div>
                    <div class="mt-4 row">
                    <div class="col" ><p class="">Q2.Would you like to recommend our
                                    Mentor?</p></div>
                        
                    </div>
                    <div class="">
                        <div class="text-info"><i class="fa fa-thumbs-up  fs-4"></i> Yes</div>
                        <sdiv class="text-info"><i class="fa fa-thumbs-down fs-4"></i> No</sdiv>
                    </div>
                    <div class="mt-4 row">
                        <div class="col"><p class="">Q3.How was your interaction with our
                                    Mentor?*</p>
                            
                            <div class="mt-2"><input name="title" placeholder="Add a title" type="text"
                                    class="form-control is-invalid" value="">
                                    <div class="invalid-feedback">
                                    Please enter a title
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 row">
                        <div class="col"><p class="">Q4.Describe your experience with our
                                    Mentor*</p>
                            
                            <div class="mt-2"><textarea name="review" placeholder="Start typing here..." rows="2"
                                    class="form-control is-invalid" id="validationTextarea"></textarea>
                                <div class="invalid-feedback">
                                    Please enter a Describe
                                </div>
                            </div>
                        
                        </div>
                    </div>
                    <div class="mt-4 row">
                        <div class="col">
                        <p class="">Q5.How can we improve our services? Or any
                                    feedback?</p>
                            
                            <div class="mt-2"><textarea name="improvement" placeholder="Share your thoughts here..."
                                    rows="2" class="form-control is-invalid"></textarea>
                                <div class="invalid-feedback"></div>
                            </div>
                                <div class="invalid-feedback">
                                    Please enter a Describe
                                </div>
                        </div>
                    </div>
                    <div class="mt-4 row">
                        <div class="text-end col"><button type="submit"
                                class=" fw-bold w-25 btn btn-primary">Submit</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="time" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <form class="">
                    <div class="row">
                        <div class="col">
                            <div>
                                <span class="close_modal_button" style="margin-right: 7px;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3 row">
                        <div class="col">
                            <h5 class="fw-bold">Confirm &amp; Pay</h5>
                        </div>
                    </div>
                    <div class="mt-2 mb-3 border-top border-bottom" style="padding: 15px;">
                        <div class="d-flex align-items-center justify-content-between"><span
                                class="d-flex align-items-center"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp; On <b> 14th Dec 2022</b></span>
                                <span class="d-flex align-items-center" style="font-size: 14px;"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp; At <b> 11:45 AM</b></span></div>
                        <div class="mt-2"
                            style="color: rgb(20, 190, 241);  font-weight: bold;">
                            Change Date Time</div>
                    </div>
                    
                    <div class="d-flex mt-2">
                        <div class="">
                        <img src="assets\img\New\isha-sharma.jpg" alt=""
                                class="img-fluid rounded-circle w-50">
                        </div>
                        <div class="">
                            <h4 class="fw-bold m-0">Isha Sharma</h4>
                            <p class="m-0">Sr. Mentor</p>
                            <span class="badge bg-primary">7 Years Experience</span>
                            <div class="d-flex">
                                <span><i class="fa fa-star text-warning"> </i></span>
                                <span> <p> 4.7 (7 votes)</p> </span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col"><label class="form-label">Course*</label><select name="course"
                                class="shadow-none cv-input-field form-select is-invalid">
                                <option value="">Select an option</option>
                                <option value="B.Com">B.Com</option>
                                <option value="B.Tech">B.Tech</option>
                                <option value="BA">BA</option>
                                <option value="BBA">BBA</option>
                                <option value="BCA">BCA</option>
                                <option value="Certificate Programs">Certificate Programs</option>
                                <option value="CMS &amp; ED">CMS &amp; ED</option>
                                <option value="Diploma in Engineering">Diploma in Engineering</option>
                                <option value="Diploma Programs">Diploma Programs</option>
                                <option value="Executive MBA">Executive MBA</option>
                                <option value="M.Com">M.Com</option>
                                <option value="M.Sc">M.Sc</option>
                                <option value="M.Tech">M.Tech</option>
                                <option value="MA">MA</option>
                                <option value="MBA">MBA</option>
                                <option value="MCA">MCA</option>
                            </select>
                            <div class="invalid-feedback">Please select a course</div>
                        </div>
                        <div class="col"><label class="form-label">Education Mode*</label><select name="mode"
                                class="shadow-none cv-input-field form-select is-invalid">
                                <option value="">Select an option</option>
                                <option value="online">Online</option>
                                <option value="offline">Offline</option>
                            </select>
                            <div class="invalid-feedback">Please select a mode</div>
                        </div>
                    </div>
                    <div class="mt-2 row">
                        <div class="col"><label class="form-label">Specialization*</label><select name="specialization"
                                class="shadow-none cv-input-field form-select is-invalid">
                                <option value="">Select an option</option>
                            </select>
                            <div class="invalid-feedback">Please select a specialization</div>
                        </div>
                    </div>
                    <div class="mt-3 mb-2">
                        <div style="color: rgb(120, 120, 135); font-size: 14px;">Final Fee</div>
                        <div class="fw-bold" style="font-size: 24px;">₹199</div>
                    </div>
                    <div class="mt-4 mb-2"><button type="submit"
                            class="fw-bold w-100 btn btn-primary">Proceed now&nbsp;&nbsp;<i class="fa fa-handshake-o text-light" aria-hidden="true"></i></button></div>
                </form>
            </div>
        </div>
    </div>
</div>