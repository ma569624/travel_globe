<?php include("header.php"); ?>
<div  class="pb-3">

    <div class="container pt-2">
        <div class="row">
            <div>
                <h1 class="fs-2">Here is the detailed comparison of selected universities for</h1>
                <h1><b>Online & Distance MBA</b> </h1>
            </div>


        </div>
    </div>


    <div class="container shadow-lg my-5 bg-light">
        <div class="row">
            <form class="p-3 pb-4 pt-5" action="/action_page.php">
                <div class="row my-4 bg-light">
                    <div class="col-lg-3">
                        <div class="mt-5 text-center"><a href="#">
                                < Back</a>
                        </div>

                    </div>
                    <div class="col-lg-3">
                        <div class="card text-center">
                            <div><a href="#"><img src="assets/img/minus.png" class="img-fluid float-end" alt=""></a>
                            </div>
                            <img src="assets/img/icon/Jain-University.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="col-lg-3">

                        <div class="card text-center" data-bs-toggle="modal" data-bs-target="#myModal2">
                            <div class="pt-3"><img src="assets/img/pluse.png" class="img-fluid text-center" alt=""
                                    width="30">
                            </div>
                            <h5 class="pt-2">Add More University</h5>
                        </div>

                    </div>
                    <div class="col-lg-3">
                        <div class="card text-center" data-bs-toggle="modal" data-bs-target="#myModal2">
                            <div class="pt-3"><img src="assets/img/pluse.png" class="img-fluid text-center" alt=""
                                    width="30">
                            </div>
                            <h5 class="pt-2">Add More University</h5>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row px-5">
                    <table class="table table-borderless">

                        <tbody>
                            <tr>
                                <td>Sample Certificate</td>
                                <td><img src="assets\img\Jain-online-university-certificate.jpeg" alt="" width="80">
                                </td>
                            </tr>
                            <tr>
                                <td>Fees<span data-bs-toggle="tooltip" data-bs-placement="right"
                                        title="Average Fees Of The University Semester"><img src="assets/img/info.png"
                                            width="20" class="img-fluid" alt=""></span></td>
                                <td>
                                    <h5><span class="badge bg-success h-100">
                                            <span>₹</span>
                                            40000 / Semester ></span></h5>
                                </td>

                            </tr>
                            <tr>
                                <td>Approvals <span data-bs-toggle="tooltip" data-bs-placement="right"
                                        title="Average Student Enrolle Score Rate"><img src="assets/img/info.png"
                                            width="20" class="img-fluid" alt=""></span></td>
                                <td><a href="#" type="submit" data-bs-toggle="modal" data-bs-target="#myModal1">UGC-DEB,
                                        AICTE, NIRF NAAC A++</a> </td>

                            </tr>
                            <tr>
                                <td>Eligibility </td>
                                <td>Graduation Pass out</td>
                            </tr>
                            <tr>
                                <td>Duration</td>
                                <td>2 Years</td>
                            </tr>
                            <tr>
                                <td>Education Mode</td>
                                <td>Online</td>
                            </tr>
                            <tr>
                                <td>Examination Mode</td>
                                <td>Online</td>
                            </tr>
                            <tr>
                                <td>E-Learning Facility </td>
                                <td>Yes</td>
                            </tr>

                            <tr>
                                <td>Online Classes</td>
                                <td>Yes</td>
                            </tr>
                            <tr>
                                <td>Industry Ready</td>
                                <td>Yes</td>
                            </tr>
                            <tr>
                                <td>Student Rating </td>
                                <td><i class="fa fa-star text-warning"></i> 4.5 / 5</td>
                            </tr>
                            <tr>
                                <td>Satisfied Students</td>
                                <td>87%</td>
                            </tr>
                            <tr>
                                <td>Student Choice</td>
                                <td>47%</td>
                            </tr>
                            <tr>
                                <td>Pros</td>
                                <td>Online Exams, Well-established Learning Management System
                                </td>
                            </tr>
                            <tr>
                                <td>NAAC Score</td>
                                <td>3.27 / 4</td>
                            </tr>
                            <tr>
                                <td>NIRF Ranking</td>
                                <td>25</td>
                            </tr>
                            <tr>
                                <td>WES (International) Approval</td>
                                <td>Yes</td>
                            </tr>
                            <tr>
                                <td>EMI Facility Available</td>
                                <td>Yes</td>
                            </tr>
                            
                            
                            <tr>
                                <td>Blog</td>
                                <td> <button type="button" class="btn"><i style="font-size: 18px;"
                                            class="fa fa-external-link"></i></button> </td>
                            </tr>
                            <tr>
                                <td>Video</td>
                                <td><img src="assets/img/video-play.png" alt=""></td>

                            </tr>

                            

                        </tbody>
                    </table>
                    <div class="row mt-4">
                        <div class="ms-5"><a href="#" type="submit" data-bs-toggle="modal" data-bs-target="#myModal"
                                class="ms-5 text-center btn btn-success">Proceed to
                                University</a></div>
                    </div>

                </div>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="row text-start">
            <h2> <b>Comparison Summary</b></h2>
        </div>
    </div>


    <div class="container shadow-lg my-3 pb-4 bg-light">
        <div class="row">
            <form class="p-3" action="/action_page.php">
                <div class="row">
                    <table class="table table-borderless">

                        <tbody>
                            <tr>
                                <td>Fees</td>
                                <td>
                                    <h5><span class="badge bg-success h-100">
                                            <span>₹</span>
                                            40000 / Semester ></span></h5>
                                </td>

                            </tr>
                            <tr>
                                <td>Student Rating</td>
                                <td><i class="fa fa-star text-warning"></i>4.5 / 5</td>
                            </tr>
                            <tr>
                                <td>EMI Facility Available</td>
                                <td>Yes</td>

                            </tr>
                            
                            
                        </tbody>
                    </table>


                </div>


            </form>
        </div>
    </div>



    <!-- The Modal -->
    <div class="modal fade" id="myModal2">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header border-0">

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body pb-5">
                    <div class="row">
                        <div class="col-lg-10">
                            <h5 class="modal-title text-left">Choose 3 University to compare</h5>
                        </div>
                        <div class="col-lg-2">
                            <div><button type="button" class="btn btn-success text-right"
                                    data-bs-dismiss="modal">Compare</button></div>
                        </div>



                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-4">
                            <div class="card shadow-lg text-center">
                                <img src="assets\img\collage\university-of-mysore-logo.jpg" class="img-fluid ps-5"
                                    alt="" width="180">
                                <p style="font-size: 14px;">University of Mysore</p>
                                <h5>₹ 92625/ Full Fees</h5>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card shadow-lg text-center">
                                <img src="assets/img/collage/Amity-University.jpg" class="img-fluid ps-5" alt=""
                                    width="180">
                                <p style="font-size: 14px;">Amity Online University</p>
                                <h5>₹ 63250/ Semester</h5>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card shadow-lg text-center">
                                <img src="assets\img\collage\Jain-University.jpg" class="img-fluid ps-5" alt=""
                                    width="180">
                                <p style="font-size: 14px;">Jain University</p>
                                <h5>₹ 40000/ Semester</h5>
                            </div>
                        </div>

                    </div>
                    <div class="row mt-5">
                        <div class="col-lg-4">
                            <div class="card shadow-lg text-center">
                                <img src="assets/img/collage/manav-rachna-online-logo.jpg" class="img-fluid ps-5" alt=""
                                    width="180">
                                <p style="font-size: 14px;">Manav Rachna University Online</p>
                                <h5>₹ 92625/ Full Fees</h5>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card shadow-lg text-center">
                                <img src="assets\img\collage\university-of-mysore-logo.jpg" class="img-fluid ps-5"
                                    alt="" width="180">
                                <p style="font-size: 14px;">D.Y. Patil Vidyapeeth</p>
                                <h5>₹ 63250/ Semester</h5>
                            </div>
                        </div>


                    </div>

                </div>

            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header ">
                    <img src="assets\img\icon\Jain-University.jpg" class="img-fluid" alt="" width="150">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body text-center">

                    <h5 class="modal-title text-center">Talk to Admission Counselor</h5>
                    <input type="email" class="form-control my-3" id="email" placeholder="Enter Full Name" name="email">
                    <input type="email" class="form-control my-3" id="email" placeholder="Enter Email" name="email">
                    <input type="email" class="form-control my-3" id="email" placeholder="Enter Number" name="email">
                    <button type="button" class="btn btn-success my-3 text-center"
                        data-bs-dismiss="modal">Submit</button>
                </div>

            </div>
        </div>
    </div>


    <!-- The Modal1 -->
    <div class="modal fade" id="myModal1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal body -->
                <div class="modal-body text-center">
                    <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                    <div>
                        <img src="assets/img/logo-design.png" alt="" class="img-fluid" alt="" width="150" height="100">
                        <h4 class="text-primary">
                            #Righttoselect<svg version="1.1" id="Layer_1" width="30" xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500"
                                enable-background="new 0 0 500 500" xml:space="preserve">
                                <style>
                                    #wing1 {
                                        transform-origin: center;
                                        animation: flap 0.4s ease-out infinite alternate;
                                    }

                                    #wing2 {
                                        transform-origin: center;
                                        animation: flap 0.4s ease-in infinite alternate;
                                    }

                                    @keyframes flap {
                                        50% {
                                            transform: scaleX(-1) rotate(-45deg) translate(-40px, -40px);
                                        }
                                    }
                                </style>
                                <path id="body" fill="#5DA8DC" d="M142.9,364.1c-1.6,1-3,1.7-4,2.3c-3,1.5-7.9,3.8-14.9,6.9c-7,3.1-14.7,5.7-23.1,7.9
                c-8.4,2.2-15.6,3.8-21.8,4.7c-6.2,0.9-12.2,1.5-18.1,1.8s-11.4,0.3-16.7,0c-5.2-0.3-8.5-0.5-9.6-0.6l-1.8-0.2l-0.4-0.1l-0.4-0.1v0.8
                h0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H33l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l3.6,2.2c2.4,1.5,4.5,2.6,6.4,3.6
                s6.6,3.3,14.1,7.1c7.6,3.7,16.6,7.4,27.2,11.1s18.6,6.2,24,7.4c5.4,1.3,12.8,2.6,22.2,3.9s14.9,2.1,16.3,2.2
                c1.5,0.1,3.3,0.3,5.5,0.4l3.3,0.2v0.2h25.6v-0.2l14-1.3c9.3-0.9,17.6-2.1,25-3.3c7.3-1.3,14.9-3.1,22.8-5.5
                c7.9-2.4,15.3-4.9,22.4-7.7c7.1-2.8,13.7-5.7,19.7-9c6.1-3.2,11.3-6,15.6-8.5c4.3-2.5,9.1-5.6,14.2-9.3c5.2-3.7,10-7.5,14.6-11.2
                s7.1-5.9,7.7-6.4c0.6-0.6,4-4,10.2-10.2c6.2-6.3,11.3-11.9,15.4-16.8c4-5,8-10.3,12-15.9c3.9-5.6,8.3-12.5,13-20.6
                s9.2-17.3,13.5-27.5s8-20.7,11-31.5c3-10.7,5.2-20.4,6.7-28.9s2.4-16.5,3-23.8c0.5-7.3,0.8-13.9,0.9-19.7s2.5-10.8,7.4-14.8
                s9.9-8.5,15-13.7c5.1-5.1,7.9-8,8.3-8.7c0.5-0.7,0.9-1.1,1.1-1.2c0.3-0.1,2.1-2.3,5.3-6.7c3.3-4.4,5-6.6,5-6.7l0.1-0.1l0.2-0.4
                l0.2-0.4l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.2-0.1l0.2-0.1V115l-1,0.3l-0.8,0.1
                l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.6,0.2l-1.2,0.4l-10.6,3.6c-6.7,2.2-13.7,4.1-21,5.7l-11,2.4h-1.9l0.1-0.1l0.1-0.1l0.1-0.1
                l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l1.9-1.3
                c1.3-0.9,2.4-1.8,3.3-2.8s2.8-2.7,5.6-5.1c2.8-2.4,6-6,9.5-10.7s6.5-9.4,8.8-14s3.6-7.2,3.7-7.9c0.1-0.6,0.3-1.2,0.4-1.6l0.2-0.6
                l0.2-0.4l0.2-0.4l0.2-0.6l0.2-0.6l0.1-0.6l0.1-0.6l-0.4,0.1l-0.4,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.4,0.2l-0.4,0.2
                l-0.4,0.2l-0.4,0.2l-0.1,0.1c-0.1,0.1-0.8,0.4-1.9,1.2c-1.2,0.7-4.7,2.4-10.5,5s-11.6,5-17.5,7.1s-11.4,3.7-16.5,4.9
                s-8.8,0.5-11.3-1.9c-2.4-2.4-5.2-4.7-8.3-6.9c-3.1-2.2-6.5-4.3-10.4-6.4c-3.8-2.1-7.7-3.9-11.8-5.5c-4-1.6-8.6-2.9-13.5-3.8
                l-7.4-1.5h-20.5v0.1c0,0.1-1.7,0.4-5.1,0.9s-7.6,1.6-12.6,3.3c-5,1.7-10.4,4.2-16.3,7.4c-5.9,3.3-11.1,7-15.7,11.2
                s-8.3,8.3-11.2,12.2c-2.9,3.9-5.2,7.4-7,10.5C221.5,163.3,231.3,307,142.9,364.1z"></path>
                                <path id="wing1" fill="#5DA8DC" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                                <path id="wing2" fill="#C4DFF2" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                            </svg>
                        </h4>
                        <h4>
                            Check out these must-have approvals to secure your future
                        </h4>
                        <a href="https://www.youtube.com/watch?v=Diao6b6lfpE">Watch Video <img
                                src="assets/img/video-play.png" alt=""></a>
                    </div>

                    <div class="shadow-lg p-2 mt-4">
                        <h6 class=" text-start"> <img src="assets/img/deb_logo.webp" alt=""> UGC (University Grants
                            Commission)
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li class="">
                                UGC is responsible to maintain the standards of Higher Education in India
                            </li>
                            <li class="">
                                UGC approval helps in identifying fake and authentic universities.
                            </li>
                            <li class="">
                                UGC approval is a must. Without this, your degree is not valid
                            </li>


                        </ul>
                        <h6 class="text-start mt-3 ms-1">DEB (Distance Education Bureau)</h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li class="">
                                DEB under UGC is the regulatory body that regulates all the Distance & Online Education
                                Programs.
                            </li>
                            <li class="">
                                The university needs UGC-DEB approval to provide distance learning courses.
                            </li>
                            <li class="">
                                Only 10% of the total universities in India, is allowed by DEB to provide Online Degree
                                Courses
                            </li>
                        </ul>
                    </div>


                    <div class="shadow-lg p-2 my-4">
                        <h6 class=" text-start"> <img src="assets/img/naac_logo.webp" alt=""> NAAC(National Assessment
                            and
                            Accreditation Council)
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li class="">
                                NAAC’s prime agenda is to assess the quality of education in Higher Education Institutes
                                and
                                then provide accreditation.
                            </li>
                            <li class="">
                                NAAC provides students with information about the quality of institutes.
                            </li>
                            <li class="">
                                NAAC provides full-fledged reviews to universities about strengths, weaknesses, and
                                opportunities that help institutions to improve.
                            </li>
                            <li>
                                NAAC accreditation ranges from A++ to C. A++ is the maximum grade
                            </li>


                        </ul>

                    </div>

                    <div class="shadow-lg p-2 my-4">
                        <h6 class=" text-start"> <img src="assets/img/nirf_logo.webp" alt=""> NIRF Ranking (National
                            Institutional Ranking Framework)
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li>
                                NIRF assess the teaching methodology of institutions and then provides them ranking
                                accordingly.
                            </li>
                            <li>
                                NIRF ranking helps students identify the best university amongst thousands.
                            </li>
                            <li>
                                NIRF provides ranking as per the 11 different categories and the ranking helps students
                                know
                                where the university stands in comparison to other universities in the same category.
                            </li>

                        </ul>

                    </div>

                    <div class="shadow-lg p-2 my-4">
                        <h6 class=" text-start"> <img src="assets/img/ugc_logo.webp" alt=""> AICTE (All India Council of
                            Technical Education)
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li>
                                AICTE approval is mandatory for technical institutes to offer courses that come under
                                AICTE.
                            </li>
                            <li>
                                The degrees of engineering institutes (except IITs, NITs, etc.) are valid only if they
                                have
                                AICTE approval.
                            </li>

                        </ul>

                    </div>

                    <div class="shadow-lg p-2 my-4">
                        <h6 class=" text-start"> <img src="assets/img/aiu_logo.webp" alt=""> AIU (Association of Indian
                            Universities)
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li>
                                AIU approval means your University Degree is valid across the Globe (Internationally
                                accepted)
                            </li>

                        </ul>

                    </div>

                    <div class="shadow-lg p-2 my-4">
                        <h6 class=" text-start"> <img src="assets/img/mobile-phone.png" class="img-fluid" alt=""> Verify
                            Your University
                        </h6>
                        <ul class=" text-start ms-4" style="list-style: unset;">
                            <li>
                                Don't make a decision that you might regret!
                            </li>
                            <li>
                                Pick UGC-DEB stamped universities only!
                            </li>


                        </ul>
                        <button type="submit" class="btn btn-danger text-start my-3">click to know</button>

                    </div>


                </div>

            </div>
        </div>
    </div>

</div>
<?php include 'real_owl.php' ?>

<?php include("footer.php"); ?>