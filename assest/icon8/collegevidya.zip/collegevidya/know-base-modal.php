<!-- The Modal -->
<div class="modal fade" id="myModal6">
    <div class="modal-dialog modal-dialog-scrollable modal-fullscreen ">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header border-0 align-items-center">

                <img src="admin/assets\images\collage\manav-rachna-online-logo.jpg" alt="" class="avatar ">

                <h6>Manav University</h6>
                <a href="#" class="ms-4 mb-2 text-primary"><span></span><span>Prospectus</span></a>


                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>


            </div>

            <div class="row">
                <ul class="nav nav-tabs nav-tabs-custom nav-justified" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#home1" role="tab">
                            <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                            <span class="d-none d-sm-block">Know Your University</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#profile1" role="tab">
                            <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                            <span class="d-none d-sm-block">Fees Breakup</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#messages1" role="tab">
                            <span class="d-block d-sm-none"><i class="far fa-envelope"></i></span>
                            <span class="d-none d-sm-block">Alumni Talk & Reviews</span>
                        </a>
                    </li>

                </ul>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="">
                            <div class="">



                                <!-- Nav tabs -->


                                <!-- Tab panes -->
                                <div class="tab-content p-3 text-muted">
                                    <div class="tab-pane active" id="home1" role="tabpanel">

                                        <h6 class=" fw-bold  my-2 my-sm-4">Manav University</h6>
                                        <div>
                                            <p>Shri Venkateshwara University (SVU) is situated in Gajraula, Uttar
                                                Pradesh. The university is known to promote excellence in higher
                                                education in India. SVU has been approved by University Grants
                                                Commission (UGC) and the AICTE**. Additionally, being a member of the
                                                Association of Indian Universities (AIU), it is an eminent higher
                                                education institution.&nbsp;&nbsp;</p>

                                            <p>In an initiative to bridge the gap between academia and industry needs,
                                                SVU provides technical education in the form of B.Tech and M.Tech
                                                courses for working professionals under the scheme of Work Integrated
                                                Learning Program (WILP). These courses are in part-time mode so that
                                                working professionals can easily balance both their work and
                                                studies.&nbsp;</p>

                                            <p>SVU is approved and entitled by UGC, and AICTE** to offer technical
                                                courses under the WILP category. SVU is also a member of the AIU. The
                                                classes are conducted in a hybrid mode with a blend of online and
                                                offline classes. There are offline practical classes conducted on
                                                Saturdays and over the weekend or students to attend. In case a student
                                                is not able to do the same, there are virtual simulation lab facilities
                                                that provide 24x7 access to learners to learn at their own pace.&nbsp;
                                            </p>

                                            <p>Students get the facility of a Learning Management System (LMS) where
                                                they can access the recorded video lectures in case they miss their
                                                online classes and other relevant study material for their course as
                                                well. Labs are conducted for practical learning every Saturday on
                                                campus. In case anybody is unable to attend the on-campus labs, then
                                                they get the facility to access labs through virtual and remote mode
                                                with simulations.&nbsp;</p>

                                            <p>WILP courses are a great opportunity for working professionals to upgrade
                                                their knowledge to keep up with the present times and trends fostering
                                                their professional as well as personal growth. With the help of WILP
                                                courses, people will be able to complete their higher education without
                                                taking a break in their careers.&nbsp;</p>

                                            <h6 class=" fw-bold  my-2 my-sm-4">Facts</h6>

                                            <div class="p-3 mb-3 positivediv card">SVU is entitled and approved by UGC
                                                and AICTE** to offer technical courses under the WILP category.</div>
                                            <div class="p-3 mb-3 positivediv card">SVU is entitled and approved by UGC
                                                and AICTE** to offer technical courses under the WILP category.</div>
                                            <div class="p-3 mb-3 positivediv card">SVU is entitled and approved by UGC
                                                and AICTE** to offer technical courses under the WILP category.</div>

                                            <h6 class=" fw-bold  my-2 my-sm-4">Approved By</h6>

                                            <p>Approvals To Look For Before Selecting A University</p>
                                            <div class="row-flex d-flex align-items-center">
                                                <img src="assets\img\New\ugc-logo.webp" class="img-fluid" alt="">

                                            </div>

                                            <h6 class=" fw-bold  my-2 my-sm-4">Sample Certificate</h6>
                                            <div class="row-flex d-flex align-items-center">
                                                <img src="assets\img\New\sv-university-sample-certificate.jpg"
                                                    class="img-fluid w-25" alt="">

                                            </div>


                                        </div>
                                    </div>
                                    <div class="tab-pane" id="profile1" role="tabpanel">
                                        <h6 class=" fw-bold  my-2 my-sm-4">Shri Venkateshwara WILP Fees</h6>
                                        <p class="m-0 bg-grey d-inline-block px-3 py-2 rounded me-2 mb-2 card"><svg
                                                stroke="currentColor" fill="currentColor" stroke-width="0"
                                                viewBox="0 0 1024 1024" font-size="20" height="1em" width="1em"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M894 462c30.9 0 43.8-39.7 18.7-58L530.8 126.2a31.81 31.81 0 0 0-37.6 0L111.3 404c-25.1 18.2-12.2 58 18.8 58H192v374h-72c-4.4 0-8 3.6-8 8v52c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-52c0-4.4-3.6-8-8-8h-72V462h62zM381 836H264V462h117v374zm189 0H453V462h117v374zm190 0H642V462h118v374z">
                                                </path>
                                            </svg> Loan Facility Available</p>
                                        <p class="m-0 bg-grey d-inline-block px-3 py-2 rounded me-2 mb-2 card"><svg
                                                stroke="currentColor" fill="currentColor" stroke-width="0"
                                                viewBox="0 0 1024 1024" font-size="20" height="1em" width="1em"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M894 462c30.9 0 43.8-39.7 18.7-58L530.8 126.2a31.81 31.81 0 0 0-37.6 0L111.3 404c-25.1 18.2-12.2 58 18.8 58H192v374h-72c-4.4 0-8 3.6-8 8v52c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-52c0-4.4-3.6-8-8-8h-72V462h62zM381 836H264V462h117v374zm189 0H453V462h117v374zm190 0H642V462h118v374z">
                                                </path>
                                            </svg> Easy to Pay</p>
                                        <p class="m-0 bg-grey d-inline-block px-3 py-2 rounded me-2 mb-2 card"><svg
                                                stroke="currentColor" fill="currentColor" stroke-width="0"
                                                viewBox="0 0 1024 1024" font-size="20" height="1em" width="1em"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M894 462c30.9 0 43.8-39.7 18.7-58L530.8 126.2a31.81 31.81 0 0 0-37.6 0L111.3 404c-25.1 18.2-12.2 58 18.8 58H192v374h-72c-4.4 0-8 3.6-8 8v52c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-52c0-4.4-3.6-8-8-8h-72V462h62zM381 836H264V462h117v374zm189 0H453V462h117v374zm190 0H642V462h118v374z">
                                                </path>
                                            </svg> Direct Pay to University</p>
                                        <p class="m-0 bg-grey d-inline-block px-3 py-2 rounded me-2 mb-2 card"><svg
                                                stroke="currentColor" fill="currentColor" stroke-width="0"
                                                viewBox="0 0 1024 1024" font-size="20" height="1em" width="1em"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M894 462c30.9 0 43.8-39.7 18.7-58L530.8 126.2a31.81 31.81 0 0 0-37.6 0L111.3 404c-25.1 18.2-12.2 58 18.8 58H192v374h-72c-4.4 0-8 3.6-8 8v52c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-52c0-4.4-3.6-8-8-8h-72V462h62zM381 836H264V462h117v374zm189 0H453V462h117v374zm190 0H642V462h118v374z">
                                                </path>
                                            </svg> No Hidden Charges</p>
                                        <div class="feestable my-4">
                                            <div class="table-responsive">
                                                <table class="table table-borderless">
                                                    <thead style="background-color: #f0f8ff;">
                                                        <tr>
                                                            <th>Fee Type</th>
                                                            <th>Total Fee</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody style="background-color: #f6f4dd">
                                                        <tr>
                                                            <td>Registration Fee (One Time)</td>
                                                            <td class="d-flex"><span class="Rupee_rupee__37VFU">₹</span>
                                                                2,000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Exam Fees (Per Sem.)</td>
                                                            <td class="d-flex"><span class="Rupee_rupee__37VFU">₹</span>
                                                                1,200</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Per Semester Fee</td>
                                                            <td class="d-flex"><span class="Rupee_rupee__37VFU">₹</span>
                                                                36,000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex align-items-center gap-1"><span>Full
                                                                        Fee</span><span class="cursor-pointer"><svg
                                                                            stroke="currentColor" fill="currentColor"
                                                                            stroke-width="0" viewBox="0 0 16 16"
                                                                            height="1em" width="1em"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            style="margin-top: -2px;">
                                                                            <path
                                                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                                                            </path>
                                                                            <path
                                                                                d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                                                            </path>
                                                                        </svg> </span></div>
                                                            </td>
                                                            <td class="d-flex"><span class="Rupee_rupee__37VFU">₹</span>
                                                                216,000</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="messages1" role="tabpanel">
                                        <h6 class=" fw-bold  my-2 my-sm-4">Alumni Talk & Reviews</h6>
                                        <div class="mb-3 bg-white p-3 rounded card">
                                            <p class="d-flex align-items-center justify-content-between"><span
                                                    class="fw-bold"><svg stroke="currentColor" fill="currentColor"
                                                        stroke-width="0" viewBox="0 0 16 16" font-size="30" height="1em"
                                                        width="1em" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
                                                        <path fill-rule="evenodd"
                                                            d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z">
                                                        </path>
                                                    </svg> Mridul Hussain Khan</span></p>
                                            <p class="fs-14">The online BBA course at Vignan University has a really
                                                good curriculum, and the course materials are also very detailed but
                                                easy to understand. The concepts are covered in-depth at the university
                                                and the faculty is very helpful in this regard. The LMS has a good UI,
                                                and helps me refer to the learning materials anytime at my own
                                                convenience.</p>
                                            <div class=" text-warning">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                        </div>
                                        <div class="mb-3 bg-white p-3 rounded card">
                                            <p class="d-flex align-items-center justify-content-between"><span
                                                    class="fw-bold"><svg stroke="currentColor" fill="currentColor"
                                                        stroke-width="0" viewBox="0 0 16 16" font-size="30" height="1em"
                                                        width="1em" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
                                                        <path fill-rule="evenodd"
                                                            d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z">
                                                        </path>
                                                    </svg> Mridul Hussain Khan</span></p>
                                            <p class="fs-14">The online BBA course at Vignan University has a really
                                                good curriculum, and the course materials are also very detailed but
                                                easy to understand. The concepts are covered in-depth at the university
                                                and the faculty is very helpful in this regard. The LMS has a good UI,
                                                and helps me refer to the learning materials anytime at my own
                                                convenience.</p>
                                            <div class=" text-warning">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                        </div>
                                        <div class="mb-3 bg-white p-3 rounded card">
                                            <p class="d-flex align-items-center justify-content-between"><span
                                                    class="fw-bold"><svg stroke="currentColor" fill="currentColor"
                                                        stroke-width="0" viewBox="0 0 16 16" font-size="30" height="1em"
                                                        width="1em" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
                                                        <path fill-rule="evenodd"
                                                            d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z">
                                                        </path>
                                                    </svg> Mridul Hussain Khan</span></p>
                                            <p class="fs-14">The online BBA course at Vignan University has a really
                                                good curriculum, and the course materials are also very detailed but
                                                easy to understand. The concepts are covered in-depth at the university
                                                and the faculty is very helpful in this regard. The LMS has a good UI,
                                                and helps me refer to the learning materials anytime at my own
                                                convenience.</p>
                                            <div class=" text-warning">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                        </div>
                                        <div class="mb-3 bg-white p-3 rounded card">
                                            <p class="d-flex align-items-center justify-content-between"><span
                                                    class="fw-bold"><svg stroke="currentColor" fill="currentColor"
                                                        stroke-width="0" viewBox="0 0 16 16" font-size="30" height="1em"
                                                        width="1em" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
                                                        <path fill-rule="evenodd"
                                                            d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z">
                                                        </path>
                                                    </svg> Mridul Hussain Khan</span></p>
                                            <p class="fs-14">The online BBA course at Vignan University has a really
                                                good curriculum, and the course materials are also very detailed but
                                                easy to understand. The concepts are covered in-depth at the university
                                                and the faculty is very helpful in this regard. The LMS has a good UI,
                                                and helps me refer to the learning materials anytime at my own
                                                convenience.</p>
                                            <div class=" text-warning">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>

            <!-- Modal footer -->
            <div class="mx-4 row-flex d-flex justify-content-between align-items-center border-1 ">
                <div class="">
                    <h6> ₹ 475,000 (Full Fee) </h6>
                </div>

                <div class="py-2">
                    <button type="button" class="btn btn-success">Proceed to University > </button>
                </div>
            </div>

        </div>
    </div>
</div>


