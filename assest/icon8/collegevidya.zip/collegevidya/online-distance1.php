<?php include("header.php");?>

    <div class="important-facts">
        <a href="">
            <img src="assets/img/icon/lightbulb.png" class="img-fluid" alt="">
            <h4>Important Facts</h4>
        </a>
    </div>
     
        
    <section class="online-distance-section">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="left-box">
                        <h4>Education Employability</h4>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                        <div class="advantages-box">
                            <h3>Education Employability Employment Advantages</h3>
                            <ul>
                                <li><i class="fa-sharp fa-solid fa-scale-balanced"></i> <span> Unbiased Counselling by Experts</span></li>
                                <li><i class="fa-solid fa-graduation-cap"></i> <span> Only Universities with Valid Approvals</span></li>
                                <li><i class="fa-sharp fa-solid fa-clock"></i> <span>Face to Face Counselling</span>  </li>
                                <li><i class="fa-solid fa-users"></i> <span> Directly Apply to the College with ‘Proceed To University’ Feature </span></li>
                                <li><i class="fa-solid fa-shield-virus"></i> <span> Full Time Degree Assistance</span></li>
                            </ul>
                            <img src="assets/img/icon/student-icons.png" class="img-fluid" alt="">
                            <div class="read-more">
                                <a href="">Why Us ? </a>
                            </div>
                        </div>
                    </div>

                    <div class="left-box mt-3">
                        <h4>Education Emplotability Emptloyment Existence</h4>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                        <div class="advantages-box">
                            <p>India has a net of 9.6 Million students that will enroll in online & distance education by the end of 2021. Still, online & distance education sector in India is unorganized and students face a lot of difficulties in getting information on it.</p>
                            <img src="assets/img/edge.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="right-box">
                        <div class="video-consultation-content">
                            <div class="row box-shadow-1 py-2 border-r-8 align-items-center justify-content-center">
                                <div class="col-md-1">
                                    <div class="navi-profile">
                                        <img src="assets/img/ourteam/pooja_singh.jpg" class="img-fluid">
                                        <span class="online"></span>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h2>
                                        <span class="font-weight-bold"> 
                                            <span class="grad-text">
                                                <img style="width: 20px;" src="assets/img/happy.png" class="img-fluid">
                                                 Hey sonu sonu , 
                                            </span> 
                                            </span> I'm Pooja , Below are the best approved universities for you
                                            according to the questions filled by you for 
                                        <span class="font-weight-bold">B.Com Fintech</span>
                                    </h2>
                                </div>
                                <div class="col-md-3"> 
                                    <div class="read-more">
                                        <a href="">Video Consultation</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="clg_large_col">
                            <ul class="list-unstyled comp_detail_bar_top d-flex align-items-center sticky-top" style="">
                                <li>University</li>
                                <li class="position-relative" data-toggle="modal" data-target="#ugc_modal">
                                    Approvals
                                    <span class="ques_know_top">
                                        Click to Know
                                    </span>
                                </li>
                                <li>
                                    <form action="">
                                        <select name="order" onchange="this.form.submit();">
                                            <option disabled="" selected=""> Fee </option>
                                            <option value="recommended"> Recommended </option>
                                            <option value="ASC">Low to high </option>
                                            <option value="DESC">High to low</option>
                                        </select>
                                    </form>
                                </li>
                                <li>
                                    <form action="">
                                        <select name="score" onchange="this.form.submit()">
                                            <option disabled="" selected=""> Education Emplotability Emptloyment Score </option>
                                            <option value="recommended"> Recommended </option>
                                            <option value="ASC">Low to high </option>
                                            <option value="DESC">High to low</option>
                                        </select>
                                    </form>
                                </li>
                                <li>

                                
                                    <form action="">
                                        <select name="rating" onchange="this.form.submit()">
                                            <option value="" disabled="" selected=""> Student Avg Rating: </option>
                                            <option value="recommended"> Recommended </option>
                                            <option value="ASC">Low to high </option>
                                            <option value="DESC">High to low</option>
                                        </select>
                                    </form>
                                </li>
                                <li>Compare Now</li>
                            </ul>
                            <p class="m-0 top-highlight-bar cursor-pointer">
                                <i class="fa fa-bolt" aria-hidden="true"></i> Proceed To University 
                                <i class="fa fa-chevron-right" aria-hidden="true"></i> 
                                <i class="fa fa-chevron-right" aria-hidden="true"></i>
                            </p>
                            <div class="drop_wrapper">
                                <ul class="list-unstyled comp_detail_bar align-items-center drop_filter drop-info" >
                                    <li> 
                                        <img class="w-100" src="assets/img/school/amrita.jpg" />
                                        <p class="sub_text m-0">
                                            Amrita Online Ahead
                                        </p>  
                                        <p class="m-0 schloar"><span class="green-dot-icon"></span> EDUCATION FOR LIVING</p>
                                    </li>
                                    <li>
                                        <p class="m-0 font-weight-bold approvals_desc">UGC, NIRF, NAAC A++, WES, AICTE<span class="ques_know">click to know</span></p>
                                    </li>
                                    <li>
                                        <p class="m-0 font-weight-bold">
                                            <span class="rupay">₹</span> 50000/ Semester
                                            <span class="ques" data-toggle="tooltip" data-placement="right" title="" data-original-title="1st Sem - 45,000/- &amp; Other 3 Sem - *50000)">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                                                    <path
                                                        d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                                                    ></path>
                                                </svg>
                                            </span>
                                        </p>
                                        <p class="m-0 font-weight-bold mob_rate d-none">
                                            <span class="mob_rate_info"><i class="fa fa-star" aria-hidden="true"></i> 9.6</span><span id="random_numm" class="position-absolute text-primary" style="right: 20px;">(266) </span>
                                            <span class="mob_rate_i" data-toggle="tooltip" data-placement="left" title="" data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors.">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                                                    <path
                                                        d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                                                    ></path>
                                                </svg>
                                            </span>
                                        </p>

                                        <p class="mob_new_rate m-0 mt-1" style="font-size: 10px;">
                                            <span>9.6 <i style="color: #ffa500;" class="fa fa-star" aria-hidden="true"></i></span><span id="random_numm" class="text-primary" style="right: 20px;"> 442 reviews </span>
                                            <span class="normal-i" data-toggle="tooltip" data-placement="right" title="" data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors.">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                                                    <path
                                                        d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                                                    ></path>
                                                </svg>
                                            </span>
                                        </p> 
                                        <p class="m-0 sub_text_other loan-desk"><i class="bi bi-bank"></i>Interest Free EMI Available</p>
                                    </li>
                                    <li>
                                        <p class="m-0 font-weight-bold rate-bar">
                                            <i class="fa fa-star" aria-hidden="true"></i> 9.6/10
                                            <span class="ques" data-toggle="tooltip"
                                                data-placement="right"
                                                title="" data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors." >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                                                    <path
                                                        d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                                                    ></path>
                                                </svg>
                                            </span>
                                        </p>
                                        <p style="font-size: 12px;" class="text-primary"><span id="random_numm">(597) reviews</span></p>
                                    </li>
                                    <li>
                                        <div class="you_thumb">
                                            <p class="m-0 font-weight-bold"><i class="fa fa-star" aria-hidden="true"></i> 4.4/5</p>
                                        </div>
                                        <p class="m-0 sub_text_other wes_color">
                                            WES (International) Approval
                                            <span class="normal-i" data-toggle="tooltip" data-placement="right" title="" data-original-title="Degree Internationally Accepted ✅ ">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                                                    <path
                                                        d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                                                    ></path>
                                                </svg>
                                            </span>
                                        </p>
                                    </li>
                                    <li> 
                                        <div class="read-more">
                                            <a href="">Add to Compare </a>
                                        </div>
                                    </li> 
                                    <p class="pros_cons_bar">
                                        <span class="pros_sec"><strong>Pros</strong> : Scholarships of upto 100% for eligible learners</span>
                                        <span class="ms-auto text-primary cursor-pointer">
                                            Proceed to University 
                                            <i class="fa fa-chevron-right" aria-hidden="true"></i> 
                                            <i class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </span> 
                                        <span></span>
                                    </p>
                                </ul>
                                <div class="alert alert-info d-flex align-items-center" role="alert">
                                    <img src="assets/img/error.gif" />
                                    <p class="m-0 p-4">
                                        <strong>Hey there,</strong> looks like the course in which you are interested is so unique that only a single university provides it. If in future any university starts providing the course and matches our strict parameters
                                        of Approvals, Learning Management System, Placement Assistance &amp; Faculty we will notify you. Education Emplotability Emptloyment strictly inspects all the factors before listing any universities.
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="popular_universities_comparison">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3>Popular <span>Universities </span>Comparison</h3>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row"> 
                <div class="col-md-8 m-md-auto">
                    <div class="popular_content">
                        <h6>Education Emplotability Emptloyment Recommender</h6>
                        <h3>Not Sure, Which University to choose?</h3>
                        <h5>Let us help you find the dream University</h5>
                        <div class="read-more">
                            <a href="">Schedule a Appointment <i class="fa-solid fa-clock ms-2"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <img src="assets/img/call-support.png" class="img-fluid  float-end" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="real-advice">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3>Real <span>Advice from Real </span> Experts</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae sed aspernatur accusantium vitae officiis eaque atque. Officiis alias asperiores tempora hic, ipsum ea fuga eius in voluptatum, magni itaque. Ea!</p>
                        <div class="icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme real-experts owl-loaded owl-drag">
                        
                    <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-1306px, 0px, 0px); transition: all 0s ease 0s; width: 2874px;"><div class="owl-item cloned" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div><div class="owl-item cloned active" style="width: 251.2px; margin-right: 10px;"><div class="item"> 
                            <div class="real-experts-content">
                                <img src="assets/img/experts/experts1.jpg" class="img-fluid experts-img" alt="">
                                <h3>Rahul Gupta </h3>
                                <h4><a href="">Consult Now</a></h4> 
                                <a href="" class="real-experts-btn">
                                    <img src="assets/img/icon/arrow.svg" class="img-fluid" alt=""> 
                                    
                                    Know More 
                                </a> 
                            </div>
                        </div></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div><div class="owl-dots disabled"></div></div>
                </div>
            </div>
        </div>
    </section>

<?php include("footer.php");?>