<?php include 'header.php' ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Mentors</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Projects</a></li>
                                <li class="breadcrumb-item active">Projects List</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="Add-Mentor.php" class="btn btn-success">Add Mentor</a>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="">
                        <div class="table-responsive">
                            <table class="table project-list-table table-nowrap align-middle table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col" style="width: 100px">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">course</th>
                                        <th scope="col">Location</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Consultation Fee</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><i class="mdi mdi-account-circle text-primary h1"></i></td>
                                        <td>
                                            <h5 class="text-truncate font-size-14"><a href="javascript: void(0);"
                                                    class="text-dark">Sarthak Garg</a></h5>
                                            <p class="text-muted mb-0">(Sr. Mentor)</p>
                                        </td>
                                        <td>B.tech</td>
                                        <td> India </td>
                                        <td>
                                            10:00 AM - 2:00 PM
                                        </td>
                                        <td>
                                            <h4>₹ 199</h4>
                                        </td>
                                        <td><span class="badge bg-success p-2">Active</span></td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="mentor.php" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><i class="mdi mdi-account-circle text-primary h1"></i></td>
                                        <td>
                                            <h5 class="text-truncate font-size-14"><a href="javascript: void(0);"
                                                    class="text-dark">Sarthak Garg</a></h5>
                                            <p class="text-muted mb-0">(Sr. Mentor)</p>
                                        </td>
                                        <td>B.tech</td>
                                        <td> India </td>
                                        <td>
                                            10:00 AM - 2:00 PM
                                        </td>
                                        <td>
                                            <h4>₹ 199</h4>
                                        </td>
                                        <td><span class="badge bg-success p-2">Active</span></td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="mentor.php" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><i class="mdi mdi-account-circle text-primary h1"></i></td>
                                        <td>
                                            <h5 class="text-truncate font-size-14"><a href="javascript: void(0);"
                                                    class="text-dark">Sarthak Garg</a></h5>
                                            <p class="text-muted mb-0">(Sr. Mentor)</p>
                                        </td>
                                        <td>B.tech</td>
                                        <td> India </td>
                                        <td>
                                            10:00 AM - 2:00 PM
                                        </td>
                                        <td>
                                            <h4>₹ 199</h4>
                                        </td>
                                        <td><span class="badge bg-success p-2">Active</span></td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="mentor.php" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><i class="mdi mdi-account-circle text-primary h1"></i></td>
                                        <td>
                                            <h5 class="text-truncate font-size-14"><a href="javascript: void(0);"
                                                    class="text-dark">Sarthak Garg</a></h5>
                                            <p class="text-muted mb-0">(Sr. Mentor)</p>
                                        </td>
                                        <td>B.tech</td>
                                        <td> India </td>
                                        <td>
                                            10:00 AM - 2:00 PM
                                        </td>
                                        <td>
                                            <h4>₹ 199</h4>
                                        </td>
                                        <td><span class="badge bg-danger p-2">Deactive</span></td>
                                        <td>
                                            <ul class="list-unstyled hstack gap-1 mb-0">
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="View">
                                                    <a href="mentor.php" class="btn  btn-soft-primary"><i
                                                            class="mdi mdi-eye-outline"></i></a>
                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                    <a href="#" class="btn btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a>
                                                                </li>
                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <a href="#jobDelete" data-bs-toggle="modal"
                                                        class="btn btn-soft-danger"><i
                                                            class="mdi mdi-delete-outline"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-12">
                    <div class="text-center my-3">
                        <a href="javascript:void(0);" class="text-success"><i
                                class="bx bx-loader bx-spin font-size-18 align-middle me-2"></i> Load more </a>
                    </div>
                </div> <!-- end col-->
            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


<?php include('footer.php') ?>