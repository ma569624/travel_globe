<!doctype html>
<html lang="en">

<?php require('header.php') ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Compare</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                <li class="breadcrumb-item active">Compare</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-6 card">
                    <div class="p-5">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class=" border-dark">
                                    <img src="assets/images/collage/Amity-University.jpg" alt="" class="w-100">
                                </div>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="">
                                <div class="alert alert-primary" role="alert">
                                    Get Best University At Affordable Fee
                                </div>
                                <div class="alert alert-primary" role="alert">
                                    Real Time Data of University to help you to decide
                                </div>
                                <div class="alert alert-primary" role="alert">
                                   Dedicated Assistance From Our Certified Exprets
                                </div>
                                
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Compare & Select University</h4>
                            <form>
                                <div class="row mb-4">
                                    <label for="name" class="col-form-label col-lg-2">Name</label>
                                    <div class="col-lg-10">
                                        <input id="name" name="name" type="text" class="form-control"
                                            placeholder="Enter Name...">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="email" class="col-form-label col-lg-2">Email</label>
                                    <div class="col-lg-10">
                                        <input id="email" name="email" type="text" class="form-control"
                                            placeholder="Enter Your Email...">
                                    </div>
                                </div>

                                

                                <div class="row mb-4">
                                    <label class="col-form-label col-lg-2">Gender</label>
                                    <div class="col-lg-5">
                                        <div class=" form-check">
                                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                                                id="flexRadioDefault1">
                                            <label class="form-check-label" for="flexRadioDefault1">
                                                Male
                                            </label>
                                        </div>
                                    </div>

                                    <div class="col-lg-5">
                                        <div class="form-check ">
                                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                                                id="flexRadioDefault2" checked>
                                            <label class="form-check-label" for="flexRadioDefault2">
                                                Female
                                            </label>
                                        </div>
                                    </div>

                                </div>

                                <div class="row mb-4">
                                    <label for="projectbudget" class="col-form-label col-lg-2">Mobile Number</label>
                                    <div class="col-lg-10">
                                        <input id="projectbudget" name="projectbudget" type="text"
                                            placeholder="Enter Your Mobile Number..." class="form-control">
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <label for="projectbudget" class="col-form-label col-lg-2">State</label>
                                    <div class="col-lg-10">
                                        <select class="form-select " aria-label=" example">
                                            <option selected>Select</option>
                                            <option value="1">one</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="projectbudget" class="col-form-label col-lg-2">Specialization</label>
                                    <div class="col-lg-10">
                                        <select class="form-select" aria-label=" example">
                                            <option selected>Not decided yet</option>
                                            <option value="1">one</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                </div>

                            </form>
                            <div class="row mb-4">
                                <label class="col-form-label col-lg-2">Attached Files</label>
                                <div class="col-lg-10">
                                    <form action="https://themesbrand.com/" method="post" class="dropzone">
                                        <div class="fallback">
                                            <input name="file" type="file" multiple />
                                        </div>

                                        <div class="dz-message needsclick">
                                            <div class="mb-3">
                                                <i class="display-4 text-muted bx bxs-cloud-upload"></i>
                                            </div>

                                            <h4>Drop files here or click to upload.</h4>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="row justify-content-end">
                                <div class="col-lg-10">
                                    <button type="submit" class="btn btn-primary">Create Project</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    
    <?php include('footer.php') ?>