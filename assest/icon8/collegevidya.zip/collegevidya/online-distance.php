<?php include("header.php"); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-9">

            <div class="container-fluid ">
            
   
                <div class="row bg-success py-1">
                    <div class="col-lg-2 col-sm-12 justify-content-center text-center">
                        <img src="assets\img\icon\img_avatar2.png" alt="Avatar Logo" style="width:60px;"
                            class="rounded-pill mt-3 text-center">
                    </div>
                    <div class="col-lg-7 col-sm-12 justify-content-center ">
                        <p class="text-light text-center mt-3 " style="font-size: 12px"> Hey , I'm Pooja , Below are the
                            best approved
                            universities
                            for you
                            according to the questions
                            filled by you for MCA Data Analytics</p>

                    </div>
                    <div class="col-lg-3 read-more col-sm-12 justify-content-center text-center text-light">
                        <a href="#" class="btn justify-content-center text-center default-btn1 mt-4"
                            data-bs-toggle="modal" data-bs-target="#myModal">Video
                            Consultation</a>

                           
                            
                    </div>

                </div>
            </div>

            <div class="clg_large_col">
                <ul class="list-unstyled comp_detail_bar_top d-flex align-items-center sticky-top" style="">
                    <li>University</li>
                    <li class="position-relative" data-toggle="modal" data-target="#ugc_modal">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#myModal3" class="text-light"> Approvals </a>
                        <span class="ques_know_top">
                            Click to Know
                        </span>
                    </li>
                    <li>
                        <form action="">
                            <select name="order" onchange="this.form.submit();">
                                <option disabled="" selected=""> Fee </option>
                                <option value="recommended"> Recommended </option>
                                <option value="ASC">Low to high </option>
                                <option value="DESC">High to low</option>
                            </select>
                        </form>
                    </li>
                    <li>
                        <form action="">
                            <select name="score" onchange="this.form.submit()">
                                <option disabled="" selected=""> Education Emplotability Emptloyment Score </option>
                                <option value="recommended"> Recommended </option>
                                <option value="ASC">Low to high </option>
                                <option value="DESC">High to low</option>
                            </select>
                        </form>
                    </li>
                    <li>

                        <form action="">
                            <select name="rating" onchange="this.form.submit()">
                                <option value="" disabled="" selected=""> Student Avg Rating: </option>
                                <option value="recommended"> Recommended </option>
                                <option value="ASC">Low to high </option>
                                <option value="DESC">High to low</option>
                            </select>
                        </form>
                    </li>
                    <li>Compare Now</li>
                </ul>

                <p class="m-0 top-highlight-bar cursor-pointer">
                    <a href="#" class="btn " style="width:99%" data-bs-toggle="modal" data-bs-target="#myModal2">
                        <i class="fa fa-bolt" aria-hidden="true"></i> Proceed To University
                        <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                </p>
                <div class="drop_wrapper">
                    <ul class="list-unstyled comp_detail_bar align-items-center drop_filter drop-info">
                        <li>
                            <a href="#" data-bs-toggle="modal" data-bs-target="#myModal6"><img class="w-100"
                                    src="assets/img/school/amrita.jpg" /></a>
                            <p class="sub_text m-0">
                                Amrita Online Ahead
                            </p>
                            <p class="m-0 schloar"><span class="green-dot-icon"></span> EDUCATION FOR LIVING</p>
                        </li>
                        <li>
                            <p class="m-0 font-weight-bold approvals_desc">UGC, NIRF, NAAC A++, WES, AICTE<span
                                    class="ques_know" data-bs-toggle="modal" data-bs-target="#myModal3">click to
                                    know</span></p>
                        </li>
                        <li>
                            <p class="m-0 font-weight-bold">
                                <span class="rupay">₹</span> 50000/ Semester
                                <span class="ques" data-toggle="tooltip" data-placement="right" title=""
                                    data-original-title="1st Sem - 45,000/- &amp; Other 3 Sem - *50000)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor"
                                        class="bi bi-info-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                        </path>
                                        <path
                                            d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                        </path>
                                    </svg>
                                </span>
                            </p>

                            <p class="m-0 font-weight-bold mob_rate d-none">
                                <span class="mob_rate_info"><i class="fa fa-star" aria-hidden="true"></i>
                                    9.6</span><span id="random_numm" class="position-absolute text-primary"
                                    style="right: 20px;">(266) </span>
                                <span class="mob_rate_i" data-toggle="tooltip" data-placement="left" title=""
                                    data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors.">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                                        class="bi bi-info-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                        </path>
                                        <path
                                            d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                        </path>
                                    </svg>
                                </span>
                            </p>

                            <p class="mob_new_rate m-0 mt-1" style="font-size: 10px;">
                                <span>9.6 <i style="color: #ffa500;" class="fa fa-star"
                                        aria-hidden="true"></i></span><span id="random_numm" class="text-primary"
                                    style="right: 20px;"> 442 reviews </span>
                                <span class="normal-i" data-toggle="tooltip" data-placement="right" title=""
                                    data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors.">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor"
                                        class="bi bi-info-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                        </path>
                                        <path
                                            d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                        </path>
                                    </svg>
                                </span>
                            </p>
                            <p class="m-0 sub_text_other loan-desk"><i class="bi bi-bank"></i>Interest Free EMI
                                Available</p>
                        </li>
                        <li>
                            <p class="m-0 font-weight-bold rate-bar">
                                <i class="fa fa-star" aria-hidden="true"></i> 9.6/10
                                <span class="ques" data-toggle="tooltip" data-placement="right" title=""
                                    data-original-title="This is the score calculated after university performance on approvals, e-learning, student rating, Fees &amp; other various factors.">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor"
                                        class="bi bi-info-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                        </path>
                                        <path
                                            d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                        </path>
                                    </svg>
                                </span>
                            </p>
                            <p style="font-size: 12px;" class="text-primary"><span id="random_numm">(597) reviews</span>
                            </p>
                        </li>
                        <li>
                            <div class="you_thumb">
                                <p class="m-0 font-weight-bold"><i class="fa fa-star" aria-hidden="true"></i> 4.4/5</p>
                            </div>
                            <p class="m-0 sub_text_other wes_color">
                                WES (International) Approval
                                <span class="normal-i" data-toggle="tooltip" data-placement="right" title=""
                                    data-original-title="Degree Internationally Accepted ✅ ">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor"
                                        class="bi bi-info-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z">
                                        </path>
                                        <path
                                            d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z">
                                        </path>
                                    </svg>
                                </span>
                            </p>
                        </li>
                        
                        <li>
                            <div style="font-size: 12px;" class="ms-2 text-center" data-bs-toggle="modal" data-bs-target="#expert">
                                <a href="#" > <span class=""><svg stroke="currentColor" fill="currentColor" stroke-width="0" version="1" viewBox="0 0 48 48" enable-background="new 0 0 48 48" font-size="30" class="mx-auto" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><polygon fill="#FF9800" points="24,37 19,31 19,25 29,25 29,31"></polygon><g fill="#FFA726"><circle cx="33" cy="19" r="2"></circle><circle cx="15" cy="19" r="2"></circle></g><path fill="#FFB74D" d="M33,13c0-7.6-18-5-18,0c0,1.1,0,5.9,0,7c0,5,4,9,9,9s9-4,9-9C33,18.9,33,14.1,33,13z"></path><path fill="#424242" d="M24,4c-6.1,0-10,4.9-10,11c0,0.8,0,2.3,0,2.3l2,1.7v-5l12-4l4,4v5l2-1.7c0,0,0-1.5,0-2.3c0-4-1-8-6-9l-1-2 H24z"></path><g fill="#784719"><circle cx="28" cy="19" r="1"></circle><circle cx="20" cy="19" r="1"></circle></g><polygon fill="#fff" points="24,43 19,31 24,32 29,31"></polygon><polygon fill="#D32F2F" points="23,35 22.3,39.5 24,43.5 25.7,39.5 25,35 26,34 24,32 22,34"></polygon><path fill="#546E7A" d="M29,31L29,31l-5,12l-5-12c0,0-11,2-11,13h32C40,33,29,31,29,31z"></path></svg></span> <br> Talk
                                    with a Licensed Expert -></a>
                            </div>
                        </li>
                        <!--<li>
                            <div class="read-more">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#myModal2">Add to Compare</a>
                            </div>
                        </li>
                            
                            -->

                        <span class="pros_cons_bar">
                            <span class="pros_sec">Know University
                            </span>
                            <span class="pros_sec">
                            </span>
                            <span class="ms-auto pros_sec"><strong>Pros</strong>
                            </span>
                            <span class=" ms-auto pros_sec">CV Advantages
                            </span>
                            <span class=" ms-auto pros_sec" data-bs-toggle="modal" data-bs-target="#selectuni"><input
                                    type="checkbox" id="" class="form-check-input">
                                <label class="form-check-label ms-1" for="flexCheckDefault">
                                    Add To Compaire
                                </label>
                            </span>


                        </span>

                    </ul>
                    <div class="alert alert-info d-flex align-items-center" role="alert">
                        <img src="assets/img/error.gif" />
                        <p class="m-0 p-4">
                            <strong>Hey there,</strong> looks like the course in which you are interested is so unique
                            that only a single university provides it. If in future any university starts providing the
                            course and matches our strict parameters
                            of Approvals, Learning Management System, Placement Assistance &amp; Faculty we will notify
                            you. Education Emplotability Emptloyment strictly inspects all the factors before listing
                            any universities.
                        </p>
                    </div>
                </div>
            </div>






        </div>

        <div class="col-lg-3">

            <h4 class="text-primary mt-5 mb-5">
                #Righttoselect<svg version="1.1" id="Layer_1" width="30" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500"
                    enable-background="new 0 0 500 500" xml:space="preserve">
                    <style>
                        #wing1 {
                            transform-origin: center;
                            animation: flap 0.4s ease-out infinite alternate;
                        }

                        #wing2 {
                            transform-origin: center;
                            animation: flap 0.4s ease-in infinite alternate;
                        }

                        @keyframes flap {
                            50% {
                                transform: scaleX(-1) rotate(-45deg) translate(-40px, -40px);
                            }
                        }
                    </style>
                    <path id="body" fill="#5DA8DC" d="M142.9,364.1c-1.6,1-3,1.7-4,2.3c-3,1.5-7.9,3.8-14.9,6.9c-7,3.1-14.7,5.7-23.1,7.9
                c-8.4,2.2-15.6,3.8-21.8,4.7c-6.2,0.9-12.2,1.5-18.1,1.8s-11.4,0.3-16.7,0c-5.2-0.3-8.5-0.5-9.6-0.6l-1.8-0.2l-0.4-0.1l-0.4-0.1v0.8
                h0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H33l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l3.6,2.2c2.4,1.5,4.5,2.6,6.4,3.6
                s6.6,3.3,14.1,7.1c7.6,3.7,16.6,7.4,27.2,11.1s18.6,6.2,24,7.4c5.4,1.3,12.8,2.6,22.2,3.9s14.9,2.1,16.3,2.2
                c1.5,0.1,3.3,0.3,5.5,0.4l3.3,0.2v0.2h25.6v-0.2l14-1.3c9.3-0.9,17.6-2.1,25-3.3c7.3-1.3,14.9-3.1,22.8-5.5
                c7.9-2.4,15.3-4.9,22.4-7.7c7.1-2.8,13.7-5.7,19.7-9c6.1-3.2,11.3-6,15.6-8.5c4.3-2.5,9.1-5.6,14.2-9.3c5.2-3.7,10-7.5,14.6-11.2
                s7.1-5.9,7.7-6.4c0.6-0.6,4-4,10.2-10.2c6.2-6.3,11.3-11.9,15.4-16.8c4-5,8-10.3,12-15.9c3.9-5.6,8.3-12.5,13-20.6
                s9.2-17.3,13.5-27.5s8-20.7,11-31.5c3-10.7,5.2-20.4,6.7-28.9s2.4-16.5,3-23.8c0.5-7.3,0.8-13.9,0.9-19.7s2.5-10.8,7.4-14.8
                s9.9-8.5,15-13.7c5.1-5.1,7.9-8,8.3-8.7c0.5-0.7,0.9-1.1,1.1-1.2c0.3-0.1,2.1-2.3,5.3-6.7c3.3-4.4,5-6.6,5-6.7l0.1-0.1l0.2-0.4
                l0.2-0.4l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.2-0.1l0.2-0.1V115l-1,0.3l-0.8,0.1
                l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.6,0.2l-1.2,0.4l-10.6,3.6c-6.7,2.2-13.7,4.1-21,5.7l-11,2.4h-1.9l0.1-0.1l0.1-0.1l0.1-0.1
                l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l1.9-1.3
                c1.3-0.9,2.4-1.8,3.3-2.8s2.8-2.7,5.6-5.1c2.8-2.4,6-6,9.5-10.7s6.5-9.4,8.8-14s3.6-7.2,3.7-7.9c0.1-0.6,0.3-1.2,0.4-1.6l0.2-0.6
                l0.2-0.4l0.2-0.4l0.2-0.6l0.2-0.6l0.1-0.6l0.1-0.6l-0.4,0.1l-0.4,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.4,0.2l-0.4,0.2
                l-0.4,0.2l-0.4,0.2l-0.1,0.1c-0.1,0.1-0.8,0.4-1.9,1.2c-1.2,0.7-4.7,2.4-10.5,5s-11.6,5-17.5,7.1s-11.4,3.7-16.5,4.9
                s-8.8,0.5-11.3-1.9c-2.4-2.4-5.2-4.7-8.3-6.9c-3.1-2.2-6.5-4.3-10.4-6.4c-3.8-2.1-7.7-3.9-11.8-5.5c-4-1.6-8.6-2.9-13.5-3.8
                l-7.4-1.5h-20.5v0.1c0,0.1-1.7,0.4-5.1,0.9s-7.6,1.6-12.6,3.3c-5,1.7-10.4,4.2-16.3,7.4c-5.9,3.3-11.1,7-15.7,11.2
                s-8.3,8.3-11.2,12.2c-2.9,3.9-5.2,7.4-7,10.5C221.5,163.3,231.3,307,142.9,364.1z"></path>
                    <path id="wing1" fill="#5DA8DC" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                    <path id="wing2" fill="#C4DFF2" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                </svg>
            </h4>
            <div class="card pb-4 shadow">
                <ul class="ps-2 mt-5">
                    <li class=" ">
                        <h5 class="">Education Emplotability Emptloyment Advantages</h5>
                    </li>
                    <li class="">

                        <p class=""> <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24"
                                stroke="#ff9b2c">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3">
                                </path>
                            </svg> Unbiased Counselling by Experts </p>
                    </li>
                    <li class=" ">
                        <p class=""> <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24"
                                stroke="#ff9b2c">
                                <path d="M12 14l9-5-9-5-9 5 9 5z"></path>
                                <path
                                    d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z">
                                </path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222">
                                </path>
                            </svg> Only Universities with Valid Approvals</p>
                    </li>
                    <li class=" ">
                        <p class=""><svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24"
                                stroke="#ff9b2c">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg> Face to Face Counselling</p>
                    </li>
                    <li class=" ">
                        <p class=""><svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24"
                                stroke="#ff9b2c">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z">
                                </path>
                            </svg> Directly Apply to the College with ‘Proceed To University’ Feature </p>
                    </li>
                    <li class=" ">
                        <p class=""><svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 20 20"
                                fill="#ff9b2c">
                                <path fill-rule="evenodd"
                                    d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                    clip-rule="evenodd"></path>
                            </svg> Full Time Degree Assistance </p>
                    </li>
                    <li class="text-center">
                        <img src="assets/img/student.jpg" class="img-fluid" alt="">
                    </li>
                    <li class="text-center my-1 px-2"><button class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#myModal5">Why Education Emplotability Emptloyment ?</button></li>


                </ul>
            </div>
            <div class="card mt-3 shadow">
                <div class="card-body">
                    <h5 class="card-title">Education Emplotability Emptloyment Existence</h5>
                    <p class="card-text">India has a net of 9.6 Million students that will enroll in online & distance
                        education by the end of 2021. Still, online & distance education sector in India is unorganized
                        and students face a lot of difficulties in getting information on it.
                    </p>

                </div>
                <img class="card-img-bottom" src="assets/img/collge-vidya-edge.jpg" alt="Card image" style="width:100%">
            </div>



        </div>



    </div>

</div>

<div class="container">
    <div class="row my-4">
        <h4>Popular Universities Comparison</h4>
    </div>



</div>

<div class="container">
    <div class="row  shadow">


        <div class="col-lg-2 text-center">
            <img src="assets/img/confused.png" class="img-fluid" width="150" alt="">
        </div>
        <div class="col-lg-7">
            <div class="mt-4" style="text-align: center;">
                <p>Education Emplotability Emptloyment Recommender</p>
                <h2>Not Sure, Which University to choose?</h2>
                <p>Let us help you find the dream University</p>
            </div>

        </div>
        <div class="col-lg-3 text-center">
            <a href="#" class="btn btn-primary btn-lg mt-5">Schedule a Appointment</a>
        </div>

    </div>
</div>
<div class="container mb-5">
    <div class="row mt-5 pb-2 shadow">
        <h4 class="py-3">Popular Universities in 2022</h4>
        <div class="col-lg-3 mt-3">
            <div class="card">
                <img class="card-img-top" src="assets/img/icon/Jain-University.jpg" alt="Card image" style="width:100%">
                <a href="#" class="btn btn-primary">Jain University</a>
            </div>
        </div>

    </div>
</div>

<?php include 'real_owl.php' ?>

<div class="container mt-5">
    <div class="row text-center mt-5 mb-5">
        <div class="col-lg-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z">
                </path>
            </svg>
            <h5>India’s #1</h5>
            <p>Larget Online Education Portal</p>
        </div>
        <div class="col-lg-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10">
                </path>
            </svg>
            <h5>500 +</h5>
            <p>Admissions every 1 hour</p>
        </div>
        <div class="col-lg-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3">
                </path>
            </svg>
            <h5>Compare</h5>
            <p>(Decode the right University for you)</p>
        </div>
        <div class="col-lg-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                </path>
            </svg>
            <h5>Scholarship</h5>
            <p>Stay updated</p>
        </div>
    </div>
</div>

<!-- The Modal -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog ">
        <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body text-center">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                <div>
                    <img src="assets/img/logo-design.png" alt="" class="img-fluid" alt="" width="150" height="100">

                    <h4 class="my-3">
                        Video Consultation
                    </h4>
                </div>

                <!-- Carousel -->
                <div id="demo" class="carousel slide" data-bs-ride="carousel">

                    <!-- Indicators/dots -->
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                    </div>

                    <!-- The slideshow/carousel -->
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="assets/img/home_slider/slide1.jpg" alt="Los Angeles" class="d-block w-100">
                        </div>
                        <div class="carousel-item">
                            <img src="assets/img/home_slider/slide1.jpg" alt="Chicago" class="d-block w-100">
                        </div>
                        <div class="carousel-item">
                            <img src="assets/img/home_slider/slide1.jpg" alt="New York" class="d-block w-100">
                        </div>
                    </div>

                    <!-- Left and right controls/icons -->
                    <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </button>
                </div>


                <div class="row my-3">
                    <div class="col text-center">
                        <a href="#">
                            <div class="card text-center"><img src="assets/img/5e8ce318664eae0004085461.png"
                                    class="img-fluid text-center" style="margin: 0 0 0 30%;" width="50" alt="">
                                <p>Convenient call / video connects</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="#">
                            <div class="card text-center"><img src="assets/img/Lock-Icon-PNG-Graphic-Cave.png"
                                    class="img-fluid" style="margin: 0 0 0 35%;" width="50" alt="">
                                <p>Private & Secure platform</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="#">
                            <div class="card text-center"><img src="assets/img/chat.png" style="margin: 0 0 0 35%;"
                                    class="img-fluid" width="60" alt="">
                                <p>Available <br> (7 days)</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="row py-1">

                    <button type="submit" class="btn btn-primary btn-lg text-start my-5 text-center">Talk to India's Top
                        Mentors
                        </butto>

                </div>

                <div class="row  ps-4">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets/img/New/Joshi-sir.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\Ankit Singh.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;"
                        src="assets\img\New\eexpert-team3.jpg" alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\Neeta.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\preeti.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\pallavi.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\Tabassum.jpg"
                        alt="Card image">

                    <img class="img-fluid rounded-circle px-0" style="width:55px;" src="assets\img\New\isha-sharma.jpg"
                        alt="Card image">
                </div>

                <div class="row py-3">
                    <a href="#" class="btn btn-default">Consult Trusted & Senior Advisors for your University Selection
                        <br>
                        (10 AM to 7 PM on all the 7 days of the week)
                    </a>
                </div>

                <!-- Carousel -->
                <div id="demo1" class="carousel slide" data-bs-ride="carousel">

                    <!-- Indicators/dots -->
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#demo1" data-bs-slide-to="0" class="active"></button>
                        <button type="button" data-bs-target="#demo1" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#demo1" data-bs-slide-to="2"></button>
                    </div>

                    <!-- The slideshow/carousel -->
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="assets/img/modal-bg.png" alt="Los Angeles" class="d-block w-100">
                            <div class="carousel-caption">
                                <p>It was a great experience talking with the Senior Counselor who patiently listened my
                                    requirements and guided me towards best university according to my needs.</p>


                                <p> Chandan Singh</p>
                            </div>
                        </div>

                        <div class="carousel-item">
                            <img src="assets/img/modal-bg.png" alt="New York" class="d-block w-100">
                            <div class="carousel-caption">
                                <p>I was really confused and was not able to select the university. I talked to the
                                    counselor and he understood my requirement and then told me what options I have in
                                    just 20 minutes. It was a WOW Experience.</p>


                                <p>Sarthak Garg</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="assets/img/modal-bg.png" alt="Chicago" class="d-block w-100">
                            <div class="carousel-caption">
                                <p>IThe answer to all my questions were kindly provided. Excellent experience consulting
                                    with Education Emplotability Emptloyment Counselor. Highly Recommended!</p>

                                <p>Pawan singh</p>
                            </div>
                        </div>
                    </div>

                    <!-- Left and right controls/icons -->
                    <button class="carousel-control-prev" type="button" data-bs-target="#demo1" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#demo1" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </button>
                </div>

                <h4 class="pt-3">
                    Frequently Asked Questions
                </h4>
                <div id="accordion" class="pb-5 pt-2">

                    <div class="card">
                        <div class="card-header">
                            <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                                Are the specialist Counselors available 24/7?
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
                            <div class="card-body">
                                Our specialists are available for consultation from 10AM to 7PM on all the 7 days of the
                                week
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
                                What are the qualifications of the counselors?
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
                            <div class="card-body">
                                All counselors on the Education Emplotability Emptloyment platform are highly qualified
                                and experienced with a
                                minimum qualification of Post Graduate in their chosen field of specialisation, in
                                addition to their PG Diploma in Career Counseling. You can see their details (Name,
                                experience, degrees) also.
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
                                I consulted with XYZ counselor 5 days ago. Can I connect with him/her again for a follow
                                up?
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
                            <div class="card-body">
                                You are entitled to one free follow-up consultation with a specialist counselor within 7
                                days of your first consultation. We will connect you to the same specialist depending on
                                slot availability.
                            </div>
                        </div>
                    </div>

                </div>



            </div>

        </div>
    </div>
</div>




<!-- The Modal1 -->
<div class="modal fade" id="myModal1">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body text-center">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                <div>
                    <div class="barder-1">
                        <img src="assets\img\icon\Jain-University.jpg" alt="" class="img-fluid" alt="" width="150"
                            height="100">
                    </div>

                    <h4 class="text-left">
                        Hi cvxbfg 👋
                    </h4>

                </div>

                <div class="alert alert-info">
                    <strong>⚠</strong> Pay Your Fees only at the Official Website of the University
                </div>

                <div class="shadow-lg p-2 mt-4">
                    <p>“ Thank you for taking the first step towards a fruitful journey towards your career growth. We
                        have shared your interest with the University and they will call you shortly. Till then, as this
                        decision of your life is very important, we recommend to explore other options and choose best
                        for you 😊</p>
                </div>

                <button type="submit" class="btn btn-success text-start my-5">I want to Explore More</butto>


            </div>

        </div>
    </div>
</div>


<!-- The Modal -->
<div class="modal fade" id="selectuni">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header border-0">

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body pb-5">
                <div class="row">
                    <div class="col-lg-10">
                        <h5 class="modal-title text-left">Choose 3 University to compare</h5>
                    </div>

                    <div class="col-lg-2">
                        <div><a href="checkin.php" type="button" class="btn btn-success text-right">Compare</a></div>
                    </div>

                </div>

                <div class="row mt-5">
                    <div class="col-lg-4">
                        <div class="card shadow-lg text-center">
                            <img src="assets\img\collage\university-of-mysore-logo.jpg" class="img-fluid ps-5" alt=""
                                width="180">
                            <p style="font-size: 14px;">University of Mysore</p>
                            <h5>₹ 92625/ Full Fees</h5>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card shadow-lg text-center">
                            <img src="assets/img/collage/Amity-University.jpg" class="img-fluid ps-5" alt=""
                                width="180">
                            <p style="font-size: 14px;">Amity Online University</p>
                            <h5>₹ 63250/ Semester</h5>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card shadow-lg text-center">
                            <img src="assets\img\collage\Jain-University.jpg" class="img-fluid ps-5" alt="" width="180">
                            <p style="font-size: 14px;">Jain University</p>
                            <h5>₹ 40000/ Semester</h5>
                        </div>
                    </div>

                </div>
                <div class="row mt-5">
                    <div class="col-lg-4">
                        <div class="card shadow-lg text-center">
                            <img src="assets/img/collage/manav-rachna-online-logo.jpg" class="img-fluid ps-5" alt=""
                                width="180">
                            <p style="font-size: 14px;">Manav Rachna University Online</p>
                            <h5>₹ 92625/ Full Fees</h5>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card shadow-lg text-center">
                            <img src="assets\img\collage\university-of-mysore-logo.jpg" class="img-fluid ps-5" alt=""
                                width="180">
                            <p style="font-size: 14px;">D.Y. Patil Vidyapeeth</p>
                            <h5>₹ 63250/ Semester</h5>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>
</div>


<!-- The Modal1 -->
<div class="modal fade" id="myModal3">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body text-center">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                <div>
                    <img src="assets/img/logo-design.png" alt="" class="img-fluid" alt="" width="150" height="100">
                    <h4 class="text-primary">
                        #Righttoselect<svg version="1.1" id="Layer_1" width="30" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500"
                            enable-background="new 0 0 500 500" xml:space="preserve">
                            <style>
                                #wing1 {
                                    transform-origin: center;
                                    animation: flap 0.4s ease-out infinite alternate;
                                }

                                #wing2 {
                                    transform-origin: center;
                                    animation: flap 0.4s ease-in infinite alternate;
                                }

                                @keyframes flap {
                                    50% {
                                        transform: scaleX(-1) rotate(-45deg) translate(-40px, -40px);
                                    }
                                }
                            </style>
                            <path id="body" fill="#5DA8DC" d="M142.9,364.1c-1.6,1-3,1.7-4,2.3c-3,1.5-7.9,3.8-14.9,6.9c-7,3.1-14.7,5.7-23.1,7.9
                c-8.4,2.2-15.6,3.8-21.8,4.7c-6.2,0.9-12.2,1.5-18.1,1.8s-11.4,0.3-16.7,0c-5.2-0.3-8.5-0.5-9.6-0.6l-1.8-0.2l-0.4-0.1l-0.4-0.1v0.8
                h0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H33l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l3.6,2.2c2.4,1.5,4.5,2.6,6.4,3.6
                s6.6,3.3,14.1,7.1c7.6,3.7,16.6,7.4,27.2,11.1s18.6,6.2,24,7.4c5.4,1.3,12.8,2.6,22.2,3.9s14.9,2.1,16.3,2.2
                c1.5,0.1,3.3,0.3,5.5,0.4l3.3,0.2v0.2h25.6v-0.2l14-1.3c9.3-0.9,17.6-2.1,25-3.3c7.3-1.3,14.9-3.1,22.8-5.5
                c7.9-2.4,15.3-4.9,22.4-7.7c7.1-2.8,13.7-5.7,19.7-9c6.1-3.2,11.3-6,15.6-8.5c4.3-2.5,9.1-5.6,14.2-9.3c5.2-3.7,10-7.5,14.6-11.2
                s7.1-5.9,7.7-6.4c0.6-0.6,4-4,10.2-10.2c6.2-6.3,11.3-11.9,15.4-16.8c4-5,8-10.3,12-15.9c3.9-5.6,8.3-12.5,13-20.6
                s9.2-17.3,13.5-27.5s8-20.7,11-31.5c3-10.7,5.2-20.4,6.7-28.9s2.4-16.5,3-23.8c0.5-7.3,0.8-13.9,0.9-19.7s2.5-10.8,7.4-14.8
                s9.9-8.5,15-13.7c5.1-5.1,7.9-8,8.3-8.7c0.5-0.7,0.9-1.1,1.1-1.2c0.3-0.1,2.1-2.3,5.3-6.7c3.3-4.4,5-6.6,5-6.7l0.1-0.1l0.2-0.4
                l0.2-0.4l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.2-0.1l0.2-0.1V115l-1,0.3l-0.8,0.1
                l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.6,0.2l-1.2,0.4l-10.6,3.6c-6.7,2.2-13.7,4.1-21,5.7l-11,2.4h-1.9l0.1-0.1l0.1-0.1l0.1-0.1
                l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l1.9-1.3
                c1.3-0.9,2.4-1.8,3.3-2.8s2.8-2.7,5.6-5.1c2.8-2.4,6-6,9.5-10.7s6.5-9.4,8.8-14s3.6-7.2,3.7-7.9c0.1-0.6,0.3-1.2,0.4-1.6l0.2-0.6
                l0.2-0.4l0.2-0.4l0.2-0.6l0.2-0.6l0.1-0.6l0.1-0.6l-0.4,0.1l-0.4,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.4,0.2l-0.4,0.2
                l-0.4,0.2l-0.4,0.2l-0.1,0.1c-0.1,0.1-0.8,0.4-1.9,1.2c-1.2,0.7-4.7,2.4-10.5,5s-11.6,5-17.5,7.1s-11.4,3.7-16.5,4.9
                s-8.8,0.5-11.3-1.9c-2.4-2.4-5.2-4.7-8.3-6.9c-3.1-2.2-6.5-4.3-10.4-6.4c-3.8-2.1-7.7-3.9-11.8-5.5c-4-1.6-8.6-2.9-13.5-3.8
                l-7.4-1.5h-20.5v0.1c0,0.1-1.7,0.4-5.1,0.9s-7.6,1.6-12.6,3.3c-5,1.7-10.4,4.2-16.3,7.4c-5.9,3.3-11.1,7-15.7,11.2
                s-8.3,8.3-11.2,12.2c-2.9,3.9-5.2,7.4-7,10.5C221.5,163.3,231.3,307,142.9,364.1z"></path>
                            <path id="wing1" fill="#5DA8DC" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                            <path id="wing2" fill="#C4DFF2" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                        </svg>
                    </h4>
                    <h4>
                        Check out these must-have approvals to secure your future
                    </h4>
                    <a href="https://www.youtube.com/watch?v=Diao6b6lfpE">Watch Video <img
                            src="assets/img/video-play.png" alt=""></a>
                </div>

                <div class="shadow-lg p-2 mt-4">
                    <h6 class=" text-start"> <img src="assets/img/deb_logo.webp" alt=""> UGC (University Grants
                        Commission)
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li class="">
                            UGC is responsible to maintain the standards of Higher Education in India
                        </li>
                        <li class="">
                            UGC approval helps in identifying fake and authentic universities.
                        </li>
                        <li class="">
                            UGC approval is a must. Without this, your degree is not valid
                        </li>


                    </ul>
                    <h6 class="text-start mt-3 ms-1">DEB (Distance Education Bureau)</h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li class="">
                            DEB under UGC is the regulatory body that regulates all the Distance & Online Education
                            Programs.
                        </li>
                        <li class="">
                            The university needs UGC-DEB approval to provide distance learning courses.
                        </li>
                        <li class="">
                            Only 10% of the total universities in India, is allowed by DEB to provide Online Degree
                            Courses
                        </li>
                    </ul>
                </div>


                <div class="shadow-lg p-2 my-4">
                    <h6 class=" text-start"> <img src="assets/img/naac_logo.webp" alt=""> NAAC(National Assessment and
                        Accreditation Council)
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li class="">
                            NAAC’s prime agenda is to assess the quality of education in Higher Education Institutes and
                            then provide accreditation.
                        </li>
                        <li class="">
                            NAAC provides students with information about the quality of institutes.
                        </li>
                        <li class="">
                            NAAC provides full-fledged reviews to universities about strengths, weaknesses, and
                            opportunities that help institutions to improve.
                        </li>
                        <li>
                            NAAC accreditation ranges from A++ to C. A++ is the maximum grade
                        </li>


                    </ul>

                </div>

                <div class="shadow-lg p-2 my-4">
                    <h6 class=" text-start"> <img src="assets/img/nirf_logo.webp" alt=""> NIRF Ranking (National
                        Institutional Ranking Framework)
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li>
                            NIRF assess the teaching methodology of institutions and then provides them ranking
                            accordingly.
                        </li>
                        <li>
                            NIRF ranking helps students identify the best university amongst thousands.
                        </li>
                        <li>
                            NIRF provides ranking as per the 11 different categories and the ranking helps students know
                            where the university stands in comparison to other universities in the same category.
                        </li>

                    </ul>

                </div>

                <div class="shadow-lg p-2 my-4">
                    <h6 class=" text-start"> <img src="assets/img/ugc_logo.webp" alt=""> AICTE (All India Council of
                        Technical Education)
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li>
                            AICTE approval is mandatory for technical institutes to offer courses that come under AICTE.
                        </li>
                        <li>
                            The degrees of engineering institutes (except IITs, NITs, etc.) are valid only if they have
                            AICTE approval.
                        </li>

                    </ul>

                </div>

                <div class="shadow-lg p-2 my-4">
                    <h6 class=" text-start"> <img src="assets/img/aiu_logo.webp" alt=""> AIU (Association of Indian
                        Universities)
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li>
                            AIU approval means your University Degree is valid across the Globe (Internationally
                            accepted)
                        </li>

                    </ul>

                </div>

                <div class="shadow-lg p-2 my-4">
                    <h6 class=" text-start"> <img src="assets/img/mobile-phone.png" class="img-fluid" alt=""> Verify
                        Your University
                    </h6>
                    <ul class=" text-start ms-4" style="list-style: unset;">
                        <li>
                            Don't make a decision that you might regret!
                        </li>
                        <li>
                            Pick UGC-DEB stamped universities only!
                        </li>


                    </ul>
                    <button type="submit" class="btn btn-danger text-start my-3">click to know</button>

                </div>


            </div>

        </div>
    </div>
</div>


<!-- The Modal1 -->
<div class="modal fade" id="myModal5">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body text-center">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>

                <div>
                    <img src="assets/img/logo-design.png" alt="" class="img-fluid" alt="" width="150" height="100">
                    <h4 class="text-primary">
                        #Righttoselect<svg version="1.1" id="Layer_1" width="30" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500"
                            enable-background="new 0 0 500 500" xml:space="preserve">
                            <style>
                                #wing1 {
                                    transform-origin: center;
                                    animation: flap 0.4s ease-out infinite alternate;
                                }

                                #wing2 {
                                    transform-origin: center;
                                    animation: flap 0.4s ease-in infinite alternate;
                                }

                                @keyframes flap {
                                    50% {
                                        transform: scaleX(-1) rotate(-45deg) translate(-40px, -40px);
                                    }
                                }
                            </style>
                            <path id="body" fill="#5DA8DC" d="M142.9,364.1c-1.6,1-3,1.7-4,2.3c-3,1.5-7.9,3.8-14.9,6.9c-7,3.1-14.7,5.7-23.1,7.9
                c-8.4,2.2-15.6,3.8-21.8,4.7c-6.2,0.9-12.2,1.5-18.1,1.8s-11.4,0.3-16.7,0c-5.2-0.3-8.5-0.5-9.6-0.6l-1.8-0.2l-0.4-0.1l-0.4-0.1v0.8
                h0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H33l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l3.6,2.2c2.4,1.5,4.5,2.6,6.4,3.6
                s6.6,3.3,14.1,7.1c7.6,3.7,16.6,7.4,27.2,11.1s18.6,6.2,24,7.4c5.4,1.3,12.8,2.6,22.2,3.9s14.9,2.1,16.3,2.2
                c1.5,0.1,3.3,0.3,5.5,0.4l3.3,0.2v0.2h25.6v-0.2l14-1.3c9.3-0.9,17.6-2.1,25-3.3c7.3-1.3,14.9-3.1,22.8-5.5
                c7.9-2.4,15.3-4.9,22.4-7.7c7.1-2.8,13.7-5.7,19.7-9c6.1-3.2,11.3-6,15.6-8.5c4.3-2.5,9.1-5.6,14.2-9.3c5.2-3.7,10-7.5,14.6-11.2
                s7.1-5.9,7.7-6.4c0.6-0.6,4-4,10.2-10.2c6.2-6.3,11.3-11.9,15.4-16.8c4-5,8-10.3,12-15.9c3.9-5.6,8.3-12.5,13-20.6
                s9.2-17.3,13.5-27.5s8-20.7,11-31.5c3-10.7,5.2-20.4,6.7-28.9s2.4-16.5,3-23.8c0.5-7.3,0.8-13.9,0.9-19.7s2.5-10.8,7.4-14.8
                s9.9-8.5,15-13.7c5.1-5.1,7.9-8,8.3-8.7c0.5-0.7,0.9-1.1,1.1-1.2c0.3-0.1,2.1-2.3,5.3-6.7c3.3-4.4,5-6.6,5-6.7l0.1-0.1l0.2-0.4
                l0.2-0.4l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.2-0.1l0.2-0.1V115l-1,0.3l-0.8,0.1
                l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.4,0.2l-0.6,0.2l-1.2,0.4l-10.6,3.6c-6.7,2.2-13.7,4.1-21,5.7l-11,2.4h-1.9l0.1-0.1l0.1-0.1l0.1-0.1
                l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l0.1-0.1l0.1-0.1l0.1-0.1l0.1-0.1l0.4-0.2l0.4-0.2l1.9-1.3
                c1.3-0.9,2.4-1.8,3.3-2.8s2.8-2.7,5.6-5.1c2.8-2.4,6-6,9.5-10.7s6.5-9.4,8.8-14s3.6-7.2,3.7-7.9c0.1-0.6,0.3-1.2,0.4-1.6l0.2-0.6
                l0.2-0.4l0.2-0.4l0.2-0.6l0.2-0.6l0.1-0.6l0.1-0.6l-0.4,0.1l-0.4,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.1,0.1l-0.4,0.2l-0.4,0.2
                l-0.4,0.2l-0.4,0.2l-0.1,0.1c-0.1,0.1-0.8,0.4-1.9,1.2c-1.2,0.7-4.7,2.4-10.5,5s-11.6,5-17.5,7.1s-11.4,3.7-16.5,4.9
                s-8.8,0.5-11.3-1.9c-2.4-2.4-5.2-4.7-8.3-6.9c-3.1-2.2-6.5-4.3-10.4-6.4c-3.8-2.1-7.7-3.9-11.8-5.5c-4-1.6-8.6-2.9-13.5-3.8
                l-7.4-1.5h-20.5v0.1c0,0.1-1.7,0.4-5.1,0.9s-7.6,1.6-12.6,3.3c-5,1.7-10.4,4.2-16.3,7.4c-5.9,3.3-11.1,7-15.7,11.2
                s-8.3,8.3-11.2,12.2c-2.9,3.9-5.2,7.4-7,10.5C221.5,163.3,231.3,307,142.9,364.1z"></path>
                            <path id="wing1" fill="#5DA8DC" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                            <path id="wing2" fill="#C4DFF2" d="M233.2,181.5c-5-0.5-12.4-1.7-22.2-3.6c-9.8-1.8-16.8-3.3-20.8-4.5s-11.1-3.7-21.2-7.4
                c-10.1-3.8-19.5-8-28.3-12.8c-8.8-4.7-16.8-9.5-24-14.4s-13.1-9.1-17.5-12.8c-4.5-3.7-7.1-6-7.9-7s-1.5-1.6-1.9-1.8
                c-0.5-0.2-3.2-2.7-8-7.6s-9.1-9.2-12.6-13.2l-5.3-5.9l-0.1-0.1l-0.1-0.1L63.1,90l-0.2-0.4l-0.1-0.1l-0.1-0.1l-0.1-0.1l-0.1-0.1
                l-0.1-0.1L62.3,89l-0.1-0.1l0,0.1l-0.1,0.1L62,89.2l0,0.1l-0.1,0.1L61.7,90l-0.2,0.6L57.9,98c-2.2,5-3.9,9.7-5.1,14.1
                c-1.2,4.5-1.9,8.5-2.4,12c-0.4,3.5-0.5,7.8-0.4,12.8s0.7,10,1.8,15.1c1,5.1,2.6,10.2,4.6,15.2c2.1,5.1,4,9.2,5.8,12.5
                c1.8,3.2,3.9,6.4,6.3,9.2c2.4,2.9,4.7,5.6,7.1,8.3s4.6,4.7,6.7,6.4c2.2,1.6,3.3,2.5,3.4,2.5l0.1,0.1l0.4,0.2l0.4,0.2l0.1,0.1
                l0.1,0.1l0.1,0.1L87,207l0.4,0.2l0.4,0.2l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1l0.1,0.1H85l-1.8-0.2
                c-1.2-0.1-4.8-0.9-10.8-2.2s-11.1-2.9-15.1-4.7l-6.1-2.8l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.2l-0.4-0.1l-0.4-0.1l0.7,8.3
                c0.4,5.5,1.4,11,2.8,16.3c1.5,5.4,3.6,11,6.5,16.9s6.2,11.1,9.8,15.5c3.7,4.5,7,8.1,10.1,11c3.1,2.8,6.3,5.4,9.8,7.8
                c3.4,2.4,8,4.8,13.8,7.3s9.3,3.9,10.6,4.3c1.3,0.4,2.2,0.6,2.8,0.8l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l0.8,0.2l-0.1,0.1l-0.1,0.1
                l-0.1,0.1l-0.1,0.1l-1,0.2l-1,0.2l-0.8,0.2c-0.5,0.1-1.9,0.4-4.3,0.8s-6.6,0.6-12.8,0.8c-6.2,0.1-10.7,0-13.5-0.4l-4.3-0.6L81,288
                l-0.6-0.1l0.1,0.4l0.1,0.4l0.2,0.6l0.2,0.6l3.2,7.2c2.2,4.8,4.4,9,6.7,12.7c2.3,3.7,5.1,7.2,8.3,10.7c3.2,3.5,5.8,6.2,7.9,8
                c2.1,1.9,5.3,4.3,9.9,7.2c4.6,2.9,9.3,5.4,14.1,7.4c4.9,2.1,9.4,3.7,13.5,4.7c4.2,1,7.3,1.6,9.2,1.8c1.9,0.1,4,0.3,6.1,0.4l3.1,0.2
                c117.9-117.9,82.9-167.7,82.9-167.7l-2.8-0.1C241.6,182.3,238.2,181.9,233.2,181.5z"></path>
                        </svg>
                    </h4>
                    <h4>
                        why choose Education Emplotability Emptloyment for making the right decision ?
                    </h4>
                    <p>100k+ Students Trust Education Emplotability Emptloyment for Admission to Online Universities
                    </p>
                </div>

                <div class="card p-2 mt-4 p-3">
                    <h4 class=" text-start">1 Unbiased Suggestions
                    </h4>
                    <p class=" text-start">As we are a information portal and not from any university we are not biassed
                        to any one and work in favour of what's best for the students, with Education Emplotability
                        Emptloyment you get to
                        explore all your options and select the best for you according to your needs.</p>



                </div>


                <div class="card p-2 my-4">
                    <h4 class=" text-start">2 Save you from a Scam
                    </h4>
                    <p class=" text-start">When you search for a university you get 100s of websites, making it
                        difficult to know which one is the official site of the university. This is where we come to
                        your rescue. We save you from getting scammed by fake websites and guide you to the official
                        site.</p>



                </div>

                <div class="card p-2 my-4">
                    <h4 class=" text-start">3 Direct Payments to the University
                    </h4>
                    <p class=" text-start">We at Education Emplotability Emptloyment do not work as middle men which
                        means that you pay the
                        fees and any other payment directly to the university. We request students to pay directly to
                        the university through their official website.</p>

                </div>

                <div class="card p-2 my-4">
                    <h4 class=" text-start">4 Full Support
                    </h4>
                    <p class=" text-start">We are there for you from the start. From the day you decide to start your
                        higher education via online mode till you complete your journey, you will find us right beside
                        you.</p>

                </div>

                <div class="card p-2 my-4">
                    <h4 class=" text-start">5 Personal Counsellors
                    </h4>
                    <p class=" text-start">We assign 2 personal counsellors to each student, one from the university and
                        the other from Education Emplotability Emptloyment itself. Counsellors assigned to the student
                        are always available to
                        resolve any query at</p>

                </div>

                <div class="card p-2 my-4">
                    <h4 class=" text-start">6 Our Services
                    </h4>
                    <p class=" text-start">We offer our services for free so that everyone gets the right guidance. Our
                        experts are available round the clock to assist you in your journey.</p>

                </div>




            </div>

        </div>
    </div>
</div>



<?php include('know-base-modal.php') ?>

<?php include('expert-modal.php') ?>

<?php include("footer.php"); ?>

<?php include ('muti-step-popup.php')?>